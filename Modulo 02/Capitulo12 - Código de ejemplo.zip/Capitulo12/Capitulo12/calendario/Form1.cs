﻿namespace calendario
{

    public partial class Form1 : System.Windows.Forms.Form
    {
        private System.Windows.Forms.MonthCalendar calendarioMensual;
        private System.Windows.Forms.TextBox txtb1;

        public Form1()
        {
            this.txtb1 = new System.Windows.Forms.TextBox();
            this.txtb1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtb1.Location = new System.Drawing.Point(48, 488);
            this.txtb1.Multiline = true;
            this.txtb1.ReadOnly = true;
            this.txtb1.Size = new System.Drawing.Size(824, 32);

            // Crear el calendario.
            this.calendarioMensual = new System.Windows.Forms.MonthCalendar();

            // Configurar la locación del calendario.
            this.calendarioMensual.Location = new System.Drawing.Point(47, 16);

            // Cambiar el color.
            this.calendarioMensual.BackColor = System.Drawing.SystemColors.Info;
            this.calendarioMensual.ForeColor = System.Drawing.Color.FromArgb(
                                     ((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(192)));
            this.calendarioMensual.TitleBackColor = System.Drawing.Color.Purple;
            this.calendarioMensual.TitleForeColor = System.Drawing.Color.Yellow;
            this.calendarioMensual.TrailingForeColor = System.Drawing.Color.FromArgb(
                                     ((System.Byte)(192)), ((System.Byte)(192)), ((System.Byte)(0)));

            // Agregar fechas al vector AnnuallyBoldedDates.
            this.calendarioMensual.AnnuallyBoldedDates =
                new System.DateTime[] { new System.DateTime(2002, 4, 20, 0, 0, 0, 0),
                                    new System.DateTime(2002, 4, 28, 0, 0, 0, 0),
                                    new System.DateTime(2002, 5, 5, 0, 0, 0, 0),
                                    new System.DateTime(2002, 7, 4, 0, 0, 0, 0),
                                    new System.DateTime(2002, 12, 15, 0, 0, 0, 0),
                                    new System.DateTime(2002, 12, 18, 0, 0, 0, 0)};

            // Agregar fechas al vector BoldedDates.
            this.calendarioMensual.BoldedDates = new System.DateTime[] { new System.DateTime(2002, 9, 26, 0, 0, 0, 0) };

            // Agregar fechas al vector MonthlyBoldedDates.
            this.calendarioMensual.MonthlyBoldedDates =
               new System.DateTime[] {new System.DateTime(2002, 1, 15, 0, 0, 0, 0),
                                  new System.DateTime(2002, 1, 30, 0, 0, 0, 0)};

            // Configurar el calendario para mostrar 3 filas por 4 columnas de meses.
            this.calendarioMensual.CalendarDimensions = new System.Drawing.Size(4, 3);

            // Configurar la semana para que comienze el lunes.
            this.calendarioMensual.FirstDayOfWeek = System.Windows.Forms.Day.Monday;

            // Configrar la fecha máxima visible del calendario en 12/31/2015.
            this.calendarioMensual.MaxDate = new System.DateTime(2015, 12, 31, 0, 0, 0, 0);

            // Configrar la fecha máxima visible del calendario en 12/31/2001.
            this.calendarioMensual.MinDate = new System.DateTime(2001, 1, 1, 0, 0, 0, 0);

            // Permitir seleccionar sólo 21 días al mismo tiempo
            this.calendarioMensual.MaxSelectionCount = 21;

            // Configurar al calendario para que se mueva de a una semana a la vez 
            // cuando se utilizan las flachas de cursor
            this.calendarioMensual.ScrollChange = 1;

            // No mostrar el cartel "Today".
            this.calendarioMensual.ShowToday = false;

            // No poner un círculo en la fecha actual.
            this.calendarioMensual.ShowTodayCircle = false;

            // Mostrar el nro de semana a la izquierda de cada una
            this.calendarioMensual.ShowWeekNumbers = true;

            // Agregar manejadores de eventos para DateSelected y DateChanged
            this.calendarioMensual.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateSelected);
            this.calendarioMensual.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);

            // Configurar como se debe mostrar el calendario y agregarlo al formulario
            this.ClientSize = new System.Drawing.Size(1048, 566);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.txtb1, this.calendarioMensual });
            this.Text = "Ejemplo de Calendario Mensual";
        }

        private void monthCalendar1_DateSelected(object sender, System.Windows.Forms.DateRangeEventArgs e)
        {
            // Mostrar las fechas de comienzo y fin en el cuadro de texto.
            this.txtb1.Text = "Fecha Seleccionada: Inicio = " +
                e.Start.ToShortDateString() + " : Fin = " + e.End.ToShortDateString();
        }

        private void monthCalendar1_DateChanged(object sender, System.Windows.Forms.DateRangeEventArgs e)
        {
            // Mostrar las fechas de comienzo y fin en el cuadro de texto.
            this.txtb1.Text = "Cambio de Fecha: Inicio =  " +
                e.Start.ToShortDateString() + " : Fin = " + e.End.ToShortDateString();
        }
    }
}
