﻿using System.Drawing;
using System.Windows.Forms;

namespace etiquetas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Etiquetas";
            // Crear una instancia de Label.
            Label lbl = new Label();
            // Agregarla al formulario
            this.Controls.Add(lbl);
            // Configurar un borde tridimensional.
            lbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            // Configurar el color de fondo
            lbl.BackColor = Color.Blue;
            // Configurar el color de la letra
            lbl.ForeColor = Color.AntiqueWhite;

            // Especificar que el tecto puede mostrrar
            // caracteres mnemónicos.
            lbl.UseMnemonic = true;
            // Configurar el texto y el caracter mnemónico
            lbl.Text = "Primer &Nombre: " + "Juan";

            /* Configurar el tamaño del control basado en 
             * los valores de PreferredHeight y PreferredWidth. */
            lbl.Size = new Size(lbl.PreferredWidth, lbl.PreferredHeight);
        }
    }
}
