﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace listasDeVistas
{
    public partial class Form1 : Form
    {
        // Crear un nuevo control ListView.
        private ListView lstv1 = new ListView();

        public Form1()
        {
            InitializeComponent();
            CrearListaDeVista();
        }

        private void CrearListaDeVista()
        {
            lstv1.Bounds = new Rectangle(new Point(10, 10), new Size(300, 200));

            // Configurar la vista para mostrar inicialmente detalles.
            lstv1.View = View.Details;
            // Permitirle al usuario editar el texto.
            lstv1.LabelEdit = true;
            // Permitirle reordenar las columnas.
            lstv1.AllowColumnReorder = true;
            // Mostrar cajas de verificación.
            lstv1.CheckBoxes = true;
            // Seleccionar items y subitemes a la vez.
            lstv1.FullRowSelect = true;
            // Mostrar las líneas de la grilla.
            lstv1.GridLines = true;
            // Ordenar items en forma ascendente.
            lstv1.Sorting = SortOrder.Ascending;
            lstv1.Visible = true;

            // Crear tres items y tres Conjuntos de subitems para cada uno.
            ListViewItem item1 = new ListViewItem("ítem 1", 0);
            // Colocar una marca de verificación en el ítem.
            item1.Checked = true;
            item1.SubItems.Add("1");
            item1.SubItems.Add("2");
            item1.SubItems.Add("3");
            ListViewItem item2 = new ListViewItem("ítem 2", 1);
            item2.SubItems.Add("4");
            item2.SubItems.Add("5");
            item2.SubItems.Add("6");
            ListViewItem item3 = new ListViewItem("ítem 3", 0);
            // Colocar una marca de verificación en el ítem.
            item3.Checked = true;
            item3.SubItems.Add("7");
            item3.SubItems.Add("8");
            item3.SubItems.Add("9");

            // Crear las columnas de los ítems y subitems
            // El ancho (Width) -2 indica tamaño automático
            lstv1.Columns.Add("Columna del Item", -2, HorizontalAlignment.Left);
            lstv1.Columns.Add("Columna 2", -2, HorizontalAlignment.Left);
            lstv1.Columns.Add("Columna 3", -2, HorizontalAlignment.Left);
            lstv1.Columns.Add("Columna 4", -2, HorizontalAlignment.Center);

            // Agregar los ítems al ListView.
            lstv1.Items.AddRange(new ListViewItem[] { item1, item2, item3 });

            // Crear dos objetos del tipo ImageList.
            ImageList listaDeImagenesChicas = new ImageList();
            ImageList listaDeImagenesGrandes = new ImageList();


            listaDeImagenesChicas.Images.Add(Bitmap.FromFile(@".\imagenes\3x2open.GIF"));
            listaDeImagenesChicas.Images.Add(Bitmap.FromFile(@".\imagenes\Penguins.jpg"));
            listaDeImagenesGrandes.Images.Add(Bitmap.FromFile(@".\imagenes\fotomot_4.jpg"));
            listaDeImagenesGrandes.Images.Add(Bitmap.FromFile(@".\imagenes\Chrysanthemum.jpg"));

            //Asignar los objetos ImageList al ListView.
            lstv1.LargeImageList = listaDeImagenesGrandes;
            lstv1.SmallImageList = listaDeImagenesChicas;
            lstv1.SmallImageList.ImageSize = new Size(25, 25);
            lstv1.LargeImageList.ImageSize = new Size(50, 50);

            // Agregar el ListView a la colección de controles.
            this.Controls.Add(lstv1);
        }

        private void btCambiarDetalles_Click(object sender, EventArgs e)
        {
            // Cambiar la vista
            lstv1.View = View.Details;
        }

        private void btIconosChicos_Click(object sender, EventArgs e)
        {
            // Cambiar la vista
            lstv1.View = View.SmallIcon;
        }

        private void btIconosGrandes_Click(object sender, EventArgs e)
        {
            // Cambiar la vista
            lstv1.View = View.LargeIcon;
        }
    }
}
