﻿namespace listasDeVistas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btCambiarDetalles = new System.Windows.Forms.Button();
            this.btIconosGrandes = new System.Windows.Forms.Button();
            this.btIconosChicos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btCambiarDetalles
            // 
            this.btCambiarDetalles.Location = new System.Drawing.Point(317, 99);
            this.btCambiarDetalles.Name = "btCambiarDetalles";
            this.btCambiarDetalles.Size = new System.Drawing.Size(133, 23);
            this.btCambiarDetalles.TabIndex = 0;
            this.btCambiarDetalles.Text = "Cambiar Detalles";
            this.btCambiarDetalles.UseVisualStyleBackColor = true;
            this.btCambiarDetalles.Click += new System.EventHandler(this.btCambiarDetalles_Click);
            // 
            // btIconosGrandes
            // 
            this.btIconosGrandes.Location = new System.Drawing.Point(317, 128);
            this.btIconosGrandes.Name = "btIconosGrandes";
            this.btIconosGrandes.Size = new System.Drawing.Size(133, 23);
            this.btIconosGrandes.TabIndex = 1;
            this.btIconosGrandes.Text = "Cambiar Íconos Grandes";
            this.btIconosGrandes.UseVisualStyleBackColor = true;
            this.btIconosGrandes.Click += new System.EventHandler(this.btIconosGrandes_Click);
            // 
            // btIconosChicos
            // 
            this.btIconosChicos.Location = new System.Drawing.Point(317, 157);
            this.btIconosChicos.Name = "btIconosChicos";
            this.btIconosChicos.Size = new System.Drawing.Size(133, 23);
            this.btIconosChicos.TabIndex = 2;
            this.btIconosChicos.Text = "Cambiar Íconos Chicos";
            this.btIconosChicos.UseVisualStyleBackColor = true;
            this.btIconosChicos.Click += new System.EventHandler(this.btIconosChicos_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 262);
            this.Controls.Add(this.btIconosChicos);
            this.Controls.Add(this.btIconosGrandes);
            this.Controls.Add(this.btCambiarDetalles);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btCambiarDetalles;
        private System.Windows.Forms.Button btIconosGrandes;
        private System.Windows.Forms.Button btIconosChicos;
    }
}

