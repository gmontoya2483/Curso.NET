﻿using System.Windows.Forms;

namespace divisor
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CrearControlesEnDivision();
        }


        private void CrearControlesEnDivision()
        {
            // Crear los controles TreeView, ListView y Splitter.
            TreeView treeView1 = new TreeView();
            ListView listView1 = new ListView();
            Splitter splitter1 = new Splitter();

            // Configurar el TreeView para ajustarse a la izquierda del formulario
            treeView1.Dock = DockStyle.Left;
            // Configurar el Splitter para ajustarse a la izquierda del TreeView.
            splitter1.Dock = DockStyle.Left;
            // Configurar el tamaño mínimo que puede tener el ListView.
            splitter1.MinExtra = 100;
            // Configurar el mínimo tamaño que puede tener el TreeView.
            splitter1.MinSize = 75;
            // Configurar al ListView para que ocupe el espacio restante.
            listView1.Dock = DockStyle.Fill;
            // Agregar los controles TreeView y ListView para identificarlos.
            treeView1.Nodes.Add("Nodo TreeView");
            listView1.Items.Add("Item ListView");

            this.Controls.AddRange(new Control[] { listView1, splitter1, treeView1 });
        }
    }
}
