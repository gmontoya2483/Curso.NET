﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace fechas
{
    public partial class Form1 : System.Windows.Forms.Form
    {


        public Form1()
        {
            InitializeComponent();
            Size = new Size(519, 305);
            dtp.Parent = this;
            dtp.Location = new Point(20, 20);
            dtp.Size = new Size(ClientSize.Width - 40, dtp.PreferredHeight);
            dtp.Anchor = AnchorStyles.Top | AnchorStyles.Left |
                  AnchorStyles.Right;
            Font fnt = new Font("Times New Roman", 16);
            dtp.CalendarFont = new Font(fnt,
                          FontStyle.Bold | FontStyle.Italic);
            dtp.CalendarForeColor = Color.Red;
            dtp.CalendarMonthBackground = Color.LightGray;
            dtp.CalendarTitleBackColor = Color.MidnightBlue;
            dtp.CalendarTitleForeColor = Color.Blue;
            dtp.CalendarTrailingForeColor = Color.FromArgb(150, 152, 222);
            dtp.CustomFormat = "dddd,MMMM d, yyyy 'at' h:mm:ss tt";
            dtp.Format = DateTimePickerFormat.Custom;
            dtp.DropDownAlign = LeftRightAlignment.Right;
            dtp.ShowUpDown = false;    // default

        }


        private void ActualizarLiterales()
        {
            DateTime d = dtp.Value;

            Console.WriteLine("-----------------------");
            Console.WriteLine(dtp.Value.ToString());
            Console.WriteLine(dtp.Value.ToLongDateString());
            Console.WriteLine(dtp.Value.ToLongTimeString());
            Console.WriteLine(dtp.Value.ToShortDateString());
            Console.WriteLine(dtp.Value.ToShortTimeString());
            Console.WriteLine("-----------------------");

            textBox1.Text = d.ToString();
            textBox2.Text = d.ToLongDateString();
            textBox3.Text = d.ToLongTimeString();
            textBox4.Text = d.ToShortDateString();
            textBox5.Text = d.ToShortTimeString();

        }


        private void dtp_ValueChanged(object sender, EventArgs e)
        {
            ActualizarLiterales();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ActualizarLiterales();
        }

    }
}
