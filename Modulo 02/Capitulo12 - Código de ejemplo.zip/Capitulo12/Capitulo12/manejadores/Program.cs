﻿using System;

namespace manejadores
{
    class Program
    {
        static void Main(string[] args)
        {
            Contador c = new Contador(new Random().Next(10));
            c.UmbralAlcanzado += ManejadorEventoUmbralAlcanzado;

            Console.WriteLine("Presionar la tecla 'a' para incrementar el total");
            while (Console.ReadKey(true).KeyChar == 'a')
            {
                Console.WriteLine("agregando uno");
                c.Agregar(1);
            }
        }

        static void ManejadorEventoUmbralAlcanzado(object sender, UmbralAlcanzadoEventArgs e)
        {
            Console.WriteLine("El umbral de {0} se alcanzó el {1}.", e.Umbral, e.FechaFinalizacion);
            Console.WriteLine("Presione una tecla para terminar ...");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
