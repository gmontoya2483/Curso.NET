﻿using System;

namespace manejadores
{
    class UmbralAlcanzadoEventArgs : EventArgs
    {
        public int Umbral { get; set; }
        public DateTime FechaFinalizacion { get; set; }
    }
}
