﻿using System;

namespace manejadores
{
    class Contador
    {
        public event EventHandler<UmbralAlcanzadoEventArgs> UmbralAlcanzado;

        private int _umbral;
        private int _total;

        public Contador(int limite)
        {
            _umbral = limite;
        }

        public void Agregar(int x)
        {
            _total += x;
            if (_total >= _umbral)
            {
                UmbralAlcanzadoEventArgs args = new UmbralAlcanzadoEventArgs();
                args.Umbral = _umbral;
                args.FechaFinalizacion = DateTime.Now;
                OnUmbralAlcanzado(args);
            }
        }

        protected virtual void OnUmbralAlcanzado(UmbralAlcanzadoEventArgs e)
        {
            EventHandler<UmbralAlcanzadoEventArgs> manejador = UmbralAlcanzado;
            if (manejador != null)
            {
                manejador(this, e);
            }
        }
    }
}
