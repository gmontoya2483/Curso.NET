﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections;

namespace listasDeControles
{
    public partial class EjemploListBox : Form
    {
        private ListBox lbx1 = new ListBox();
        private Label lb1 = new Label();
        private TextBox txtb1 = new TextBox();

        public EjemploListBox()
        {
            this.ClientSize = new Size(307, 206);
            this.Text = "Ejemplo de ListBox";

            lbx1.Location = new Point(54, 16);
            lbx1.Name = "ListBox1";
            lbx1.Size = new Size(240, 130);

            lb1.Location = new Point(14, 150);
            lb1.Name = "label1";
            lb1.Size = new Size(45, 30);
            lb1.Text = "Iniciales";

            txtb1.Location = new Point(70, 150);
            txtb1.Name = "textBox1";
            txtb1.Size = new Size(215, 24);

            this.Controls.AddRange(new Control[] { lbx1, lb1, txtb1 });

            // Rellenar la lista usando un vector como DataSource
            ArrayList _nombres = new ArrayList();
            _nombres.Add(new Nombres("José Garcia", "JG"));
            _nombres.Add(new Nombres("Pedro Buscemi", "PB"));
            _nombres.Add(new Nombres("Virginia Manso", "VM"));
            _nombres.Add(new Nombres("Mónica Gonzalez", "MG"));
            _nombres.Add(new Nombres("Franciso Vieytes", "FV"));
            lbx1.DataSource = _nombres;

            // Configurar la propiedad Nombre para que se muestre y la
            // propiedad Iniciales como el valor retornado cuando se 
            // selecciona una columna. En este caso son propiedades pero
            // si se enlaza con una tabla de una BDD se deben colocar
            // los nombres de las columnas.
            lbx1.DisplayMember = "Nombre";
            lbx1.ValueMember = "Iniciales";

            // Enlazar el evento SelectedValueChanged al manejador.
            lbx1.SelectedValueChanged +=
                new EventHandler(ListBox1_SelectedValueChanged);

            // Asegurarse que el formulario se abre sin filas seleccionadas.
            lbx1.ClearSelected();
        }

        private void ListBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (lbx1.SelectedIndex != -1)
            {
                txtb1.Text = ((Nombres)lbx1.SelectedItem).Nombre + ": " + lbx1.SelectedValue.ToString();
            }
        }
    }
}
