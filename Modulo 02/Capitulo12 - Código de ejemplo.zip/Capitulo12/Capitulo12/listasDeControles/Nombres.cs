﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace listasDeControles
{
    public class Nombres
    {
        private string _iniciales;
        private string _nombre;

        public Nombres(string nombre, string iniciales)
        {
            this._iniciales = iniciales;
            this._nombre = nombre;
        }

       public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }

        public string Iniciales
        {
            get
            {
                return _iniciales;
            }
            set
            {
                _iniciales = value;
            }
        }
    }
}
