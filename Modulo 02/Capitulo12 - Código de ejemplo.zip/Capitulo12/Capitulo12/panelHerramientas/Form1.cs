﻿using System;
using System.Windows.Forms;

namespace panelHerramientas
{
    // Este ejemplo demuestra como usar ToolStripPanel
    // con una interfaz MDI (multiple document interface)
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Convertir al Form en contenedor MDI.
            this.IsMdiContainer = true;

            // Crear los controles ToolStripPanel.
            ToolStripPanel tspArriba = new ToolStripPanel();
            ToolStripPanel tspAbajo = new ToolStripPanel();
            ToolStripPanel tspIzquierda = new ToolStripPanel();
            ToolStripPanel tspDerecha = new ToolStripPanel();

            // Anclar los the controles del ToolStripPanel 
            // a los bordes del formulario.
            tspArriba.Dock = DockStyle.Top;
            tspAbajo.Dock = DockStyle.Bottom;
            tspIzquierda.Dock = DockStyle.Left;
            tspDerecha.Dock = DockStyle.Right;

            // Crear los controles de ToolStrip para
            // moverse entre los controles del ToolStripPanel

            // Crear el control ToolStrip de "Arriba" y
            // agregarlo al correspondiente ToolStripPanel.
            ToolStrip tsArriba = new ToolStrip();
            tsArriba.Items.Add("Arriba");
            tspArriba.Join(tsArriba);

            // Crear el control ToolStrip de "Abajo" y
            // agregarlo al correspondiente ToolStripPanel.
            ToolStrip tsAbajo = new ToolStrip();
            tsAbajo.Items.Add("Abajo");
            tspAbajo.Join(tsAbajo);

            // Crear el control ToolStrip de "Derecha" y
            // agregarlo al correspondiente ToolStripPanel.
            ToolStrip tsDerecha = new ToolStrip();
            tsDerecha.Items.Add("Derecha");
            tspDerecha.Join(tsDerecha);

            // Crear el control ToolStrip de "Izquierda" y
            // agregarlo al correspondiente ToolStripPanel.
            ToolStrip tsIzquierda = new ToolStrip();
            tsIzquierda.Items.Add("Izquierda");
            tspIzquierda.Join(tsIzquierda);

            // Crear un control MenuStrip con una ventana nueva.
            MenuStrip ms = new MenuStrip();
            ToolStripMenuItem menuVentana = new ToolStripMenuItem("Menú en la Ventana");
            ToolStripMenuItem menuNuevo = new ToolStripMenuItem("Nuevo", null, new EventHandler(windowNewMenu_Click));
            menuVentana.DropDownItems.Add(menuNuevo);
            ((ToolStripDropDownMenu)(menuVentana.DropDown)).ShowImageMargin = false;
            ((ToolStripDropDownMenu)(menuVentana.DropDown)).ShowCheckMargin = true;

            // Asignar el ToolStripMenuItem que muestra
            // la lista de formularios hijos
            ms.MdiWindowListItem = menuVentana;

            // Agregar la ventana del ToolStripMenuItem al MenuStrip.
            ms.Items.Add(menuVentana);

            // Anclar el MenuStrip a la parte superior del formulario
            ms.Dock = DockStyle.Top;

            // La propiedad Form.MainMenuStrip determina el destino con que se fusiona.
            this.MainMenuStrip = ms;

            // Agregar los ToolStripPanels al formulario en orden inverso
            this.Controls.Add(tspDerecha);
            this.Controls.Add(tspIzquierda);
            this.Controls.Add(tspAbajo);
            this.Controls.Add(tspArriba);

            // Agregar al final el MenuStrip
            // ESTO ES IMPORTANTE para la ubicación correcta del z-order.
            this.Controls.Add(ms);
        }

        // Este manejador de evento se invoca cuando
        // se presiona Nuevo en el ToolStripMenuItem y
        // crea un formulario nuevo, configurando como
        // padre al formulario principal por medio de
        // la propiedad MdiParent
        void windowNewMenu_Click(object sender, EventArgs e)
        {
            Form f = new Form();
            f.MdiParent = this;
            f.Text = "Formulario - " + this.MdiChildren.Length.ToString();
            f.Show();
        }
    }
}
