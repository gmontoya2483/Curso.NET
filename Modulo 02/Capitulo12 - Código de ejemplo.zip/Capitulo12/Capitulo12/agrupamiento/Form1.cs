﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace agrupamiento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            gbMaxima.FlatStyle = FlatStyle.Flat;
            gbMinima.FlatStyle = FlatStyle.Standard;
            lblMinima.Text = "Mínima: ";
            lblMaxima.Text = "Máxima: ";
        }

        private void CambioDeVelocidadMinima(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton) sender;
            lblMinima.Text = "Mínima: " + rb.Text;
        }

        private void CambioDeVelocidadMaxima(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            lblMaxima.Text = "Máxima: " + rb.Text;
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
