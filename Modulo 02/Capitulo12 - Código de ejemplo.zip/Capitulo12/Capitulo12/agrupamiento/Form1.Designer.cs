﻿namespace agrupamiento
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbMinima = new System.Windows.Forms.GroupBox();
            this.rbt40 = new System.Windows.Forms.RadioButton();
            this.rbt30 = new System.Windows.Forms.RadioButton();
            this.rbt20 = new System.Windows.Forms.RadioButton();
            this.gbMaxima = new System.Windows.Forms.GroupBox();
            this.rbt130 = new System.Windows.Forms.RadioButton();
            this.rbt120 = new System.Windows.Forms.RadioButton();
            this.rbt100 = new System.Windows.Forms.RadioButton();
            this.lblMinima = new System.Windows.Forms.Label();
            this.lblMaxima = new System.Windows.Forms.Label();
            this.btAceptar = new System.Windows.Forms.Button();
            this.gbMinima.SuspendLayout();
            this.gbMaxima.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbMinima
            // 
            this.gbMinima.Controls.Add(this.rbt40);
            this.gbMinima.Controls.Add(this.rbt30);
            this.gbMinima.Controls.Add(this.rbt20);
            this.gbMinima.Location = new System.Drawing.Point(12, 12);
            this.gbMinima.Name = "gbMinima";
            this.gbMinima.Size = new System.Drawing.Size(108, 100);
            this.gbMinima.TabIndex = 0;
            this.gbMinima.TabStop = false;
            this.gbMinima.Text = "Velocidad Mínima";
            // 
            // rbt40
            // 
            this.rbt40.AutoSize = true;
            this.rbt40.Location = new System.Drawing.Point(7, 65);
            this.rbt40.Name = "rbt40";
            this.rbt40.Size = new System.Drawing.Size(65, 17);
            this.rbt40.TabIndex = 2;
            this.rbt40.TabStop = true;
            this.rbt40.Text = "40 km/h";
            this.rbt40.UseVisualStyleBackColor = true;
            this.rbt40.CheckedChanged += new System.EventHandler(this.CambioDeVelocidadMinima);
            // 
            // rbt30
            // 
            this.rbt30.AutoSize = true;
            this.rbt30.Location = new System.Drawing.Point(7, 42);
            this.rbt30.Name = "rbt30";
            this.rbt30.Size = new System.Drawing.Size(65, 17);
            this.rbt30.TabIndex = 1;
            this.rbt30.TabStop = true;
            this.rbt30.Text = "30 km/h";
            this.rbt30.UseVisualStyleBackColor = true;
            this.rbt30.CheckedChanged += new System.EventHandler(this.CambioDeVelocidadMinima);
            // 
            // rbt20
            // 
            this.rbt20.AutoSize = true;
            this.rbt20.Location = new System.Drawing.Point(7, 20);
            this.rbt20.Name = "rbt20";
            this.rbt20.Size = new System.Drawing.Size(65, 17);
            this.rbt20.TabIndex = 0;
            this.rbt20.TabStop = true;
            this.rbt20.Text = "20 km/h";
            this.rbt20.UseVisualStyleBackColor = true;
            this.rbt20.CheckedChanged += new System.EventHandler(this.CambioDeVelocidadMinima);
            // 
            // gbMaxima
            // 
            this.gbMaxima.Controls.Add(this.rbt130);
            this.gbMaxima.Controls.Add(this.rbt120);
            this.gbMaxima.Controls.Add(this.rbt100);
            this.gbMaxima.Location = new System.Drawing.Point(12, 122);
            this.gbMaxima.Name = "gbMaxima";
            this.gbMaxima.Size = new System.Drawing.Size(108, 100);
            this.gbMaxima.TabIndex = 1;
            this.gbMaxima.TabStop = false;
            this.gbMaxima.Text = "Velocidad Máxima";
            // 
            // rbt130
            // 
            this.rbt130.AutoSize = true;
            this.rbt130.Location = new System.Drawing.Point(7, 67);
            this.rbt130.Name = "rbt130";
            this.rbt130.Size = new System.Drawing.Size(71, 17);
            this.rbt130.TabIndex = 5;
            this.rbt130.TabStop = true;
            this.rbt130.Text = "130 km/h";
            this.rbt130.UseVisualStyleBackColor = true;
            this.rbt130.CheckedChanged += new System.EventHandler(this.CambioDeVelocidadMaxima);
            // 
            // rbt120
            // 
            this.rbt120.AutoSize = true;
            this.rbt120.Location = new System.Drawing.Point(7, 44);
            this.rbt120.Name = "rbt120";
            this.rbt120.Size = new System.Drawing.Size(71, 17);
            this.rbt120.TabIndex = 4;
            this.rbt120.TabStop = true;
            this.rbt120.Text = "120 km/h";
            this.rbt120.UseVisualStyleBackColor = true;
            this.rbt120.CheckedChanged += new System.EventHandler(this.CambioDeVelocidadMaxima);
            // 
            // rbt100
            // 
            this.rbt100.AutoSize = true;
            this.rbt100.Location = new System.Drawing.Point(7, 22);
            this.rbt100.Name = "rbt100";
            this.rbt100.Size = new System.Drawing.Size(71, 17);
            this.rbt100.TabIndex = 3;
            this.rbt100.Text = "100 km/h";
            this.rbt100.UseVisualStyleBackColor = true;
            this.rbt100.CheckedChanged += new System.EventHandler(this.CambioDeVelocidadMaxima);
            // 
            // lblMinima
            // 
            this.lblMinima.AutoSize = true;
            this.lblMinima.Location = new System.Drawing.Point(169, 58);
            this.lblMinima.Name = "lblMinima";
            this.lblMinima.Size = new System.Drawing.Size(35, 13);
            this.lblMinima.TabIndex = 2;
            this.lblMinima.Text = "label1";
            // 
            // lblMaxima
            // 
            this.lblMaxima.AutoSize = true;
            this.lblMaxima.Location = new System.Drawing.Point(169, 170);
            this.lblMaxima.Name = "lblMaxima";
            this.lblMaxima.Size = new System.Drawing.Size(35, 13);
            this.lblMaxima.TabIndex = 3;
            this.lblMaxima.Text = "label2";
            // 
            // btAceptar
            // 
            this.btAceptar.Location = new System.Drawing.Point(109, 237);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(75, 23);
            this.btAceptar.TabIndex = 4;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 272);
            this.Controls.Add(this.btAceptar);
            this.Controls.Add(this.lblMaxima);
            this.Controls.Add(this.lblMinima);
            this.Controls.Add(this.gbMaxima);
            this.Controls.Add(this.gbMinima);
            this.Name = "Form1";
            this.Text = "Seleccionar Velocidad";
            this.gbMinima.ResumeLayout(false);
            this.gbMinima.PerformLayout();
            this.gbMaxima.ResumeLayout(false);
            this.gbMaxima.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbMinima;
        private System.Windows.Forms.RadioButton rbt40;
        private System.Windows.Forms.RadioButton rbt30;
        private System.Windows.Forms.RadioButton rbt20;
        private System.Windows.Forms.GroupBox gbMaxima;
        private System.Windows.Forms.RadioButton rbt130;
        private System.Windows.Forms.RadioButton rbt120;
        private System.Windows.Forms.RadioButton rbt100;
        private System.Windows.Forms.Label lblMinima;
        private System.Windows.Forms.Label lblMaxima;
        private System.Windows.Forms.Button btAceptar;
    }
}

