﻿using System.Windows.Forms;

namespace seguimiento
{
    public partial class Form1 : Form
    {
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TextBox textBox1;

        public Form1()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();

            // TextBox que se actualiza con TrackBar.Value
            this.textBox1.Location = new System.Drawing.Point(240, 16);
            this.textBox1.Size = new System.Drawing.Size(48, 20);

            // Configurar como se debe mostrar el formulario y sus controles
            this.ClientSize = new System.Drawing.Size(296, 62);
            this.Controls.AddRange(new System.Windows.Forms.Control[] { this.textBox1, this.trackBar1 });
            this.Text = "Ejemplo de TrackBar";

            // Configurar el TrackBar.
            this.trackBar1.Location = new System.Drawing.Point(8, 8);
            this.trackBar1.Size = new System.Drawing.Size(224, 45);
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);

            // La propiedad Maximum configura el valor de la barra de
            // seguimiento cunado el deslizador llega al extremo derecho
            trackBar1.Maximum = 30;

            // La propiedad TickFrequency establece la cantidad
            // de marcas de división
            trackBar1.TickFrequency = 5;

            // La propiedad LargeChange configura la cantidad de
            // posiciones que se mueve cuando se hace clic a uno u
            // otro lado del deslizador
            trackBar1.LargeChange = 3;

            // La propiedad SmallChange configura la cantidad de posiciones
            // el deslizador cuando se usan las flechas del teclado
            trackBar1.SmallChange = 2;
        }

        private void trackBar1_Scroll(object sender, System.EventArgs e)
        {
            // Mostrar el valor de la barra de seguimiento en
            // el cuadro de texto.
            textBox1.Text = "" + trackBar1.Value;
        }
    }
}
