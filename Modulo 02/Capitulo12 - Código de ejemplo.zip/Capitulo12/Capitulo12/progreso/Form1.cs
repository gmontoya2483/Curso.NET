﻿using System;
using System.Windows.Forms;

namespace progreso
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            lbl1.Text = ""; 
            lbl2.Text = ""; 
            lbl3.Text = ""; 
            lbl4.Text = "";
        }

        private void RealizarTareas()
        {
           Label[] lVec = {lbl1, lbl2, lbl3, lbl4 };
            // Mostrar el ProgressBar.
            pBar1.Visible = true;
            // Configurar el mínimo en 1 que representa la primera tarea.
            pBar1.Minimum = 1;
            // Configurar el máximo de tareas a realizar.
            pBar1.Maximum = lVec.Length + 1;
            // Configurar el valor inicial del ProgressBar.
            pBar1.Value = 1;
            // Configurar la propiedad Step a un valor de 1
            // que representa cada tarea realizada
            pBar1.Step = 1;

             // Simular realización de tareas
            for (int x = 0; x < 4; x++)
            {
                pBar1.PerformStep();
                for (int i = 0; i < 10000; i++)
                {
                    lVec[x].Text = i.ToString();
                    lVec[x].Update();
                }              
            }
        }

        private void btComenzar_Click(object sender, EventArgs e)
        {
            RealizarTareas();
        }

        private void btSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
