﻿using System;
using System.Windows.Forms;

namespace mascaras
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            maskedTextBox1.Mask = "00/00/0000";

            maskedTextBox1.MaskInputRejected += new MaskInputRejectedEventHandler(maskedTextBox1_MaskInputRejected);
            maskedTextBox1.KeyDown += new KeyEventHandler(maskedTextBox1_KeyDown);
        }

        void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (maskedTextBox1.MaskFull)
            {
                toolTip1.ToolTipTitle = "Ingreso Rechazado - Demasiados Datos";
                toolTip1.Show("No se pueden ingresar más datos en el campo fecha. Borrar algunos caracteres para ingresar datos.", maskedTextBox1, 0, -20, 5000);
            }
            else if (e.Position == maskedTextBox1.Mask.Length)
            {
                toolTip1.ToolTipTitle = "Ingreso Rechazado - Fin del Campo";
                toolTip1.Show("No se pueden agregar caracteres extras al final de este campo fecha.", maskedTextBox1, 0, -20, 5000);
            }
            else
            {
                toolTip1.ToolTipTitle = "Ingreso Rechazado";
                toolTip1.Show("Se pueden ingresar sólo caracteres numéricos (0-9) en este campo fecha.", maskedTextBox1, 0, -20, 5000);
            }
        }

        void maskedTextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            // El globo informativo es visible por 5 segundos; si el usuario escribe cualquier datos
            // este desaparece por si mismo
            toolTip1.Hide(maskedTextBox1);
        }
    }
}
