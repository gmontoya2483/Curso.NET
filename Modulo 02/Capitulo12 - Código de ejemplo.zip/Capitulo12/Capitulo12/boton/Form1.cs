﻿using System;
using System.Windows.Forms;

namespace boton
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Configurar el boton para que retorne OK cuando se presiona
            boton.DialogResult = DialogResult.OK;
        }

        private void boton_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Se presionó el botón. Resultado: {0}", boton.DialogResult);
        }

        private void btSalir_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
