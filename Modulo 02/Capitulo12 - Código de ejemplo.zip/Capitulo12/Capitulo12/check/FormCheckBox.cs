﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace check
{
    public partial class FormCheckBox : Form
    {

        private Label lbl;
        private Panel pnl;
        private FontStyle[] estilosFonts;

        public FormCheckBox()
        {
            Size = new Size(300, 250);
            this.Text = "Prueba de formatos de letra";

            lbl = new Label();
            lbl.Parent = this;
            lbl.Text = "Texto de verificación";
            lbl.Location = new Point(0, 0);
            lbl.AutoSize = true;
            lbl.BorderStyle = BorderStyle.Fixed3D;
            int yDelta = lbl.Height + 10;

            FontStyle enumeracionFonts = new FontStyle();
            estilosFonts = (FontStyle[])Enum.GetValues(enumeracionFonts.GetType());

            pnl = new Panel();
            pnl.Parent = this;
            pnl.Location = new Point(0, yDelta);
            pnl.Size = new Size(150, (estilosFonts.Length + 1) * yDelta);
            pnl.BorderStyle = BorderStyle.FixedSingle;


            int i = 1;
            CheckBox cb;
            foreach (FontStyle estilo in estilosFonts)
            {
                cb = new CheckBox();
                cb.Parent = pnl;
                cb.Location = new Point(25, (yDelta * (i - 1)) + 10);
                cb.Size = new Size(75, 20);
                cb.Text = estilo.ToString();
                cb.Tag = estilo;
                cb.CheckedChanged += new System.EventHandler(cb_CheckedChanged);
                if (cb.Text == "Regular")
                    cb.Checked = true;
                i++;
            }
        }
        private void cb_CheckedChanged(object sender, EventArgs e)
        {
            FontStyle fs = 0;
            for (int i = 0; i < pnl.Controls.Count; i++)
            {
                CheckBox cb = (CheckBox)pnl.Controls[i];
                if (cb.Checked)
                    fs |= (FontStyle)cb.Tag;

                if (((CheckBox)pnl.Controls[i]).Checked)
                    fs |= (FontStyle)((CheckBox)pnl.Controls[i]).Tag;
            }
            lbl.Font = new Font(lbl.Font, fs);
        }
    }
}
