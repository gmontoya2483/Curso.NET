﻿using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace enriquecido
{
    public partial class Form1 : Form
    {
        // Crear una corriente en memoria en lugar
        // de un archivo en disco para usar con el control.
        private MemoryStream ingresosEnMemoria = new MemoryStream();

        public Form1()
        {
            InitializeComponent();
            CrearUnRichTextBox();
        }

        public void CrearUnRichTextBox()
        {
            RichTextBox rtb = new RichTextBox();
            rtb.Dock = DockStyle.Fill;

            rtb.LoadFile(ingresosEnMemoria, RichTextBoxStreamType.PlainText);
            rtb.Find("Text", RichTextBoxFinds.MatchCase);

            rtb.SelectionFont = new Font("Verdana", 12, FontStyle.Bold);
            rtb.SelectionColor = Color.Red;

            rtb.SaveFile(ingresosEnMemoria, RichTextBoxStreamType.RichText);

            this.Controls.Add(rtb);
        }
    }
}
