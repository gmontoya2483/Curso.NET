﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace impresion
{
    public partial class Form1 : Form
    {
        // Declarar los objetos PrintPreviewControl y PrintDocument.
        internal PrintPreviewControl ppc;
        private System.Drawing.Printing.PrintDocument doc =
            new System.Drawing.Printing.PrintDocument();

        public Form1()
        {
            InitializeComponent();
            InicializarPrintPreviewControl();
        }

        private void InicializarPrintPreviewControl()
        {

            // Construir el PrintPreviewControl.
            this.ppc = new PrintPreviewControl();

            // Configurar el lugar y estilo de anclaje 
            // para el PrintPreviewControl1
            this.ppc.Location = new Point(88, 80);
            this.ppc.Name = "PrintPreviewControl1";
            this.ppc.Dock = DockStyle.Fill;

            // Configurar la propiedad Document de PrintDocument
            // para el cual se debe manejar el evento PrintPage
            this.ppc.Document = doc;

            // Configurar el zoom al 45 porciento.
            this.ppc.Zoom = 0.45;

            // Configurar el nombre del documento. Esto se mostrará
            // cuando el documento se este cargando en el control
            this.ppc.Document.DocumentName = @".\doc\CantoDeBilbo.txt";

            // Configurar la propiedad UseAntiAlias a verdadero
            // para que el SO suavice las fuentes
            this.ppc.UseAntiAlias = true;

            // Agregar el control al formulario
            this.Controls.Add(this.ppc);

            // Asociar el método manejador de evento con
            // el evento PrintPage del documento
            this.doc.PrintPage +=
                new System.Drawing.Printing.PrintPageEventHandler(
                doc_PrintPage);
        }

        // El PrintPreviewControl mostrará en pantalla el
        // documento manejando el evento PrintPage del mismo
        private void doc_PrintPage(
            object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            // Insertar el código que rinde la página en este lugar.
            // Se debe llamar cuando se dibuja el control
            System.Drawing.Font fuenteParaImprimir =
                new Font("Calibri", 25, FontStyle.Regular);

            string path = @".\doc\CantoDeBilbo.txt";
                  
            int contador = 10;
            float largoLetra = fuenteParaImprimir.SizeInPoints;
            int espacio = (int)largoLetra + 5;

            // Usar manejo de recursos para leer el archivo
            // y la codificación de la consola para que se vean
            // los acentos y la ñ
            using (StreamReader sr = new StreamReader(path, 
                Console.OutputEncoding))
            {
                string s = "";
                while ((s = sr.ReadLine()) != null)
                {
                    e.Graphics.DrawString(s, fuenteParaImprimir,
                Brushes.Black, 10, contador);
                    contador += espacio;
                }
            }
        }
    }
}
