﻿using System.Windows.Forms;

namespace pestañas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tab1Button1_Click(object sender, System.EventArgs e)
        {
            MessageBox.Show("Se presionó el botón");
            lbl1.Text = "Hola mundo en la pestaña 1";
        }
     }
}
