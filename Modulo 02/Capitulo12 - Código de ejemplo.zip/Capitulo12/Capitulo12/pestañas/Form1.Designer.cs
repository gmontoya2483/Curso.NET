﻿namespace pestañas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lbl1 = new System.Windows.Forms.Label();
            this.tab1Button1 = new System.Windows.Forms.Button();
            this.tab2CheckBox3 = new System.Windows.Forms.CheckBox();
            this.tab3RadioButton2 = new System.Windows.Forms.RadioButton();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tab2CheckBox2 = new System.Windows.Forms.CheckBox();
            this.tab2CheckBox1 = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tab3RadioButton1 = new System.Windows.Forms.RadioButton();
            this.tabPage1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lbl1);
            this.tabPage1.Controls.Add(this.tab1Button1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(256, 214);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Pestaña 1";
            // 
            // lbl1
            // 
            this.lbl1.Location = new System.Drawing.Point(16, 24);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(224, 96);
            this.lbl1.TabIndex = 1;
            // 
            // tab1Button1
            // 
            this.tab1Button1.Location = new System.Drawing.Point(88, 144);
            this.tab1Button1.Name = "tab1Button1";
            this.tab1Button1.Size = new System.Drawing.Size(80, 40);
            this.tab1Button1.TabIndex = 0;
            this.tab1Button1.Text = "Botón";
            this.tab1Button1.Click += new System.EventHandler(this.tab1Button1_Click);
            // 
            // tab2CheckBox3
            // 
            this.tab2CheckBox3.Location = new System.Drawing.Point(32, 100);
            this.tab2CheckBox3.Name = "tab2CheckBox3";
            this.tab2CheckBox3.Size = new System.Drawing.Size(176, 32);
            this.tab2CheckBox3.TabIndex = 2;
            this.tab2CheckBox3.Text = "Verificar opción 3";
            // 
            // tab3RadioButton2
            // 
            this.tab3RadioButton2.Location = new System.Drawing.Point(40, 72);
            this.tab3RadioButton2.Name = "tab3RadioButton2";
            this.tab3RadioButton2.Size = new System.Drawing.Size(152, 24);
            this.tab3RadioButton2.TabIndex = 1;
            this.tab3RadioButton2.Text = "Opción 2";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(8, 10);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(264, 240);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tab2CheckBox3);
            this.tabPage2.Controls.Add(this.tab2CheckBox2);
            this.tabPage2.Controls.Add(this.tab2CheckBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(256, 214);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Pestaña 2";
            // 
            // tab2CheckBox2
            // 
            this.tab2CheckBox2.Location = new System.Drawing.Point(32, 62);
            this.tab2CheckBox2.Name = "tab2CheckBox2";
            this.tab2CheckBox2.Size = new System.Drawing.Size(176, 32);
            this.tab2CheckBox2.TabIndex = 1;
            this.tab2CheckBox2.Text = "Verificar opción 2";
            // 
            // tab2CheckBox1
            // 
            this.tab2CheckBox1.Location = new System.Drawing.Point(32, 24);
            this.tab2CheckBox1.Name = "tab2CheckBox1";
            this.tab2CheckBox1.Size = new System.Drawing.Size(176, 32);
            this.tab2CheckBox1.TabIndex = 0;
            this.tab2CheckBox1.Text = "Verificar opción 1";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.tab3RadioButton2);
            this.tabPage3.Controls.Add(this.tab3RadioButton1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(256, 214);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Pestaña 3";
            // 
            // tab3RadioButton1
            // 
            this.tab3RadioButton1.Location = new System.Drawing.Point(40, 32);
            this.tab3RadioButton1.Name = "tab3RadioButton1";
            this.tab3RadioButton1.Size = new System.Drawing.Size(152, 24);
            this.tab3RadioButton1.TabIndex = 0;
            this.tab3RadioButton1.Text = "Opción 1";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(284, 262);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Pestañas";
            this.tabPage1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        // Declare variables.
        private System.Windows.Forms.RadioButton tab3RadioButton2;
        private System.Windows.Forms.RadioButton tab3RadioButton1;
        private System.Windows.Forms.CheckBox tab2CheckBox3;
        private System.Windows.Forms.CheckBox tab2CheckBox2;
        private System.Windows.Forms.CheckBox tab2CheckBox1;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Button tab1Button1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl1;
        #endregion
    }
}

