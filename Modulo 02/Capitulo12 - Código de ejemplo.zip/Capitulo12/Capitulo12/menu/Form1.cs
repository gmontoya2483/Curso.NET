﻿using System.Windows.Forms;

namespace menu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CreateMyMenu();
        }

        public void CreateMyMenu()
        {
            // Create an empty MainMenu.
            MainMenu mainMenu1 = new MainMenu();
            MenuItem menuItem0 = new MenuItem();
            MenuItem menuItem1 = new MenuItem();
            MenuItem menuItem2 = new MenuItem();
            MenuItem menuItem3 = new MenuItem();
            MenuItem menuItem4 = new MenuItem();

            // Configurar la etiqueta del menú de alto nivel.
            menuItem0.Text = "Archivo";
            menuItem1.Text = "Edición";
            // Configurar la etiqueta del primer submenú.
            menuItem2.Text = "Tamaño de Fuente";
            // Configurar la etiqueta del hijo del primer submenú.
            menuItem3.Text = "Pequeña";
            // Configurar la propiedad Checked para que se vea el tilde
            menuItem3.Checked = true;
            // Definir una combinación de teclas de acceso
            menuItem3.Shortcut = Shortcut.CtrlS;
            // Configurar la etiqueta del segundo hijo del primer submenú.
            menuItem4.Text = "Grande";
            // Definir una combinación de teclas de acceso
            menuItem4.Shortcut = Shortcut.CtrlL;
            // Configurar el ínidice para determinar ubicación
            menuItem4.Index = 1;
            // Agregar los menus hijos.
            menuItem2.MenuItems.Add(menuItem3);
            menuItem2.MenuItems.Add(menuItem4);
            // Agregar como hijo del primer menu.
            menuItem1.MenuItems.Add(menuItem2);
            // Agregar como hijo del principal
            mainMenu1.MenuItems.Add(menuItem0);
            mainMenu1.MenuItems.Add(menuItem1);
            // Enlazar al formulario
            Menu = mainMenu1;   
        }
    }
}
