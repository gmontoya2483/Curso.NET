﻿using System.Windows.Forms;

namespace lista
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, System.EventArgs e)
        {
            // Crear una instancia del ListBox.
            ListBox lstB = new ListBox();
            // Configurar el tamaño y la localización del ListBox.
            lstB.Size = new System.Drawing.Size(200, 100);
            lstB.Location = new System.Drawing.Point(10, 10);
            // Agregar el ListBox al formulario. 
            this.Controls.Add(lstB);
            // Configurarlo para mostrar múltiples columnas.
            lstB.MultiColumn = true;
            // Configurar el modo de selección como múltiple y extendido.
            lstB.SelectionMode = SelectionMode.MultiExtended;

            // Deterner el dibujo del ListBox mientras se agregan los items.
            lstB.BeginUpdate();
            // Agregar con un ciclo 50 items al ListBox. 
            for (int x = 1; x <= 50; x++)
            {
                lstB.Items.Add("Item " + x.ToString());
            }
            // Permitirle al ListBox redibujarse y mostrar los items
            lstB.EndUpdate();

            // Selecccionar tres items del ListBox.
            lstB.SetSelected(1, true);
            lstB.SetSelected(3, true);
            lstB.SetSelected(5, true);

            // Mostrar por consola el segundo item seleccionado en el ListBox
            System.Diagnostics.Debug.WriteLine(lstB.SelectedItems[1].ToString());
            // Mostrar por consola el índice del primer item seleccionado en el ListBox
            System.Diagnostics.Debug.WriteLine(lstB.SelectedIndices[0].ToString());
        }
    }
}
