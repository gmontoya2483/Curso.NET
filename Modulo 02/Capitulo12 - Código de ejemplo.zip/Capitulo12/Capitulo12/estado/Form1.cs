﻿using System.Windows.Forms;

namespace estado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CrearLaBarraDeEstado();
        }
        private void CrearLaBarraDeEstado()
        {
            // Crear un control StatusBar.
            StatusBar barraDeEstado = new StatusBar();
            // Crear dos objetos StatusBarPanel para mostrar la StatusBar.
            StatusBarPanel panel1 = new StatusBarPanel();
            StatusBarPanel panel2 = new StatusBarPanel();

            // Mostrar en pantalla el primer panel con un estilo 
            // de borde de bajo relieve 
            panel1.BorderStyle = StatusBarPanelBorderStyle.Sunken;

            // Inicializar el texto del panel.
            panel1.Text = "Listo...";

            // Configurar la propiedad AutoSize para usar el espacio restante 
            // en la barra de estado
            panel1.AutoSize = StatusBarPanelAutoSize.Spring;

            // Mostrar el segundo panel con un estilo de borde elevado 
            panel2.BorderStyle = StatusBarPanelBorderStyle.Raised;

            // Crear un texto de ToolTip que muestre el horario en el
            // cuál arrancó la aplicación.
            panel2.ToolTipText = "Iniciada: " + System.DateTime.Now.ToShortTimeString();

            // Configurar el texto del panel a la fecha actual.
            panel2.Text = System.DateTime.Today.ToLongDateString();

            // Configurar la propiedad AutoSize para ajustar el tamaño
            // del panel al contenido
            panel2.AutoSize = StatusBarPanelAutoSize.Contents;

            // Mostrar el panel en el control StatusBar
            barraDeEstado.ShowPanels = true;

 			// Agregar ambos paneles  al StatusBarPanelCollection del StatusBar.
            barraDeEstado.Panels.Add(panel1);
            barraDeEstado.Panels.Add(panel2);

            // Agregar el StatusBar al formulario.
            this.Controls.Add(barraDeEstado);
        }
    }
}
