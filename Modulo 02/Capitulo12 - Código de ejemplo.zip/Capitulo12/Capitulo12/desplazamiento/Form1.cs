﻿using System.Windows.Forms;

namespace desplazamiento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            AgregarBarraDeDesplazamiento();
        }

        private void AgregarBarraDeDesplazamiento()
        {
            // Crear e inicializar un VScrollBar.
            VScrollBar vScrollBar1 = new VScrollBar();

            // Ajustar al lado derecho del formulario.
            vScrollBar1.Dock = DockStyle.Right;

            // Agregar la barra al formulario.
            Controls.Add(vScrollBar1);
        }
    }
}
