﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace cursores
{
    public partial class Cursores : Form
    {
        public Cursores()
        {
            InitializeComponent();
            // Agregar todos los tipos de cursores al combobox. 
            foreach (Cursor cursor in ListaDeCursores())
            {
                cbSeleccionDeCursor.Items.Add(cursor);
            }

        }

        private Cursor[] ListaDeCursores()
        {

            // Crear un vector con todos los tipos de cursores en Windows Forms.
            return new Cursor[] {
                Cursors.AppStarting, Cursors.Arrow, Cursors.Cross,
                Cursors.Default, Cursors.Hand, Cursors.Help,
                Cursors.HSplit, Cursors.IBeam, Cursors.No,
                Cursors.NoMove2D, Cursors.NoMoveHoriz, Cursors.NoMoveVert,
                Cursors.PanEast, Cursors.PanNE, Cursors.PanNorth,
                Cursors.PanNW, Cursors.PanSE, Cursors.PanSouth,
                Cursors.PanSW, Cursors.PanWest, Cursors.SizeAll,
                Cursors.SizeNESW, Cursors.SizeNS, Cursors.SizeNWSE,
                Cursors.SizeWE, Cursors.UpArrow, Cursors.VSplit, Cursors.WaitCursor};

        }

        private void cursorSelectionComboBox_SelectedIndexChanged(
            object sender, System.EventArgs e)
        {
            // Configurar el cursor en el panel de verificación para que
            // tenga el estilo de cursor seleccionado
            panDeVerificacion.Cursor = (Cursor)cbSeleccionDeCursor.SelectedItem;
        }

        private void panDeVerificacion_CursorChanged(object sender, System.EventArgs e)
        {
            // Construir una cadena con el tipo de objeto donde 
            // cambia el cursor recibido y el evento
            string eventoDeCursor = string.Format("[{0}]: {1}", 
                sender.GetType().ToString(), "El Cursor cambió");

            // Registrar este evento en el visor de la lista de eventos
            this.lstvDeEventosDeCursor.Items.Add(eventoDeCursor);
        }
    }
}
