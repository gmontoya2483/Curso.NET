﻿namespace cursores
{
    partial class Cursores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbSeleccionDeCursor = new System.Windows.Forms.ComboBox();
            this.panDeVerificacion = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lstvDeEventosDeCursor = new System.Windows.Forms.ListView();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cbSeleccionDeCursor
            // 
            this.cbSeleccionDeCursor.Location = new System.Drawing.Point(24, 40);
            this.cbSeleccionDeCursor.Name = "cbSeleccionDeCursor";
            this.cbSeleccionDeCursor.Size = new System.Drawing.Size(152, 21);
            this.cbSeleccionDeCursor.TabIndex = 0;
            this.cbSeleccionDeCursor.SelectedIndexChanged += new System.EventHandler(this.cursorSelectionComboBox_SelectedIndexChanged);
            // 
            // panDeVerificacion
            // 
            this.panDeVerificacion.BackColor = System.Drawing.SystemColors.ControlDark;
            this.panDeVerificacion.Location = new System.Drawing.Point(24, 104);
            this.panDeVerificacion.Name = "panDeVerificacion";
            this.panDeVerificacion.Size = new System.Drawing.Size(152, 160);
            this.panDeVerificacion.TabIndex = 7;
            this.panDeVerificacion.CursorChanged += new System.EventHandler(this.panDeVerificacion_CursorChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(24, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 23);
            this.label1.TabIndex = 6;
            this.label1.Text = "Panel para verificar el cursor:";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(24, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "Selecccionar un cursor:";
            // 
            // lstvDeEventosDeCursor
            // 
            this.lstvDeEventosDeCursor.Location = new System.Drawing.Point(184, 40);
            this.lstvDeEventosDeCursor.Name = "lstvDeEventosDeCursor";
            this.lstvDeEventosDeCursor.Size = new System.Drawing.Size(256, 224);
            this.lstvDeEventosDeCursor.TabIndex = 4;
            this.lstvDeEventosDeCursor.UseCompatibleStateImageBehavior = false;
            this.lstvDeEventosDeCursor.View = System.Windows.Forms.View.List;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(184, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(217, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Eventos de cambio de cursor en:";
            // 
            // Cursores
            // 
            this.ClientSize = new System.Drawing.Size(456, 286);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lstvDeEventosDeCursor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panDeVerificacion);
            this.Controls.Add(this.cbSeleccionDeCursor);
            this.Name = "Cursores";
            this.Text = "Ejemplo De Cursores";
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.ComboBox cbSeleccionDeCursor;

        private System.Windows.Forms.Panel panDeVerificacion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lstvDeEventosDeCursor;
        private System.Windows.Forms.Label label3;
        #endregion
    }
}

