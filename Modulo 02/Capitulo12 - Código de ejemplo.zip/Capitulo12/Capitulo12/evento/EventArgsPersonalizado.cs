﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace evento
{
    public class EventArgsPersonalizado : EventArgs
    {
        private string _mensaje;

        public EventArgsPersonalizado(string s)
        {
            _mensaje = s;
        }

        public string Mensaje
        {
            get { return _mensaje; }
            set { _mensaje = value; }
        }
    }
}
