﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace evento
{
    class Suscriptor
    {
        private string id;
        public Suscriptor(string ID, Publicador pub)
        {
            id = ID;
            // Suscribirse al evento
            pub.GenerarEventoPersonalizado += ManejarEventoPersonalizado;
        }

        // Definir las acciones a tomar cuando se genere el evento.
        void ManejarEventoPersonalizado(object sender, EventArgsPersonalizado e)
        {
            Console.WriteLine(id + " recibió este mensaje: {0}", e.Mensaje);
        }
    }
}
