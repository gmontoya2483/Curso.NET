﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace evento
{
    public class Publicador
    {

        // Declarar el evento usando EventHandler<T>
        public event EventHandler<EventArgsPersonalizado> GenerarEventoPersonalizado;

        public void HacerAlgo()
        {
            // Escribir código que haga algo aqui y luego genere
            // el evento. También se puede generar el evento
            // antes de ejecutar código alguno.
            OnGenerarEventoPersonalizado(new EventArgsPersonalizado("Hizo algo"));

        }

        // Encapsular las invocaciones del evento dentro de un método
        // protegido virtual para permitir a las clases derivadas rescribir
        // el comportamiento de invocación del evento
        protected virtual void OnGenerarEventoPersonalizado(EventArgsPersonalizado e)
        {
             // Realizar una copia temporal del evento para evitar la posibilidad
            // de un "race condition" si el último suscriptor se baja 
            // inmediatamente después de verificar el null y antes que se
            // genere el evento
            EventHandler<EventArgsPersonalizado> manejador = GenerarEventoPersonalizado;

            // El evento será nulo si no hay suscriptores
            if (manejador != null)
            {
                // Formatear la cadena a enviar dentro del 
                // parámetro EventArgsPersonalizado
                e.Mensaje += String.Format(" el {0}", DateTime.Now.ToString());

                // Usar el operador () para generar el evento.
                manejador(this, e);
            }
        }
    }
}
