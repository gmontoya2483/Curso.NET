﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace evento
{
    class Program
    {
        static void Main(string[] args)
        {
            Publicador pub = new Publicador();
            Suscriptor suscriptor1 = new Suscriptor("suscriptor1", pub);
            Suscriptor suscriptor2 = new Suscriptor("suscriptor2", pub);

            // Llamar al método que genera el evento.
            pub.HacerAlgo();

            // Mantener abierta la ventana de consola.
            Console.WriteLine("Presionar Enter para cerrar esta ventana.");
            Console.ReadLine();
        }
    }
}
