﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace tiempos
{
    public partial class Form1 : Form
    {
        private Label lblTime;
        private string strFormat;

        public Form1()
        {
            InitializeComponent();
            Size = new Size(300, 100);

            strFormat = "dddd, MMMM d, yyyy  h:mm:ss tt";

            lblTime = new Label();
            lblTime.Parent = this;
            lblTime.Size = new Size((int)(ClientSize.Width * .8), 25);
            lblTime.Location = new Point((int)(ClientSize.Width * .1),
                        (int)(ClientSize.Height * .4));
            lblTime.BorderStyle = BorderStyle.FixedSingle;
            lblTime.Text = DateTime.Now.ToString(strFormat);
            lblTime.TextAlign = ContentAlignment.MiddleCenter;

            Timer t = new Timer();
            t.Interval = 1000;    // 1 segundo
            t.Start();
            t.Tick += new EventHandler(t_Tick);
        }

        private void t_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToString(strFormat);
        }
    }
}
