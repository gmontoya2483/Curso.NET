﻿using System;
using System.Windows.Forms;

namespace modal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Show();
            FrmAcercaDe frm = new FrmAcercaDe();
            frm.ShowDialog(this);
            frm.Text = "Este Formulario Es Modal!!";
            Console.WriteLine("Resultado: {0}", frm.DialogResult);
        }
    }
}
