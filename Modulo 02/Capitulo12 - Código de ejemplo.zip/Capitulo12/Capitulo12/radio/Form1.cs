﻿using System;
using System.Windows.Forms;

namespace radio
{
    public partial class Form1 : Form
    {
        string claseDeTicket;

        public Form1()
        {
            InitializeComponent();
        }
        private void botonOk_Click(object sender, EventArgs e)
        {
            MessageBox.Show(claseDeTicket);
        }

        private void CambioDelTipoDeTicket(object sender, EventArgs e)
        {
            RadioButton button = (RadioButton)sender;
            if (button.Checked)
                claseDeTicket = button.Text;
        }
    }
}
