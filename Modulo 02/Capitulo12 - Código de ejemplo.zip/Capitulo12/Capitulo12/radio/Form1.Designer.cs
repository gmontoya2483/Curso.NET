﻿namespace radio
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.botonOk = new System.Windows.Forms.Button();
            this.radioPrimera = new System.Windows.Forms.RadioButton();
            this.radioBusinessSuperior = new System.Windows.Forms.RadioButton();
            this.radioBusiness = new System.Windows.Forms.RadioButton();
            this.radioPremium = new System.Windows.Forms.RadioButton();
            this.radioEconomico = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // botonOk
            // 
            this.botonOk.Location = new System.Drawing.Point(209, 195);
            this.botonOk.Name = "botonOk";
            this.botonOk.Size = new System.Drawing.Size(75, 23);
            this.botonOk.TabIndex = 20;
            this.botonOk.Text = "OK";
            this.botonOk.Click += new System.EventHandler(this.botonOk_Click);
            // 
            // radioPrimera
            // 
            this.radioPrimera.AutoSize = true;
            this.radioPrimera.Location = new System.Drawing.Point(43, 140);
            this.radioPrimera.Name = "radioPrimera";
            this.radioPrimera.Size = new System.Drawing.Size(89, 17);
            this.radioPrimera.TabIndex = 19;
            this.radioPrimera.Text = "Primera Clase";
            this.radioPrimera.CheckedChanged += new System.EventHandler(this.CambioDelTipoDeTicket);
            // 
            // radioBusinessSuperior
            // 
            this.radioBusinessSuperior.AutoSize = true;
            this.radioBusinessSuperior.Location = new System.Drawing.Point(43, 116);
            this.radioBusinessSuperior.Name = "radioBusinessSuperior";
            this.radioBusinessSuperior.Size = new System.Drawing.Size(138, 17);
            this.radioBusinessSuperior.TabIndex = 18;
            this.radioBusinessSuperior.Text = "Clase Business Superior";
            this.radioBusinessSuperior.CheckedChanged += new System.EventHandler(this.CambioDelTipoDeTicket);
            // 
            // radioBusiness
            // 
            this.radioBusiness.AutoSize = true;
            this.radioBusiness.Location = new System.Drawing.Point(43, 93);
            this.radioBusiness.Name = "radioBusiness";
            this.radioBusiness.Size = new System.Drawing.Size(96, 17);
            this.radioBusiness.TabIndex = 17;
            this.radioBusiness.Text = "Clase Business";
            this.radioBusiness.CheckedChanged += new System.EventHandler(this.CambioDelTipoDeTicket);
            // 
            // radioPremium
            // 
            this.radioPremium.AutoSize = true;
            this.radioPremium.Location = new System.Drawing.Point(43, 69);
            this.radioPremium.Name = "radioPremium";
            this.radioPremium.Size = new System.Drawing.Size(121, 17);
            this.radioPremium.TabIndex = 16;
            this.radioPremium.Text = "Económico Premium";
            this.radioPremium.CheckedChanged += new System.EventHandler(this.CambioDelTipoDeTicket);
            // 
            // radioEconomico
            // 
            this.radioEconomico.AutoSize = true;
            this.radioEconomico.Location = new System.Drawing.Point(43, 45);
            this.radioEconomico.Name = "radioEconomico";
            this.radioEconomico.Size = new System.Drawing.Size(78, 17);
            this.radioEconomico.TabIndex = 15;
            this.radioEconomico.Text = "Económico";
            this.radioEconomico.CheckedChanged += new System.EventHandler(this.CambioDelTipoDeTicket);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Elegir el tipo de Pasaje";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 227);
            this.Controls.Add(this.botonOk);
            this.Controls.Add(this.radioPrimera);
            this.Controls.Add(this.radioBusinessSuperior);
            this.Controls.Add(this.radioBusiness);
            this.Controls.Add(this.radioPremium);
            this.Controls.Add(this.radioEconomico);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Reservas de Vuelo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button botonOk;
        private System.Windows.Forms.RadioButton radioPrimera;
        private System.Windows.Forms.RadioButton radioBusinessSuperior;
        private System.Windows.Forms.RadioButton radioBusiness;
        private System.Windows.Forms.RadioButton radioPremium;
        private System.Windows.Forms.RadioButton radioEconomico;
        private System.Windows.Forms.Label label1;
    }
}

