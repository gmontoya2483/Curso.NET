﻿using System;
using System.Windows.Forms;

namespace herramientas
{
    public partial class Form1 : Form
    {
        private ToolBar toolBar1 = new ToolBar();
        public Form1()
        {
            InitializeComponent(); 
            CrearLaBarrra();
        }

        public void CrearLaBarrra()
        {
            ToolBarButton tbb1 = new ToolBarButton();
            ToolBarButton tbb2 = new ToolBarButton();
            ToolBarButton tbb3 = new ToolBarButton();

            // Configurar el texto de los controles ToolBarButton.
            tbb1.Text = "Abrir";
            tbb2.Text = "Guardar";
            tbb3.Text = "Imprimir";

            // Agregar los controles ToolBarButton al ToolBar.
            toolBar1.Buttons.Add(tbb1);
            toolBar1.Buttons.Add(tbb2);
            toolBar1.Buttons.Add(tbb3);

            // Agregar el manejador del evento
            toolBar1.ButtonClick += new ToolBarButtonClickEventHandler(
               this.toolBar1_ButtonClick);

            // Agregar la barra de herramientas al formulario
            this.Controls.Add(toolBar1);
        }

        private void toolBar1_ButtonClick(
                                Object sender,
                                ToolBarButtonClickEventArgs e)
        {
            OpenFileDialog cuadroDeDialogoAbrir = new OpenFileDialog();
            SaveFileDialog cuadroDeDialogoGuardar = new SaveFileDialog();
            PrintDialog cuadroDeDialogoImprimir = new PrintDialog();
            // Evaluar la propiedad Button para determinar qué botón de presionó. 
            switch (toolBar1.Buttons.IndexOf(e.Button))
            {
                case 0:
                    cuadroDeDialogoAbrir.ShowDialog();
                    // Insertar código de apertura de archivo. 
                    break;
                case 1:
                    cuadroDeDialogoGuardar.ShowDialog();
                    // Insertar código de salvado de archivo.  
                    break;
                case 2:
                    cuadroDeDialogoImprimir.ShowDialog();
                    // Insertar código de impresión de archivo.      
                    break;
            }
        }
    }
}
