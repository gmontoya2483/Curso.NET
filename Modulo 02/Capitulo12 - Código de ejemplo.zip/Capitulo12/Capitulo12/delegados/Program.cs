﻿using System;

namespace delegados
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear una nueva lista.
            ListaConEventosDeCambios lista = new ListaConEventosDeCambios();

            // Crear una clase que "escuche" los eventos de cambio de la lista
            OyenteDeEvento oyente = new OyenteDeEvento(lista);

            // Agregar elementos a la lista.
            Console.WriteLine("Agregando un item");
            lista.Add("item 1");
            // Agregar otro elemento a la lista.
            Console.WriteLine("Agregando un item");
            lista.Add("item 2");
            //Limpiar la lista
            lista.Clear();
 
            Console.ReadKey();
        }
    }
}
