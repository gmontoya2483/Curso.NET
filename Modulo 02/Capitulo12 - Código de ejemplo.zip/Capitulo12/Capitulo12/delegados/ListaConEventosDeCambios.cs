﻿using System;

namespace delegados
{
    using System.Collections;

    // Un tipo delegate para almacenar las notificaciones de cambio
    public delegate void ManejadorEventosCambiados(object sender, EventArgs e);

    // Una clase que funciona como un ArrayList, pero envia 
    // notificaciones de eventos cada vez que cambia la lista
    public class ListaConEventosDeCambios : ArrayList
    {
        // Un evento que los clientes pueden usar para notificarse
        // cuando los elementos de la lista cambian
        public event ManejadorEventosCambiados Cambiado;

        // Invocar al evento Cambiado. Llamarlo cada vez que cambie la lista
        protected virtual void OnCambiado(EventArgs e)
        {
            if (Cambiado != null)
                Cambiado(this, e);
        }

        // Sobrescribir algunos de los métodos que cambian la lista.
        // Invocar el evento al final de cada uno
        public override int Add(object valor)
        {
            int i = base.Add(valor);
            OnCambiado(EventArgs.Empty);
            return i;
        }

        public override void Clear()
        {
            base.Clear();
            Console.WriteLine("Se limpia la lista. Implica que cambia");
            OnCambiado(EventArgs.Empty);
        }


    }

}
