﻿using System;

namespace delegados
{
    class OyenteDeEvento
    {
        private ListaConEventosDeCambios _lista;

        // Construir la instancia con la referencia al objeto
        // que tiene declarado el evento que se quiere suscribir
        public OyenteDeEvento(ListaConEventosDeCambios lista)
        {
            _lista = lista;
            // Agregar "ListaCambiada" al evento Cambiado en "Lista".
            _lista.Cambiado += new ManejadorEventosCambiados(ListaCambiada);
        }

        // Este método se llama cuando cambia la lista.
        private void ListaCambiada(object sender, EventArgs e)
        {
            Console.WriteLine("Esto se llama cuando se dispara el evento.");
        }
    }

}
