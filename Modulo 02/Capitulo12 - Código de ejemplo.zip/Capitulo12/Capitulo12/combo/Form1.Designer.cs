﻿namespace combo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.botonMostrarSeleccion = new System.Windows.Forms.Button();
            this.botonBuscar = new System.Windows.Forms.Button();
            this.botonAgregarMuchos = new System.Windows.Forms.Button();
            this.botonAgregar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox1.DropDownWidth = 280;
            this.comboBox1.Items.AddRange(new object[] {
            "Item 1",
            "Item 2",
            "Item 3",
            "Item 4",
            "Item 5"});
            this.comboBox1.Location = new System.Drawing.Point(6, 234);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(307, 21);
            this.comboBox1.TabIndex = 15;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(6, 50);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(232, 20);
            this.textBox2.TabIndex = 14;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 18);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(232, 20);
            this.textBox1.TabIndex = 13;
            // 
            // botonMostrarSeleccion
            // 
            this.botonMostrarSeleccion.Location = new System.Drawing.Point(6, 114);
            this.botonMostrarSeleccion.Name = "botonMostrarSeleccion";
            this.botonMostrarSeleccion.Size = new System.Drawing.Size(301, 24);
            this.botonMostrarSeleccion.TabIndex = 12;
            this.botonMostrarSeleccion.Text = "¿Qué Item se Seleccionó?";
            this.botonMostrarSeleccion.Click += new System.EventHandler(this.botonMostrarSeleccion_Click);
            // 
            // botonBuscar
            // 
            this.botonBuscar.Location = new System.Drawing.Point(246, 50);
            this.botonBuscar.Name = "botonBuscar";
            this.botonBuscar.Size = new System.Drawing.Size(61, 24);
            this.botonBuscar.TabIndex = 11;
            this.botonBuscar.Text = "Buscar";
            this.botonBuscar.Click += new System.EventHandler(this.botonBuscar_Click);
            // 
            // botonAgregarMuchos
            // 
            this.botonAgregarMuchos.Location = new System.Drawing.Point(6, 82);
            this.botonAgregarMuchos.Name = "botonAgregarMuchos";
            this.botonAgregarMuchos.Size = new System.Drawing.Size(301, 23);
            this.botonAgregarMuchos.TabIndex = 10;
            this.botonAgregarMuchos.Text = "Agregar 100 Items";
            this.botonAgregarMuchos.Click += new System.EventHandler(this.botonAgregarMuchos_Click);
            // 
            // botonAgregar
            // 
            this.botonAgregar.Location = new System.Drawing.Point(246, 18);
            this.botonAgregar.Name = "botonAgregar";
            this.botonAgregar.Size = new System.Drawing.Size(61, 24);
            this.botonAgregar.TabIndex = 9;
            this.botonAgregar.Text = "Agregar";
            this.botonAgregar.Click += new System.EventHandler(this.botonAgregar_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(6, 210);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 23);
            this.label1.TabIndex = 8;
            this.label1.Text = "Test ComboBox";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(319, 273);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.botonMostrarSeleccion);
            this.Controls.Add(this.botonBuscar);
            this.Controls.Add(this.botonAgregarMuchos);
            this.Controls.Add(this.botonAgregar);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Ejemplo de ComboBox";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.ComboBox comboBox1;
        internal System.Windows.Forms.TextBox textBox2;
        internal System.Windows.Forms.TextBox textBox1;
        internal System.Windows.Forms.Button botonMostrarSeleccion;
        internal System.Windows.Forms.Button botonBuscar;
        internal System.Windows.Forms.Button botonAgregarMuchos;
        internal System.Windows.Forms.Button botonAgregar;
        internal System.Windows.Forms.Label label1;
    }
}

