﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace eventos
{
    public partial class Eventos : Form
    {
        EventHandler handlerGotFocus;
        EventHandler handlerLostFocus;
        EventHandler auxHandlerGotFocus;
        EventHandler auxHandlerLostFocus;

        public Eventos()
        {
            InitializeComponent();
            TextBoxIngreso.MouseWheel +=
                new MouseEventHandler(TextBoxDeIngresos_MouseWheel);

            TextBoxIngreso.GotFocus += handlerGotFocus;
            TextBoxIngreso.LostFocus += handlerLostFocus;
            handlerGotFocus = new EventHandler(TextBoxDeIngresos_GotFocus);
            handlerLostFocus = new EventHandler(TextBoxDeIngresos_LostFocus);
            auxHandlerGotFocus = handlerGotFocus;
            auxHandlerLostFocus = handlerLostFocus;
            VerificarTodosLosCheckBoxesHijos(this, true);

        }

        // Buscar recursivamente en el formulario para todos los checkboxes
        // contenidos e inicializarlos como check
        private void VerificarTodosLosCheckBoxesHijos(Control padre, bool valor)
        {
            CheckBox cBox;
            foreach (Control controlActual in padre.Controls)
            {
                if (controlActual is CheckBox)
                {
                    cBox = (CheckBox)controlActual;
                    cBox.Checked = valor;
                }

                // Buscar recursivamente si el control contiene otros controles
                if (controlActual.Controls.Count > 0)
                {
                    VerificarTodosLosCheckBoxesHijos(controlActual, valor);
                }
            }
        }

        // Métodos de propósito general para mostrar una línea de texto
        // en el text Box que muestra eventos
        private void MostrarLinea(string linea)
        {
            TextBoxSalida.AppendText(linea);
            TextBoxSalida.AppendText(Environment.NewLine);
        }

        // Manejador de eventos para el clic del botón que limpia el TextBox de salidas de eventos
        private void BotonLimpiar_Click(object sender, EventArgs e)
        {
            TextBoxSalida.Invalidate();
            TextBoxSalida.Clear();
        }

        private void TextBoxDeIngresos_KeyDown(object sender, KeyEventArgs e)
        {
            if (CheckBoxTeclado.Checked)
            {
                if (CheckBoxTeclaArribaAbajo.Checked)
                {
                    MostrarLinea("Evento: KeyDown. Presionar Tecla: " + e.KeyData.ToString());
                }
            }
        }

        private void TextBoxDeIngresos_KeyUp(object sender, KeyEventArgs e)
        {
            if (CheckBoxTeclado.Checked)
            {
                if (CheckBoxTeclaArribaAbajo.Checked)
                {
                    MostrarLinea("Evento: KeyUp .Soltar Tecla: " + e.KeyData.ToString());
                }
            }
        }

        private void TextBoxDeIngresos_KeyPress(object sender,
            KeyPressEventArgs e)
        {
            if (CheckBoxTeclado.Checked)
            {
                if (Char.IsWhiteSpace(e.KeyChar))
                {
                    MostrarLinea("Evento: KeyPress. Tecla Presionada: Espacio en Blanco");
                }
                else
                {
                    MostrarLinea("Evento: KeyPress. Tecla Presionada: " + e.KeyChar.ToString());
                }
            }
        }

        private void TextBoxDeIngresos_Click(object sender, EventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                MostrarLinea("Evento: Click");
            }
        }

        private void TextBoxDeIngresos_DoubleClick(object sender, EventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                MostrarLinea("Evento: DoubleClick. Doble clic en tecla izquierda");
            }
        }

        private void TextBoxDeIngresos_MouseClick(object sender, MouseEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                MostrarLinea("Evento: MouseClick. Clic en tecla izquierda: " + e.Button.ToString() +
                        " " + e.Location.ToString());
            }
        }

        private void TextBoxDeIngresos_MouseDoubleClick(object sender,
            MouseEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                MostrarLinea("Evento: MouseDoubleClick. Doble clic en el mouse: " + e.Button.ToString() +
                        " " + e.Location.ToString());
            }
        }

        private void TextBoxDeIngresos_MouseDown(object sender,
            MouseEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                MostrarLinea("Evento: MouseDown. Presionar tecla del mouse: " + e.Button.ToString() +
                        " " + e.Location.ToString());
            }
        }

        private void TextBoxDeIngresos_MouseUp(object sender,
            MouseEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                MostrarLinea("MouseUp: Soltar tecla del mouse: " + e.Button.ToString() +
                        " " + e.Location.ToString());
            }

            // El control del TextBox fue diseñado para cambiar el foco sólo
            // en clic primario (botón izquierdo), de manera que se fuerza el foco
            // para evitar que el usuario se confunda
            if (!TextBoxIngreso.Focused)
            {
                TextBoxIngreso.Focus();
            }
        }

        private void TextBoxDeIngresos_MouseEnter(object sender, EventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxMouseIngreso.Checked)
                {
                    MostrarLinea("Evento: MouseEnter. Ingreso del Mouse");
                }
            }
        }

        private void TextBoxDeIngresos_MouseHover(object sender, EventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxMouseIngreso.Checked)
                {
                    MostrarLinea("Evento: MouseHover. Sobrevuelo del Mouse e Inmovilidad");
                }
            }
        }

        private void TextBoxDeIngresos_MouseLeave(object sender, EventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxMouseIngreso.Checked)
                {
                    MostrarLinea("Evento: MouseLeave. Salida del Mouse");
                }
            }
        }

        private void TextBoxDeIngresos_MouseWheel(object sender,
            MouseEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                MostrarLinea("Evento: MouseWheel. Rueda del Mouse: " + e.Delta.ToString() +
                        " detenida en " + e.Location.ToString());
            }
        }

        private void TextBoxDeIngresos_MouseMove(object sender,
            MouseEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxMovimientoMouse.Checked)
                {
                    MostrarLinea("Evento: MouseMove. Movimieno del Mouse: " + e.Button.ToString() + " " +
                            e.Location.ToString());
                }

                if (CheckBoxPuntosDelMouse.Checked)
                {
                    Graphics g = TextBoxIngreso.CreateGraphics();
                    g.FillRectangle(Brushes.Black, e.Location.X,
                        e.Location.Y, 1, 1);
                    g.Dispose();
                }
            }
        }

        private void TextBoxDeIngresos_MouseCaptureChanged(object sender,
            EventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxMouseDrag.Checked)
                {
                    MostrarLinea("Evento: MouseCaptureChanged");
                }
            }
        }

        private void TextBoxDeIngresos_DragEnter(object sender,
            DragEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxMouseDrag.Checked)
                {
                    Point pt = new Point(e.X, e.Y);
                    MostrarLinea("Evento: DragEnter. Ingreso Arrastrando: " +
                        ConvertirEstadoTeclaAString(e.KeyState)
                        + " en " + pt.ToString());
                }
            }
        }

        private void TextBoxDeIngresos_DragDrop(object sender,
            DragEventArgs e)
        {

            if (CheckBoxMouse.Checked)
            {
                Object item = (object)e.Data.GetData(typeof(System.String));
                TextBoxIngreso.Text = item.ToString();
                if (CheckBoxMouseDrag.Checked)
                {
                    Point pt = new Point(e.X, e.Y);
                    MostrarLinea("Evento: DragDrop. Soltar arrastre: " +
                        ConvertirEstadoTeclaAString(e.KeyState)
                        + " en " + pt.ToString());
                }
            }
        }

        private void TextBoxDeIngresos_DragOver(object sender,
            DragEventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxDesplazamientoMouseDrag.Checked)
                {
                    Point pt = new Point(e.X, e.Y);
                    MostrarLinea("Evento: DragOver. Arrastrando sobre: " +
                        ConvertirEstadoTeclaAString(e.KeyState)
                        + " en " + pt.ToString());
                }

                // Permitir si el tipo de datos arrojado es string.
                if (!e.Data.GetDataPresent(typeof(String)))
                {
                    e.Effect = DragDropEffects.None;
                }
                else
                {
                    e.Effect = DragDropEffects.Copy;
                }
            }
        }

        private void TextBoxDeIngresos_DragLeave(object sender,
            EventArgs e)
        {
            if (CheckBoxMouse.Checked)
            {
                if (CheckBoxMouseDrag.Checked)
                {
                    MostrarLinea("Evento salir arrastrando: DragLeave");
                }
            }
        }

        private string ConvertirEstadoTeclaAString(int estadoTecla)
        {
            string stringDeEstado = "Ninguno";

            // ¿Qué botón se presionó?
            if ((estadoTecla & 1) == 1)
            {
                stringDeEstado = "Izquierdo";
            }
            else if ((estadoTecla & 2) == 2)
            {
                stringDeEstado = "Derecho";
            }
            else if ((estadoTecla & 16) == 16)
            {
                stringDeEstado = "Medio";
            }

            // ¿Se presionó también una o más teclas modificadoras? 
            if ((estadoTecla & 4) == 4)
            {
                stringDeEstado += "+SHIFT";
            }

            if ((estadoTecla & 8) == 8)
            {
                stringDeEstado += "+CTRL";
            }

            if ((estadoTecla & 32) == 32)
            {
                stringDeEstado += "+ALT";
            }

            return stringDeEstado;
        }

        private void TextBoxDeIngresos_Enter(object sender, EventArgs e)
        {
            if (CheckBoxFoco.Checked)
            {
                MostrarLinea("Evento de ingreso: Enter");
            }
        }

        private void TextBoxDeIngresos_Leave(object sender, EventArgs e)
        {
            if (CheckBoxFoco.Checked)
            {
                MostrarLinea("Evento de salida: Leave");
            }
        }

        private void TextBoxDeIngresos_GotFocus(object sender, EventArgs e)
        {
            if (CheckBoxFoco.Checked)
            {
                MostrarLinea("Evento: GotFocus. Obtener el foco");
            }
        }

        private void TextBoxDeIngresos_LostFocus(object sender, EventArgs e)
        {
            if (CheckBoxFoco.Checked)
            {
                MostrarLinea("Evento: LostFocus. Perder el foco");
            }
        }

        private void TextBoxDeIngresos_Validated(object sender, EventArgs e)
        {
            if (CheckBoxValidar.Checked)
            {
                MostrarLinea("Evento: Validated. Validado");
            }
        }

        private void TextBoxDeIngresos_Validating(
            object sender, CancelEventArgs e)
        {
            if (CheckBoxValidar.Checked)
            {
                MostrarLinea("Evento Validating. Validando");
            }
        }

        private void CheckBoxSeleccionarTodo_CheckedChanged(
            object sender, EventArgs e)
        {
            if (sender is CheckBox)
            {
                VerificarTodosLosCheckBoxesHijos(this, ((CheckBox)sender).Checked);
            }
        }

        private void CheckBoxMouse_CheckedChanged(
            object sender, EventArgs e)
        {
            ConfigurarAsignacionesDeCheckBox();
        }

        private void CheckBoxArrastrarMouse_CheckedChanged(
            object sender, EventArgs e)
        {
            ConfigurarAsignacionesDeCheckBox();
        }

        private void CheckBoxTeclado_CheckedChanged(
            object sender, EventArgs e)
        {
            ConfigurarAsignacionesDeCheckBox();
        }

        private void CheckBoxMovimientoDelMouse_CheckedChanged(
            object sender, EventArgs e)
        {
            ConfigurarAsignacionesDeCheckBox();
        }

        // Compaginar dependencias entre la elecciones
        // seleccionadas en los check box
        private void ConfigurarAsignacionesDeCheckBox()
        {
            // CheckBoxMouse es un check box de mayor nivel.
            if (!CheckBoxMouse.Checked)
            {
                CheckBoxMouseIngreso.Enabled = false;
                CheckBoxMovimientoMouse.Enabled = false;
                CheckBoxMouseDrag.Enabled = false;
                CheckBoxDesplazamientoMouseDrag.Enabled = false;
                CheckBoxPuntosDelMouse.Enabled = false;
            }
            else
            {
                CheckBoxMouseIngreso.Enabled = true;
                CheckBoxMovimientoMouse.Enabled = true;
                CheckBoxMouseDrag.Enabled = true;
                CheckBoxPuntosDelMouse.Enabled = true;

                // Activar dependencias de los hijos acorde al estado del padre
                if (!CheckBoxMouseDrag.Checked)
                {
                    CheckBoxDesplazamientoMouseDrag.Enabled = false;
                }
                else
                {
                    CheckBoxDesplazamientoMouseDrag.Enabled = true;
                }
            }

            if (!CheckBoxTeclado.Checked)
            {
                CheckBoxTeclaArribaAbajo.Enabled = false;
            }
            else
            {
                CheckBoxTeclaArribaAbajo.Enabled = true;
            }
            TextBoxIngreso.Text = "";
        }

        private void ArrastrarEtiquetaEnlazada_MouseDown(object sender,
            MouseEventArgs e)
        {
            string data = "Datos de ejemplo";
            ArrastrarEtiquetaEnlazada.DoDragDrop(data, DragDropEffects.All);
        }

        private void ArrastrarEtiquetaEnlazada_GiveFeedback(object sender,
            GiveFeedbackEventArgs e)
        {
            if ((e.Effect & DragDropEffects.Copy) ==
                DragDropEffects.Copy)
            {
                ArrastrarEtiquetaEnlazada.Cursor = Cursors.HSplit;

            }
            else
            {
                ArrastrarEtiquetaEnlazada.Cursor = Cursors.Default;
            }
        }

        private void Eventos_Load(object sender, EventArgs e)
        {
            VerificarTodosLosCheckBoxesHijos(this, true);
        }

        private void CheckBoxFoco_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBoxFoco.Checked)
            {
                if (handlerGotFocus == null)
                {
                    handlerGotFocus += auxHandlerGotFocus;
                }
                if (handlerLostFocus == null)
                {
                    handlerLostFocus += auxHandlerLostFocus;
                }
            }
            else
            {
                handlerGotFocus = null;
                handlerLostFocus = null;
            }
        }
    }
}
