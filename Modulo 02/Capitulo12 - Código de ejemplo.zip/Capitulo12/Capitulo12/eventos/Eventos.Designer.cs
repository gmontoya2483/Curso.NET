﻿namespace eventos
{
    partial class Eventos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.TextBoxIngreso = new System.Windows.Forms.TextBox();
            this.ArrastrarEtiquetaEnlazada = new System.Windows.Forms.LinkLabel();
            this.GroupBoxParaEventos = new System.Windows.Forms.GroupBox();
            this.CheckBoxMouseIngreso = new System.Windows.Forms.CheckBox();
            this.CheckBoxActivarDesactivarTodos = new System.Windows.Forms.CheckBox();
            this.CheckBoxPuntosDelMouse = new System.Windows.Forms.CheckBox();
            this.CheckBoxTeclaArribaAbajo = new System.Windows.Forms.CheckBox();
            this.CheckBoxDesplazamientoMouseDrag = new System.Windows.Forms.CheckBox();
            this.CheckBoxMouseDrag = new System.Windows.Forms.CheckBox();
            this.CheckBoxValidar = new System.Windows.Forms.CheckBox();
            this.CheckBoxMovimientoMouse = new System.Windows.Forms.CheckBox();
            this.CheckBoxFoco = new System.Windows.Forms.CheckBox();
            this.CheckBoxTeclado = new System.Windows.Forms.CheckBox();
            this.CheckBoxMouse = new System.Windows.Forms.CheckBox();
            this.TextBoxSalida = new System.Windows.Forms.TextBox();
            this.ButtonLimpiar = new System.Windows.Forms.Button();
            this.GroupBoxParaEventos.SuspendLayout();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(280, 12);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(104, 13);
            this.Label1.TabIndex = 17;
            this.Label1.Text = "Eventos Generados:";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(13, 12);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(175, 13);
            this.Label2.TabIndex = 18;
            this.Label2.Text = "Objetivo para Ingresos de Usuarios:";
            // 
            // TextBoxIngreso
            // 
            this.TextBoxIngreso.AllowDrop = true;
            this.TextBoxIngreso.Cursor = System.Windows.Forms.Cursors.Cross;
            this.TextBoxIngreso.Location = new System.Drawing.Point(13, 34);
            this.TextBoxIngreso.Multiline = true;
            this.TextBoxIngreso.Name = "TextBoxIngreso";
            this.TextBoxIngreso.Size = new System.Drawing.Size(260, 200);
            this.TextBoxIngreso.TabIndex = 1;
            this.TextBoxIngreso.DoubleClick += new System.EventHandler(this.TextBoxDeIngresos_DoubleClick);
            this.TextBoxIngreso.MouseCaptureChanged += new System.EventHandler(this.TextBoxDeIngresos_MouseCaptureChanged);
            this.TextBoxIngreso.MouseWheel += new System.Windows.Forms.MouseEventHandler(this.TextBoxDeIngresos_MouseWheel);
            this.TextBoxIngreso.MouseLeave += new System.EventHandler(this.TextBoxDeIngresos_MouseLeave);
            this.TextBoxIngreso.DragDrop += new System.Windows.Forms.DragEventHandler(this.TextBoxDeIngresos_DragDrop);
            this.TextBoxIngreso.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TextBoxDeIngresos_MouseMove);
            this.TextBoxIngreso.Validated += new System.EventHandler(this.TextBoxDeIngresos_Validated);
            this.TextBoxIngreso.Click += new System.EventHandler(this.TextBoxDeIngresos_Click);
            this.TextBoxIngreso.GotFocus += new System.EventHandler(this.TextBoxDeIngresos_GotFocus);
            this.TextBoxIngreso.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBoxDeIngresos_KeyDown);
            this.TextBoxIngreso.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.TextBoxDeIngresos_MouseDoubleClick);
            this.TextBoxIngreso.Leave += new System.EventHandler(this.TextBoxDeIngresos_Leave);
            this.TextBoxIngreso.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TextBoxDeIngresos_KeyUp);
            this.TextBoxIngreso.MouseClick += new System.Windows.Forms.MouseEventHandler(this.TextBoxDeIngresos_MouseClick);
            this.TextBoxIngreso.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TextBoxDeIngresos_MouseDown);
            this.TextBoxIngreso.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBoxDeIngresos_KeyPress);
            this.TextBoxIngreso.Enter += new System.EventHandler(this.TextBoxDeIngresos_Enter);
            this.TextBoxIngreso.DragLeave += new System.EventHandler(this.TextBoxDeIngresos_DragLeave);
            this.TextBoxIngreso.LostFocus += new System.EventHandler(this.TextBoxDeIngresos_LostFocus);
            this.TextBoxIngreso.MouseHover += new System.EventHandler(this.TextBoxDeIngresos_MouseHover);
            this.TextBoxIngreso.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TextBoxDeIngresos_MouseUp);
            this.TextBoxIngreso.Validating += new System.ComponentModel.CancelEventHandler(this.TextBoxDeIngresos_Validating);
            this.TextBoxIngreso.DragEnter += new System.Windows.Forms.DragEventHandler(this.TextBoxDeIngresos_DragEnter);
            this.TextBoxIngreso.MouseEnter += new System.EventHandler(this.TextBoxDeIngresos_MouseEnter);
            this.TextBoxIngreso.DragOver += new System.Windows.Forms.DragEventHandler(this.TextBoxDeIngresos_DragOver);
            // 
            // ArrastrarEtiquetaEnlazada
            // 
            this.ArrastrarEtiquetaEnlazada.AllowDrop = true;
            this.ArrastrarEtiquetaEnlazada.AutoSize = true;
            this.ArrastrarEtiquetaEnlazada.LinkArea = new System.Windows.Forms.LinkArea(0, 52);
            this.ArrastrarEtiquetaEnlazada.Location = new System.Drawing.Point(13, 240);
            this.ArrastrarEtiquetaEnlazada.Name = "ArrastrarEtiquetaEnlazada";
            this.ArrastrarEtiquetaEnlazada.Size = new System.Drawing.Size(254, 13);
            this.ArrastrarEtiquetaEnlazada.TabIndex = 2;
            this.ArrastrarEtiquetaEnlazada.TabStop = true;
            this.ArrastrarEtiquetaEnlazada.Text = "Presionar aca para usarlo como fuente para arrastrar";
            this.ArrastrarEtiquetaEnlazada.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ArrastrarEtiquetaEnlazada_MouseDown);
            this.ArrastrarEtiquetaEnlazada.GiveFeedback += new System.Windows.Forms.GiveFeedbackEventHandler(this.ArrastrarEtiquetaEnlazada_GiveFeedback);
            // 
            // GroupBoxParaEventos
            // 
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxMouseIngreso);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxActivarDesactivarTodos);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxPuntosDelMouse);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxTeclaArribaAbajo);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxDesplazamientoMouseDrag);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxMouseDrag);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxValidar);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxMovimientoMouse);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxFoco);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxTeclado);
            this.GroupBoxParaEventos.Controls.Add(this.CheckBoxMouse);
            this.GroupBoxParaEventos.Location = new System.Drawing.Point(13, 281);
            this.GroupBoxParaEventos.Name = "GroupBoxParaEventos";
            this.GroupBoxParaEventos.Size = new System.Drawing.Size(260, 302);
            this.GroupBoxParaEventos.TabIndex = 3;
            this.GroupBoxParaEventos.TabStop = false;
            this.GroupBoxParaEventos.Text = "Filtrado de Eventos:";
            // 
            // CheckBoxMouseIngreso
            // 
            this.CheckBoxMouseIngreso.AutoSize = true;
            this.CheckBoxMouseIngreso.Location = new System.Drawing.Point(26, 73);
            this.CheckBoxMouseIngreso.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
            this.CheckBoxMouseIngreso.Name = "CheckBoxMouseIngreso";
            this.CheckBoxMouseIngreso.Size = new System.Drawing.Size(185, 17);
            this.CheckBoxMouseIngreso.TabIndex = 17;
            this.CheckBoxMouseIngreso.Text = "Ingreso/Inmóvil/Salida del Mouse";
            this.CheckBoxMouseIngreso.CheckedChanged += new System.EventHandler(this.CheckBoxMovimientoDelMouse_CheckedChanged);
            // 
            // CheckBoxActivarDesactivarTodos
            // 
            this.CheckBoxActivarDesactivarTodos.AutoSize = true;
            this.CheckBoxActivarDesactivarTodos.Location = new System.Drawing.Point(7, 24);
            this.CheckBoxActivarDesactivarTodos.Name = "CheckBoxActivarDesactivarTodos";
            this.CheckBoxActivarDesactivarTodos.Size = new System.Drawing.Size(206, 17);
            this.CheckBoxActivarDesactivarTodos.TabIndex = 15;
            this.CheckBoxActivarDesactivarTodos.Text = "Activar/Desactivar Todos los Eventos";
            this.CheckBoxActivarDesactivarTodos.CheckedChanged += new System.EventHandler(this.CheckBoxSeleccionarTodo_CheckedChanged);
            // 
            // CheckBoxPuntosDelMouse
            // 
            this.CheckBoxPuntosDelMouse.AutoSize = true;
            this.CheckBoxPuntosDelMouse.Location = new System.Drawing.Point(26, 116);
            this.CheckBoxPuntosDelMouse.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
            this.CheckBoxPuntosDelMouse.Name = "CheckBoxPuntosDelMouse";
            this.CheckBoxPuntosDelMouse.Size = new System.Drawing.Size(161, 17);
            this.CheckBoxPuntosDelMouse.TabIndex = 19;
            this.CheckBoxPuntosDelMouse.Text = "Dibujar puntos con el Mouse";
            // 
            // CheckBoxTeclaArribaAbajo
            // 
            this.CheckBoxTeclaArribaAbajo.AutoSize = true;
            this.CheckBoxTeclaArribaAbajo.Location = new System.Drawing.Point(26, 211);
            this.CheckBoxTeclaArribaAbajo.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
            this.CheckBoxTeclaArribaAbajo.Name = "CheckBoxTeclaArribaAbajo";
            this.CheckBoxTeclaArribaAbajo.Size = new System.Drawing.Size(172, 17);
            this.CheckBoxTeclaArribaAbajo.TabIndex = 23;
            this.CheckBoxTeclaArribaAbajo.Text = "Eventos para presión de teclas";
            // 
            // CheckBoxDesplazamientoMouseDrag
            // 
            this.CheckBoxDesplazamientoMouseDrag.AutoSize = true;
            this.CheckBoxDesplazamientoMouseDrag.Location = new System.Drawing.Point(44, 163);
            this.CheckBoxDesplazamientoMouseDrag.Name = "CheckBoxDesplazamientoMouseDrag";
            this.CheckBoxDesplazamientoMouseDrag.Size = new System.Drawing.Size(193, 17);
            this.CheckBoxDesplazamientoMouseDrag.TabIndex = 21;
            this.CheckBoxDesplazamientoMouseDrag.Text = "Eventos del Mouse Drag Desplazar";
            // 
            // CheckBoxMouseDrag
            // 
            this.CheckBoxMouseDrag.AutoSize = true;
            this.CheckBoxMouseDrag.Location = new System.Drawing.Point(26, 139);
            this.CheckBoxMouseDrag.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
            this.CheckBoxMouseDrag.Name = "CheckBoxMouseDrag";
            this.CheckBoxMouseDrag.Size = new System.Drawing.Size(193, 17);
            this.CheckBoxMouseDrag.TabIndex = 20;
            this.CheckBoxMouseDrag.Text = "Eventos del Mouse de Drag && Drop";
            this.CheckBoxMouseDrag.CheckedChanged += new System.EventHandler(this.CheckBoxArrastrarMouse_CheckedChanged);
            // 
            // CheckBoxValidar
            // 
            this.CheckBoxValidar.AutoSize = true;
            this.CheckBoxValidar.Location = new System.Drawing.Point(8, 261);
            this.CheckBoxValidar.Name = "CheckBoxValidar";
            this.CheckBoxValidar.Size = new System.Drawing.Size(135, 17);
            this.CheckBoxValidar.TabIndex = 25;
            this.CheckBoxValidar.Text = "Eventos de Validación ";
            this.CheckBoxValidar.CheckedChanged += new System.EventHandler(this.TextBoxDeIngresos_Validated);
            // 
            // CheckBoxMovimientoMouse
            // 
            this.CheckBoxMovimientoMouse.AutoSize = true;
            this.CheckBoxMovimientoMouse.Location = new System.Drawing.Point(26, 93);
            this.CheckBoxMovimientoMouse.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
            this.CheckBoxMovimientoMouse.Name = "CheckBoxMovimientoMouse";
            this.CheckBoxMovimientoMouse.Size = new System.Drawing.Size(197, 17);
            this.CheckBoxMovimientoMouse.TabIndex = 18;
            this.CheckBoxMovimientoMouse.Text = "Eventos de Movimientos del Mouse ";
            this.CheckBoxMovimientoMouse.CheckedChanged += new System.EventHandler(this.CheckBoxMovimientoDelMouse_CheckedChanged);
            // 
            // CheckBoxFoco
            // 
            this.CheckBoxFoco.AutoSize = true;
            this.CheckBoxFoco.Location = new System.Drawing.Point(8, 237);
            this.CheckBoxFoco.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
            this.CheckBoxFoco.Name = "CheckBoxFoco";
            this.CheckBoxFoco.Size = new System.Drawing.Size(171, 17);
            this.CheckBoxFoco.TabIndex = 24;
            this.CheckBoxFoco.Text = "Eventos de Foco y Activación ";
            this.CheckBoxFoco.CheckedChanged += new System.EventHandler(this.CheckBoxFoco_CheckedChanged);
            // 
            // CheckBoxTeclado
            // 
            this.CheckBoxTeclado.AutoSize = true;
            this.CheckBoxTeclado.Location = new System.Drawing.Point(8, 188);
            this.CheckBoxTeclado.Name = "CheckBoxTeclado";
            this.CheckBoxTeclado.Size = new System.Drawing.Size(124, 17);
            this.CheckBoxTeclado.TabIndex = 22;
            this.CheckBoxTeclado.Text = "Eventos del Teclado";
            this.CheckBoxTeclado.CheckedChanged += new System.EventHandler(this.CheckBoxTeclado_CheckedChanged);
            // 
            // CheckBoxMouse
            // 
            this.CheckBoxMouse.AutoSize = true;
            this.CheckBoxMouse.Location = new System.Drawing.Point(7, 49);
            this.CheckBoxMouse.Name = "CheckBoxMouse";
            this.CheckBoxMouse.Size = new System.Drawing.Size(146, 17);
            this.CheckBoxMouse.TabIndex = 16;
            this.CheckBoxMouse.Text = "Eventos de Mouse y Clic ";
            this.CheckBoxMouse.CheckedChanged += new System.EventHandler(this.CheckBoxMouse_CheckedChanged);
            // 
            // TextBoxSalida
            // 
            this.TextBoxSalida.CausesValidation = false;
            this.TextBoxSalida.Location = new System.Drawing.Point(280, 34);
            this.TextBoxSalida.Multiline = true;
            this.TextBoxSalida.Name = "TextBoxSalida";
            this.TextBoxSalida.ReadOnly = true;
            this.TextBoxSalida.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.TextBoxSalida.Size = new System.Drawing.Size(403, 510);
            this.TextBoxSalida.TabIndex = 15;
            this.TextBoxSalida.WordWrap = false;
            // 
            // ButtonLimpiar
            // 
            this.ButtonLimpiar.Location = new System.Drawing.Point(280, 560);
            this.ButtonLimpiar.Name = "ButtonLimpiar";
            this.ButtonLimpiar.Size = new System.Drawing.Size(308, 23);
            this.ButtonLimpiar.TabIndex = 16;
            this.ButtonLimpiar.Text = "Limpiar Lista de Eventos";
            this.ButtonLimpiar.Click += new System.EventHandler(this.BotonLimpiar_Click);
            // 
            // Eventos
            // 
            this.ClientSize = new System.Drawing.Size(695, 595);
            this.Controls.Add(this.ArrastrarEtiquetaEnlazada);
            this.Controls.Add(this.ButtonLimpiar);
            this.Controls.Add(this.GroupBoxParaEventos);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.TextBoxIngreso);
            this.Controls.Add(this.TextBoxSalida);
            this.Name = "Eventos";
            this.Text = "Eventos para ingresos de Usuarios ";
            this.Load += new System.EventHandler(this.Eventos_Load);
            this.GroupBoxParaEventos.ResumeLayout(false);
            this.GroupBoxParaEventos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.TextBox TextBoxSalida;
        private System.Windows.Forms.TextBox TextBoxIngreso;
        private System.Windows.Forms.GroupBox GroupBoxParaEventos;
        private System.Windows.Forms.Button ButtonLimpiar;
        private System.Windows.Forms.LinkLabel ArrastrarEtiquetaEnlazada;

        #endregion
        private System.Windows.Forms.CheckBox CheckBoxMouseIngreso;
        private System.Windows.Forms.CheckBox CheckBoxActivarDesactivarTodos;
        private System.Windows.Forms.CheckBox CheckBoxPuntosDelMouse;
        private System.Windows.Forms.CheckBox CheckBoxTeclaArribaAbajo;
        private System.Windows.Forms.CheckBox CheckBoxDesplazamientoMouseDrag;
        private System.Windows.Forms.CheckBox CheckBoxMouseDrag;
        private System.Windows.Forms.CheckBox CheckBoxValidar;
        private System.Windows.Forms.CheckBox CheckBoxMovimientoMouse;
        private System.Windows.Forms.CheckBox CheckBoxFoco;
        private System.Windows.Forms.CheckBox CheckBoxTeclado;
        private System.Windows.Forms.CheckBox CheckBoxMouse;

    }
}