﻿namespace grilla
{
    using System;
    using System.Drawing;
    using System.Windows.Forms;

    public class Form1 : System.Windows.Forms.Form
    {
        private Panel PanelDeBotones = new Panel();
        private DataGridView DataGridViewDeCanciones = new DataGridView();
        private Button BotonAgregarFilaNueva = new Button();
        private Button BotonBorrarFila = new Button();

        public Form1()
        {
            this.Load += new EventHandler(Form1_Load);
        }

        private void Form1_Load(System.Object sender, System.EventArgs e)
        {
            ConfigurarSalida();
            InicializarDataGridView();
            LlenarElDataGridView();
        }

        private void DataGridViewDeCanciones_CellFormatting(object sender,
            System.Windows.Forms.DataGridViewCellFormattingEventArgs e)
        {
            if (this.DataGridViewDeCanciones.Columns[e.ColumnIndex].Name == "Fecha de Lanzamiento")
            {
                if (e != null)
                {
                    if (e.Value != null)
                    {
                        try
                        {
                            e.Value = DateTime.Parse(e.Value.ToString())
                                .ToLongDateString();
                            e.FormattingApplied = true;
                        }
                        catch (FormatException)
                        {
                            Console.WriteLine("{0} no es una fecha válida.", e.Value.ToString());
                        }
                    }
                }
            }
        }

        private void addNewRowButton_Click(object sender, EventArgs e)
        {
            this.DataGridViewDeCanciones.Rows.Add();
        }

        private void deleteRowButton_Click(object sender, EventArgs e)
        {
            if (this.DataGridViewDeCanciones.SelectedRows.Count > 0 &&
                this.DataGridViewDeCanciones.SelectedRows[0].Index !=
                this.DataGridViewDeCanciones.Rows.Count - 1)
            {
                this.DataGridViewDeCanciones.Rows.RemoveAt(
                    this.DataGridViewDeCanciones.SelectedRows[0].Index);
            }
        }

        private void ConfigurarSalida()
        {
            this.Size = new Size(600, 500);

            BotonAgregarFilaNueva.Text = "Agregar Fila";
            BotonAgregarFilaNueva.Location = new Point(10, 10);
            BotonAgregarFilaNueva.Click += new EventHandler(addNewRowButton_Click);

            BotonBorrarFila.Text = "Borrar Fila";
            BotonBorrarFila.Location = new Point(100, 10);
            BotonBorrarFila.Click += new EventHandler(deleteRowButton_Click);

            PanelDeBotones.Controls.Add(BotonAgregarFilaNueva);
            PanelDeBotones.Controls.Add(BotonBorrarFila);
            PanelDeBotones.Height = 50;
            PanelDeBotones.Dock = DockStyle.Bottom;

            this.Controls.Add(this.PanelDeBotones);
        }

        private void InicializarDataGridView()
        {
            this.Controls.Add(DataGridViewDeCanciones);

            DataGridViewDeCanciones.ColumnCount = 5;

            DataGridViewDeCanciones.ColumnHeadersDefaultCellStyle.BackColor = Color.Navy;
            DataGridViewDeCanciones.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            DataGridViewDeCanciones.ColumnHeadersDefaultCellStyle.Font =
                new Font(DataGridViewDeCanciones.Font, FontStyle.Bold);

            DataGridViewDeCanciones.Name = "DataGridViewDeCanciones";
            DataGridViewDeCanciones.Location = new Point(8, 8);
            DataGridViewDeCanciones.Size = new Size(500, 250);
            DataGridViewDeCanciones.AutoSizeRowsMode =
                DataGridViewAutoSizeRowsMode.DisplayedCellsExceptHeaders;
            DataGridViewDeCanciones.ColumnHeadersBorderStyle =
                DataGridViewHeaderBorderStyle.Single;
            DataGridViewDeCanciones.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            DataGridViewDeCanciones.GridColor = Color.Black;
            DataGridViewDeCanciones.RowHeadersVisible = false;

            DataGridViewDeCanciones.Columns[0].Name = "Fecha de Lanzamiento";
            DataGridViewDeCanciones.Columns[1].Name = "Track";
            DataGridViewDeCanciones.Columns[2].Name = "Título";
            DataGridViewDeCanciones.Columns[3].Name = "Artista";
            DataGridViewDeCanciones.Columns[4].Name = "Álbum";
            DataGridViewDeCanciones.Columns[4].DefaultCellStyle.Font =
                new Font(DataGridViewDeCanciones.DefaultCellStyle.Font, FontStyle.Italic);

            DataGridViewDeCanciones.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;
            DataGridViewDeCanciones.MultiSelect = false;
            DataGridViewDeCanciones.Dock = DockStyle.Fill;

            DataGridViewDeCanciones.CellFormatting += new
                DataGridViewCellFormattingEventHandler(
                DataGridViewDeCanciones_CellFormatting);
        }

        private void LlenarElDataGridView()
        {

            string[] row0 = { "11/22/1968", "29", "Revolution 9", 
            "Beatles", "The Beatles [White Album]" };
            string[] row1 = { "1960", "6", "Fools Rush In", 
            "Frank Sinatra", "Nice 'N' Easy" };
            string[] row2 = { "11/11/1971", "1", "One of These Days", 
            "Pink Floyd", "Meddle" };
            string[] row3 = { "1988", "7", "Where Is My Mind?", 
            "Pixies", "Surfer Rosa" };
            string[] row4 = { "5/1981", "9", "Can't Find My Mind", 
            "Cramps", "Psychedelic Jungle" };
            string[] row5 = { "6/10/2003", "13", 
            "Scatterbrain. (As Dead As Leaves.)", 
            "Radiohead", "Hail to the Thief" };
            string[] row6 = { "6/30/1992", "3", "Dress", "P J Harvey", "Dry" };

            DataGridViewDeCanciones.Rows.Add(row0);
            DataGridViewDeCanciones.Rows.Add(row1);
            DataGridViewDeCanciones.Rows.Add(row2);
            DataGridViewDeCanciones.Rows.Add(row3);
            DataGridViewDeCanciones.Rows.Add(row4);
            DataGridViewDeCanciones.Rows.Add(row5);
            DataGridViewDeCanciones.Rows.Add(row6);

            DataGridViewDeCanciones.Columns[0].DisplayIndex = 3;
            DataGridViewDeCanciones.Columns[1].DisplayIndex = 4;
            DataGridViewDeCanciones.Columns[2].DisplayIndex = 0;
            DataGridViewDeCanciones.Columns[3].DisplayIndex = 1;
            DataGridViewDeCanciones.Columns[4].DisplayIndex = 2;
        }

    }
}