﻿using System.Drawing;
using System.Windows.Forms;

namespace propiedades
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
 
            PropertyGrid propertyGrid1 = new PropertyGrid();
            propertyGrid1.CommandsVisibleIfAvailable = true;
            propertyGrid1.Location = new Point(10, 40);
            propertyGrid1.Size = new System.Drawing.Size(400, 300);
            propertyGrid1.TabIndex = 1;
            propertyGrid1.Text = "Grilla de Propiedades";

            this.Controls.Add(propertyGrid1);
            textBox1.Text = "Cambiar propiedades del cuadro de texto";
            propertyGrid1.SelectedObject = textBox1;
        }
    }
}
