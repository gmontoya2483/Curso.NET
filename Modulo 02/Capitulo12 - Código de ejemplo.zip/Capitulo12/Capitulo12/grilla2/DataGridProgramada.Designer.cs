﻿namespace grilla2
{
    partial class DataGridProgramada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.botonAgregarColumnasALaTabla = new System.Windows.Forms.Button();
            this.botonAgregarMasColumnasConCantidad = new System.Windows.Forms.Button();
            this.botonRemoverColumnas = new System.Windows.Forms.Button();
            this.tabla = new System.Windows.Forms.DataGridView();
            this.botonAgregarFilas = new System.Windows.Forms.Button();
            this.botonAgregarFilasHetrogeneas = new System.Windows.Forms.Button();
            this.botonAgregarOtraFilaHeterogenea = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.tabla)).BeginInit();
            this.SuspendLayout();
            // 
            // botonAgregarColumnasALaTabla
            // 
            this.botonAgregarColumnasALaTabla.Location = new System.Drawing.Point(13, 13);
            this.botonAgregarColumnasALaTabla.Name = "botonAgregarColumnasALaTabla";
            this.botonAgregarColumnasALaTabla.Size = new System.Drawing.Size(168, 23);
            this.botonAgregarColumnasALaTabla.TabIndex = 0;
            this.botonAgregarColumnasALaTabla.Text = "Agregar Columnas a la Tabla";
            this.botonAgregarColumnasALaTabla.Click += new System.EventHandler(this.ManejadorEventoAgregarColumnas);
            // 
            // botonAgregarMasColumnasConCantidad
            // 
            this.botonAgregarMasColumnasConCantidad.Location = new System.Drawing.Point(205, 13);
            this.botonAgregarMasColumnasConCantidad.Name = "botonAgregarMasColumnasConCantidad";
            this.botonAgregarMasColumnasConCantidad.Size = new System.Drawing.Size(208, 23);
            this.botonAgregarMasColumnasConCantidad.TabIndex = 1;
            this.botonAgregarMasColumnasConCantidad.Text = "Agregar Más Columnas Con Cantidad";
            this.botonAgregarMasColumnasConCantidad.Click += new System.EventHandler(this.ManejadorEventoAgregarMas);
            // 
            // botonRemoverColumnas
            // 
            this.botonRemoverColumnas.Location = new System.Drawing.Point(428, 12);
            this.botonRemoverColumnas.Name = "botonRemoverColumnas";
            this.botonRemoverColumnas.Size = new System.Drawing.Size(196, 23);
            this.botonRemoverColumnas.TabIndex = 2;
            this.botonRemoverColumnas.Text = "Remover Columnas Con Cantidad";
            this.botonRemoverColumnas.Click += new System.EventHandler(this.ManejadorEventoRemover);
            // 
            // tabla
            // 
            this.tabla.Location = new System.Drawing.Point(12, 85);
            this.tabla.Name = "tabla";
            this.tabla.Size = new System.Drawing.Size(612, 265);
            this.tabla.TabIndex = 3;
            // 
            // botonAgregarFilas
            // 
            this.botonAgregarFilas.Location = new System.Drawing.Point(38, 41);
            this.botonAgregarFilas.Name = "botonAgregarFilas";
            this.botonAgregarFilas.Size = new System.Drawing.Size(131, 23);
            this.botonAgregarFilas.TabIndex = 4;
            this.botonAgregarFilas.Text = "Agregar Filas";
            this.botonAgregarFilas.Click += new System.EventHandler(this.ManejadorEventoAgregarFilas);
            // 
            // botonAgregarFilasHetrogeneas
            // 
            this.botonAgregarFilasHetrogeneas.Location = new System.Drawing.Point(228, 42);
            this.botonAgregarFilasHetrogeneas.Name = "botonAgregarFilasHetrogeneas";
            this.botonAgregarFilasHetrogeneas.Size = new System.Drawing.Size(138, 23);
            this.botonAgregarFilasHetrogeneas.TabIndex = 5;
            this.botonAgregarFilasHetrogeneas.Text = "Agregar Filas Hetrogéneas";
            this.botonAgregarFilasHetrogeneas.Click += new System.EventHandler(this.ManejadorEventoAgregarHeterogeneas);
            // 
            // botonAgregarOtraFilaHeterogenea
            // 
            this.botonAgregarOtraFilaHeterogenea.Location = new System.Drawing.Point(452, 41);
            this.botonAgregarOtraFilaHeterogenea.Name = "botonAgregarOtraFilaHeterogenea";
            this.botonAgregarOtraFilaHeterogenea.Size = new System.Drawing.Size(159, 23);
            this.botonAgregarOtraFilaHeterogenea.TabIndex = 6;
            this.botonAgregarOtraFilaHeterogenea.Text = "Agregar Otras Filas Hetrogéneas";
            this.botonAgregarOtraFilaHeterogenea.Click += new System.EventHandler(this.ManejadorEventoAgregarOtraHeterogenea);
            // 
            // DataGridProgramada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 362);
            this.Controls.Add(this.botonAgregarOtraFilaHeterogenea);
            this.Controls.Add(this.botonAgregarFilasHetrogeneas);
            this.Controls.Add(this.botonAgregarFilas);
            this.Controls.Add(this.tabla);
            this.Controls.Add(this.botonRemoverColumnas);
            this.Controls.Add(this.botonAgregarMasColumnasConCantidad);
            this.Controls.Add(this.botonAgregarColumnasALaTabla);
            this.Name = "DataGridProgramada";
            this.Text = "Tabla por Programa";
            ((System.ComponentModel.ISupportInitialize)(this.tabla)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Button botonAgregarColumnasALaTabla;
        private System.Windows.Forms.Button botonAgregarMasColumnasConCantidad;
        private System.Windows.Forms.Button botonRemoverColumnas;
        private System.Windows.Forms.DataGridView tabla;
        private System.Windows.Forms.Button botonAgregarFilas;
        private System.Windows.Forms.Button botonAgregarFilasHetrogeneas;
        private System.Windows.Forms.Button botonAgregarOtraFilaHeterogenea;
    }

        #endregion
}