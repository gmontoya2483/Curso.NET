﻿using System;
using System.Windows.Forms;

namespace grilla2
{
    public partial class DataGridProgramada : Form
    {
        public DataGridProgramada()
        {
            InitializeComponent();
        }
        private void ManejadorEventoAgregarColumnas(object sender, EventArgs e)
        {
            tabla.Columns.Add("NombreColumna", "TextoCabeceraColumna");
            tabla.Columns.Add("OtroNombreColumna", "OtroTextoCabeceraColumna");
        }

        private void ManejadorEventoAgregarMas(object sender, EventArgs e)
        {
            tabla.ColumnCount = 5;
            tabla.Columns[2].Name = "Col3";
            tabla.Columns[2].HeaderText = "Col3";
            tabla.Columns[3].Name = "Col4";
            tabla.Columns[3].HeaderText = "Col4";
            tabla.Columns[4].Name = "Col5";
            tabla.Columns[4].HeaderText = "Col5";
        }

        private void ManejadorEventoRemover(object sender, EventArgs e)
        {
            tabla.ColumnCount = 3;
        }

        private void ManejadorEventoAgregarFilas(object sender, EventArgs e)
        {
            tabla.Rows.Add(20);
        }

        private void ManejadorEventoAgregarHeterogeneas(object sender, EventArgs e)
        {
            tabla.ColumnCount = 5;
            DataGridViewRow filaHeterogenea = new DataGridViewRow();
            DataGridViewComboBoxCell celdaConCombo = new DataGridViewComboBoxCell();
            celdaConCombo.Items.Add("Negro");
            celdaConCombo.Items.Add("Blanco");
            celdaConCombo.Value = "Blanco";
            filaHeterogenea.Cells.Add(celdaConCombo);
            for (int i = 0; i < 4; i++)
            {
                filaHeterogenea.Cells.Add(new DataGridViewTextBoxCell());
            }
            tabla.Rows.Add(filaHeterogenea);

        }

        private void ManejadorEventoAgregarOtraHeterogenea(object sender, EventArgs e)
        {
            DataGridViewRow filaHeterogenea = new DataGridViewRow();
            filaHeterogenea.CreateCells(tabla);
            filaHeterogenea.Cells.RemoveAt(0);
            filaHeterogenea.Cells.Insert(0, new DataGridViewComboBoxCell());
            tabla.Rows.Add(filaHeterogenea);

        }

    }
}
