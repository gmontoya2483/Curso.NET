﻿using System.Windows.Forms;

namespace division
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            treeView1.BeginUpdate();
            treeView1.Nodes.Add("Padre");
            treeView1.Nodes[0].Nodes.Add("Hijo 1");
            treeView1.Nodes[0].Nodes.Add("Hijo 2");
            treeView1.Nodes[0].Nodes[1].Nodes.Add("Nieto");
            treeView1.Nodes[0].Nodes[1].Nodes[0].Nodes.Add("Bisnieto");
            treeView1.EndUpdate();

            listView2.View = View.List;

            splitContainer1.ResumeLayout(false);
            splitContainer2.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void splitContainer1_SplitterMoving(System.Object sender, System.Windows.Forms.SplitterCancelEventArgs e)
        {
            // Cambiar el tipo de cursor cuando se mueve
            Cursor.Current = System.Windows.Forms.Cursors.NoMoveVert;
        }
        private void splitContainer1_SplitterMoved(System.Object sender, System.Windows.Forms.SplitterEventArgs e)
        {
            // Cuando se deja de mover, volver al cursor por defecto.
            Cursor.Current = System.Windows.Forms.Cursors.Default;
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            ListViewItem item1 = new ListViewItem(e.Node.Text, 0);
            listView1.Items.Add(item1);
            ListViewItem item2 = new ListViewItem(e.Node.Text, 0);
            listView2.Items.Add(item2);
        }
    }
}
