﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace imagen
{
    public partial class Form1 : Form
    {
        private Bitmap laImagen;

        public Form1()
        {
            InitializeComponent();
            MostrarImagen(@".\imagenes\Chrysanthemum.jpg", 260, 238);
        }

        public void MostrarImagen(String archivoAMostrar, int x, int y)
        {
            // Configurar la imagen a mostrar.
            if (laImagen != null)
            {
                laImagen.Dispose();
            }

            // Ajustar la imagen al PictureBox.
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            laImagen = new Bitmap(archivoAMostrar);
            pictureBox1.ClientSize = new Size(x, y);
            pictureBox1.Image = (Image)laImagen;
        }
    }
}
