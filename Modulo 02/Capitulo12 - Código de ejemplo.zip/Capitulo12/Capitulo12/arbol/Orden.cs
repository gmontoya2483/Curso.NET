﻿namespace arbol
{
    public class Orden 
    {
        private string _idOrden = "";

        public Orden(string _idOrden)
        {
            this._idOrden = _idOrden;
        }

        public string IdOrden
        {
            get { return this._idOrden; }
            set { this._idOrden = value; }
        }
    }
}
