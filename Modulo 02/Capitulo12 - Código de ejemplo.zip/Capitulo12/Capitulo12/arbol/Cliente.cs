﻿using System.Collections;

namespace arbol
{
    public class Cliente 
    {
        private string _nombreCliente = "";
        protected ArrayList _ordenesCliente = new ArrayList();

        public Cliente(string nombre)
        {
            this._nombreCliente = nombre;
        }

        public string NombreCliente
        {
            get { return this._nombreCliente; }
            set { this._nombreCliente = value; }
        }

        public ArrayList OrdenesCliente
        {
            get { return this._ordenesCliente; }
        }
    }
}
