﻿using System.Windows.Forms;
using System.Collections;
using System;

namespace arbol
{
    public partial class Form1 : Form
    {
        // Crear un ArraList para contener los objetos del tipo Cliente
        private ArrayList listaClientes = new ArrayList();

        public Form1()
        {
            InitializeComponent();
            this.Show();
            MostrarElTreeView();
        }

        private void MostrarElTreeView()
        {
            // Agregar clientes al ArrayList.
            for (int x = 0; x < 2000; x++)
            {
                listaClientes.Add(new Cliente("Cliente" + x.ToString()));
            }

            // Agregar órdenes a cada cliente de la lista
            foreach (Cliente _cliente in listaClientes)
            {
                for (int y = 0; y < 15; y++)
                {
                    _cliente.OrdenesCliente.Add(new Orden("Orden" + y.ToString()));
                }
            }

            // Mostrar el cursor de espera mientras se llena el TreeView
            Cursor.Current = Cursors.WaitCursor;


            // Suprimir el dibujo del TreeView hasta que se complete
            treeView1.BeginUpdate();

            // Limpiar el TreeView cada vez que se llame al método
            treeView1.Nodes.Clear();

            // Agregar un TreeNode raíz por cada cliente en la lista 
            foreach (Cliente _cliente2 in listaClientes)
            {
                treeView1.Nodes.Add(new TreeNode(_cliente2.NombreCliente));

                // Agregar un TreeNode hijo por cada Orden en el cliente actual.
                foreach (Orden orden1 in _cliente2.OrdenesCliente)
                {
                    treeView1.Nodes[listaClientes.IndexOf(_cliente2)].Nodes.Add(
                      new TreeNode(_cliente2.NombreCliente + "." + orden1.IdOrden));
                }
            }

            // Reiniciar al cursor por defecto
            Cursor.Current = Cursors.Default;

            // Empezar el dibujo del TreeView.
            treeView1.EndUpdate();
        }

        void HandleCustomEvent(object sender, EventArgs a)
        {
            // Do something useful here.
        }

    }
}
