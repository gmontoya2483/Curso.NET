﻿using System.Windows.Forms;

namespace mensajes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Show();
            const string mensaje =
                "¿Está seguro que quiere cerrar la aplicación?";
            const string titulo = "Cerrar aplicación";
            var resultado = MessageBox.Show(mensaje, titulo,
                                         MessageBoxButtons.YesNo,
                                         MessageBoxIcon.Question);

            if (resultado == DialogResult.No)
            {
                MessageBox.Show("Seleccionó No. Cierre la aplicación desde el botón del formulario",
                            "Para cerrar la aplicación ...",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Seleccionó Si. Cierre la aplicación desde el botón del formulario",
                             "Para cerrar la aplicación ...",
                             MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
