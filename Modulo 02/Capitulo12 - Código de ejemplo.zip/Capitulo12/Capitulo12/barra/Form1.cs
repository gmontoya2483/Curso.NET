﻿using System.Windows.Forms;

namespace banda
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            toolStrip1.Items.Add("Uno");
            toolStrip1.Items.Add("Dos");
            toolStrip1.Items.Add("Tres");
            // Agregar la barra de herrramientas al contenedor ToolStripContainer.
            toolStripContainer1.TopToolStripPanel.Controls.Add(toolStrip1);
        }
    }
}
