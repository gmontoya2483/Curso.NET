﻿using System.Windows.Forms;

namespace noModal
{
    public partial class FrmAcercaDe : Form
    {
        public FrmAcercaDe()
        {
            InitializeComponent();
            btAceptar.DialogResult = DialogResult.OK;
            this.DialogResult = btAceptar.DialogResult;
        }
    }
}
