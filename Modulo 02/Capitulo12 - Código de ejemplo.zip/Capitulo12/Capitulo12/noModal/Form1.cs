﻿using System;
using System.Windows.Forms;

namespace noModal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Show();
            FrmAcercaDe frm = new FrmAcercaDe();
            frm.Text = "Este Formulario Es No Modal!!";
            frm.Show();
            Console.WriteLine("Resultado: {0}", frm.DialogResult);
        }
    }
}
