﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace tabular
{
    public partial class Form1 : Form
    {
        private string lenguaje = "Inglés";

        public Form1()
        {
            InitializeComponent();
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Declarar el tamaño actual. 
            float tamanioActual;
            tamanioActual = lbl1.Font.Size;
            tamanioActual += 2.0F;
            switch (comboBox1.SelectedItem.ToString().Trim())
            {
                case "8":
                    tamanioActual = 8.0F;
                    break;
                case "10":
                    tamanioActual = 10.0F;
                    break;
                case "12":
                    tamanioActual = 12.0F;
                    break;
                case "14":
                    tamanioActual = 14.0F;
                    break;
                case "16":
                    tamanioActual = 16.0F;
                    break;
            }

            lbl1.Font = new Font(lbl1.Font.Name, tamanioActual, lbl1.Font.Style, lbl1.Font.Unit);
            lbl2.Font = new Font(lbl2.Font.Name, tamanioActual, lbl2.Font.Style, lbl2.Font.Unit);
            lbl3.Font = new Font(lbl3.Font.Name, tamanioActual, lbl3.Font.Style, lbl3.Font.Unit);
            lbl4.Font = new Font(lbl4.Font.Name, tamanioActual, lbl4.Font.Style, lbl4.Font.Unit);
            lbl5.Font = new Font(lbl5.Font.Name, tamanioActual, lbl5.Font.Style, lbl5.Font.Unit);
            lbl6.Font = new Font(lbl6.Font.Name, tamanioActual, lbl6.Font.Style, lbl6.Font.Unit);
            lblAnchoVentana.Text = "Ancho del formulario = " + this.Size.Width;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (lenguaje.Equals("Inglés"))
            {
                lenguaje = "Español";
                lbl1.Text = "Reutilizar el documento activo si se guardó";
                lbl2.Text = "Detectar si se modifica el archivo fuera del entorno";
                lbl3.Text = "Cargar cambios automáticamente (si no se han aplicado ya en el entorno)";
                lbl4.Text = "Permitir la edición de archivos sólo lectura, advertir al guardarlos";
                lbl5.Text = "Abrir archivos utilizando el directorio del documento activo actualmente";
                lbl6.Text = "Mostrar archivos varios en el Explorador de soluciones";
            }
            else
            {
                lenguaje = "Inglés";
                lbl1.Text = "Re-use current document window , if saved";
                lbl2.Text = "Detect when file is changed outside the environment";
                lbl3.Text = "Auto-load changes (if not currently modified inside the environment)";
                lbl4.Text = "Allow editing of read-only files, warn when attempt to save";
                lbl5.Text = "Open file using directory of current active document";
                lbl6.Text = "Show Miscellaneous files in Solution Explorer";
            }
            lblAnchoVentana.Text = "Ancho del formulario = " + this.Size.Width;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lbl1.Text = "Re-use current document window , if saved";
            lbl2.Text = "Detect when file is changed outside the environment";
            lbl3.Text = "Auto-load changes (if not currently modified inside the environment)";
            lbl4.Text = "Allow editing of read-only files, warn when attempt to save";
            lbl5.Text = "Open file using directory of current active document";
            lbl6.Text = "Show Miscellaneous files in Solution Explorer";
            lblAnchoVentana.Text = "Ancho del formulario = " + this.Size.Width;
            float tamanioActual;  // Tamaño de fuente 
            tamanioActual = lbl1.Font.Size;
            tamanioActual = 8.0F;
            lbl1.Font = new Font(lbl1.Font.Name, tamanioActual, lbl1.Font.Style, lbl1.Font.Unit);
            lbl2.Font = new Font(lbl2.Font.Name, tamanioActual, lbl2.Font.Style, lbl2.Font.Unit);
            lbl3.Font = new Font(lbl3.Font.Name, tamanioActual, lbl3.Font.Style, lbl3.Font.Unit);
            lbl4.Font = new Font(lbl4.Font.Name, tamanioActual, lbl4.Font.Style, lbl4.Font.Unit);
            lbl5.Font = new Font(lbl5.Font.Name, tamanioActual, lbl5.Font.Style, lbl5.Font.Unit);
            lbl6.Font = new Font(lbl6.Font.Name, tamanioActual, lbl6.Font.Style, lbl6.Font.Unit);
            // Ancho del formulario para comparar el tamao al localizar el formulario
            lblAnchoVentana.Text = "Ancho del formulario = " + this.Size.Width;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Ancho del formulario para comparar el tamaño al localizar el formulario 
            lblAnchoVentana.Text = "Ancho del formulario = " + this.Size.Width;
            // Texto de los controles Labels en el formulario 
            lbl1.Text = "Re-use current document window , if saved";
            lbl2.Text = "Detect when file is changed outside the environment";
            lbl3.Text = "Auto-load changes (if not currently modified inside the environment)";
            lbl4.Text = "Allow editing of read-only files, warn when attempt to save";
            lbl5.Text = "Open file using directory of current active document";
            lbl6.Text = "Show Miscellaneous files in Solution Explorer";
        }
    }
}
