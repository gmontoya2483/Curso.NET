﻿using System.Drawing;
using System.Windows.Forms;

namespace panel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            CrearPanel();
        }

        public void CrearPanel()
        {
            Panel panel1 = new Panel();
            TextBox textBox1 = new TextBox();
            Label label1 = new Label();

            // Inicializar el control Panel.
            panel1.Location = new Point(10, 10);
            panel1.Size = new Size(264, 152);
            // Configurar el estilo del borde en 3 dimensiones.
            panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;

            // Inicializar los otros controles.
            label1.Location = new Point(16, 16);
            label1.Text = "Una Etiqueta";
            label1.Size = new Size(104, 16);
            textBox1.Location = new Point(16, 32);
            textBox1.Text = "";
            textBox1.Size = new Size(152, 20);

            // Agregar el Panel al formulario.
            this.Controls.Add(panel1);
            // Agregar los controles Label y TextBox al Panel.
            panel1.Controls.Add(label1);
            panel1.Controls.Add(textBox1);
        }
    }
}
