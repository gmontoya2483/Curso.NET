﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace cuentas
{
    public class FormatoDelNumeroDeCuenta : IFormatProvider, ICustomFormatter
    {
        private const int LARGO_CUENTA = 12;

        public object GetFormat(Type formatoDelTipo)
        {
            if (formatoDelTipo == typeof(ICustomFormatter))
                return this;
            else
                return null;
        }

        public string Format(string formato, object arg, IFormatProvider formatProvider)
        {
            // Proveer un formato por defecto si el argumento no es un Int64. 
            if (arg.GetType() != typeof(Int64))
                try
                {
                    return ManejarOtrosFormatos(formato, arg);
                }
                catch (FormatException e)
                {
                    throw new FormatException(String.Format("El formato '{0}' es inválido.", formato), e);
                }

            // Proveer un formato por defecto si es una cadena no soportada. 
            string tipoF = formato.ToUpper(CultureInfo.InvariantCulture);
            if (!(tipoF == "G" || tipoF == "E"))
                try
                {
                    return ManejarOtrosFormatos(formato, arg);
                }
                catch (FormatException e)
                {
                    throw new FormatException(String.Format("El formato '{0}' es inválido.", formato), e);
                }

            // Convertir el argumento a string. 
            string resultado = arg.ToString();

            // Si el número de cuenta tiene menos de 12 dígitos, completar con 0
            if (resultado.Length < LARGO_CUENTA)
                resultado = resultado.PadLeft(LARGO_CUENTA, '0');
            // Si el número de cuenta tiene menos de 12 dígitos, truncar a 12 caracteres. 
            if (resultado.Length > LARGO_CUENTA)
                resultado = resultado.Substring(0, LARGO_CUENTA);

            if (tipoF == "E")                    // Formato sólo para enteros.  
                return resultado;
            // Agregar guiones para el formato G. 
            else                                          // Formato con guiones. 
                return resultado.Substring(0, 5) + "-" + resultado.Substring(5, 3) + "-" + resultado.Substring(8);
        }

        private string ManejarOtrosFormatos(string formato, object arg)
        {
            if (arg is IFormattable)
                return ((IFormattable)arg).ToString(formato, CultureInfo.CurrentCulture);
            else if (arg != null)
                return arg.ToString();
            else
                return String.Empty;
        }
    }
}
