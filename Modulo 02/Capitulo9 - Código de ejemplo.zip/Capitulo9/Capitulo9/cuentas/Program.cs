﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace cuentas
{
    class Program
    {
        public enum DiasDeLaSemana { Lunes = 1, 
                                    Martes = 2,
                                    Miercoles = 3,
                                    Jueves = 4,
                                    Viernes = 5
                                };
        static void Main(string[] args)
        {
            long nroCuenta;
            double balance;
            DiasDeLaSemana diaSemana;
            string salida;

            nroCuenta = 104254567890;
            balance = 16.34;
            diaSemana = DiasDeLaSemana.Lunes;

            salida = String.Format(new FormatoDelNumeroDeCuenta(),
                                   "El {2}, el balance de la cuenta {0:G} fue {1:C2}.",
                                   nroCuenta, balance, diaSemana);
            Console.WriteLine(salida);

            diaSemana = DiasDeLaSemana.Martes;
            salida = String.Format(new FormatoDelNumeroDeCuenta(),
                                   "El {2}, el balance de la cuenta {0:E} fue {1:C2}.",
                                   nroCuenta, balance, diaSemana);
            Console.WriteLine(salida);
            Console.ReadKey();
        }
    }
}
