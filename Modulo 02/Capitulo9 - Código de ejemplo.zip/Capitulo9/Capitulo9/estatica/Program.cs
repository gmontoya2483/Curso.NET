﻿using System;
using System.Text.RegularExpressions;

namespace estatica
{
    class Program
    {
        static void Main(string[] args)
        {
            if (Regex.IsMatch("192.168.100.1", @"\d{1,3}"))
            {
                MatchCollection mc = Regex.Matches("192.168.100.1", @"\d{1,3}");
                foreach (Match coincidencia in mc)
                    Console.WriteLine(coincidencia.Value);
            }
            else
            {
                Console.WriteLine("No se encontraron coincidencias");
            }
            Console.ReadKey();
        }
    }
}
