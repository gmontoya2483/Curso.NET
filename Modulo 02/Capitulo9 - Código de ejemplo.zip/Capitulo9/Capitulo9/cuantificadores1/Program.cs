﻿using System;
using System.Text.RegularExpressions;

namespace cuantificadores1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Buscando con am* (si aparece el literal 'a' y se repite 0 o más veces 'm')");
            BuscarCoincidencias("amatista", @"am*");
            BuscarCoincidencias("camarones", @"am*");
            BuscarCoincidencias("enmarca", @"am*");
            BuscarCoincidencias("am", @"am*");

            Console.WriteLine("Buscando con am+ (si aparece el literal 'a' y se repite 1 o más veces 'm')");
            BuscarCoincidencias("amatista", @"am+");
            BuscarCoincidencias("camarones", @"am+");
            BuscarCoincidencias("enmarca", @"am+");
            BuscarCoincidencias("panam", @"am+");
            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex myRegex = new Regex(patron);
            bool coincidencia = myRegex.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (coincidencia)
                foreach (Match match in Regex.Matches(cadena, patron))
                    Console.WriteLine(match.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}
