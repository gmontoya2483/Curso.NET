﻿using System;
using System.Text.RegularExpressions;

namespace grupos
{
    class Program
    {
        static void Main(string[] args)
        {
            string patron = @"(?<palabraDuplicada>\w+)\s\k<palabraDuplicada>\W(?<proximaPalabra>\w+)";

            string cadena = "Todo lo que que quiero es una una respuesta correcta.";

            Console.WriteLine("Analizando la cadena: " + cadena);
            Console.WriteLine("-------------------------------------");

            foreach (Match coincidencia in Regex.Matches(cadena, patron, RegexOptions.IgnoreCase))
            {
                Console.WriteLine("Se encuentra duplicada la palabra: '{0}'.",
                                 coincidencia.Groups["palabraDuplicada"].Value);
                Console.WriteLine("Primera aparición a partir del literal: {0}.",
                                 coincidencia.Groups["palabraDuplicada"].Index + 1);
                Console.WriteLine("Palabra a continuación: '{0}'.",
                      coincidencia.Groups["proximaPalabra"].Value);

                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
