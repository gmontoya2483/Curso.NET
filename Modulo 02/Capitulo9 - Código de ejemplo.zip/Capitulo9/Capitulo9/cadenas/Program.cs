﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace cadenas
{
    class Program
    {
        static void Main(string[] args)
        {
            string s1 = "palabras";
            string s2 = "palabra";
            string s3 = "Palabras";
            string s4 = "Este es un ejemplo de manejo de cadenas";
            string s5 = " Este es el texto a manipular ";
            Console.WriteLine("El largo de {0} es {1}", s1, s1.Length);
            Console.WriteLine("El resultado de comparar {0} con {1} es {2}", s1, s2, s1.CompareTo(s2));
            Console.WriteLine("Verificando igualdad entre {0} y {1} retorna {2}", s1, s3, s1.Equals(s3));
            Console.WriteLine("Verificando igualdad entre {0} en minúscula con {1} ({2}) retorna {3}",
            s1, s3, s3.ToLower(), s1.Equals(s3.ToLower()));
            Console.WriteLine("El índice de \"a\" en {0} es {1}", s3, s3.IndexOf('a'));
            Console.WriteLine("El último índice de \"a\" en {0} es {1}", s3, s3.LastIndexOf('a'));
            Console.WriteLine("Las palabras individuales de \"{0}\" son", s4);
            string[] palabras = s4.Split(' ');
            foreach (string palabra in palabras)
            {
                Console.WriteLine("\t {0}", palabra);
            }
            Console.WriteLine("\nla subcadena de \n\t\"{0}\" \ndesde el índice 3 hasta el índice 10 es \n\t\"{1}\"", s4, s4.Substring(3, 10));
            Console.WriteLine("\nLa cadena \n\t\"{0}\"\nsin espacios en blanco es\n\t\"{1}\"", s5, s5.Trim());
            Console.WriteLine("\nLas cadenas originales contenadas separadas por punto: \n {0}", String.Concat(s4,String.Concat(". ",s5)));  
            Console.ReadKey();
        }
    }
}
