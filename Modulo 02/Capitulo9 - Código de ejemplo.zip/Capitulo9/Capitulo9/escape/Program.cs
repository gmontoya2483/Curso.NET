﻿using System;
using System.Text.RegularExpressions;

namespace escape
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Buscando con o\\. E");
            BuscarCoincidencias("Ejemplo. Esta es una cadena", @"o\. E");

            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex myRegex = new Regex(patron);
            bool coincidencia = myRegex.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (coincidencia)
                foreach (Match match in Regex.Matches(cadena, patron))
                    Console.WriteLine(match.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}
