﻿using System;
using System.Text.RegularExpressions;

namespace cuantificadores5
{
    class Program
    {
        static void Main(string[] args)
        {
            // {n} Exactamente n ocurrencias
            Console.WriteLine("Buscando con (ama){2} (si aparece  'ama' 2 veces)");
            BuscarCoincidencias("ama", @"(ama){2}");
            BuscarCoincidencias("rpppamaamass", @"(ama){2}");
            BuscarCoincidencias("amaamaamaamaama", @"(ama){2}");
            BuscarCoincidencias("amaama", @"(ama){2}");
            BuscarCoincidencias("amaamaamaama", @"(ama){2}");

            // {n,} Al menos n ocurrencias
            Console.WriteLine("Buscando con (ama){2,} (si aparece 'ama' al menos 2 veces)");
            BuscarCoincidencias("ama", @"(ama){2}");
            BuscarCoincidencias("rpppamaamass", @"a{2,}");
            BuscarCoincidencias("amaamaamaamaama", @"a{2,}");
            BuscarCoincidencias("amaama", @"a{2,}");
            BuscarCoincidencias("amaamaamaama", @"a{2,}");

            // {,n} Hasta n ocurrencias
            Console.WriteLine("Buscando con (ama){,2} (si aparece 'ama' no más de 2 veces)");
            BuscarCoincidencias("ama", @"(ama){2}");
            BuscarCoincidencias("rpppamaamass", @"(ama){,2}");
            BuscarCoincidencias("amaamaamaamaama", @"(ama){,2}");
            BuscarCoincidencias("amaama", @"(ama){2,}");
            BuscarCoincidencias("amaamaamaama", @"(ama){,2}");

            // {n,m} Entre n y m ocurrencias (inclusivo)
            Console.WriteLine("Buscando con (ama){2,3} (si aparece 'ama' al menos 2 veces y hasta 3 inclusive)");
            BuscarCoincidencias("ama", @"(ama){2}");
            BuscarCoincidencias("rpppamaamass", @"(ama){2,3}");
            BuscarCoincidencias("amaamaamaamaama", @"(ama){2,3}");
            BuscarCoincidencias("amaama", @"(ama){2,3}");
            BuscarCoincidencias("amaamaamaama", @"(ama){2,3}");
            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex myRegex = new Regex(patron);
            bool coincidencia = myRegex.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (coincidencia)
                foreach (Match match in Regex.Matches(cadena, patron))
                    Console.WriteLine(match.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}
