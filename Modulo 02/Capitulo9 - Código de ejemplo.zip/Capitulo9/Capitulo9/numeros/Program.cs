﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;

namespace numeros
{
    class Program
    {
        static void Main(string[] args)
        {
        NumberFormatInfo numberFormat =
            Thread.CurrentThread.CurrentCulture.NumberFormat;
        Console.WriteLine("Separador decimal: {0}",
            numberFormat.NumberDecimalSeparator);
        Console.WriteLine("Separador de miles: {0}",
            numberFormat.NumberGroupSeparator);
        Console.ReadKey();
        }
    }
}
