﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace culturas
{
    class Program
    {
        static void Main(string[] args)
        {
            CultureInfo cultureArgentina = new CultureInfo("es-AR", false);
            Console.WriteLine(cultureArgentina);
            Console.WriteLine(cultureArgentina.DisplayName);
            Console.ReadKey();
            Console.WriteLine("------------------------------------------");
            foreach (CultureInfo ci in
                  CultureInfo.GetCultures(CultureTypes.AllCultures))
            {
                Console.Write(ci + "\t");
            }
            Console.ReadKey();
            Console.WriteLine("\n------------------------------------------");
            CultureInfo[] culturas = 
                CultureInfo.GetCultures(CultureTypes.SpecificCultures);
            foreach (CultureInfo cultura in culturas)
            {
                Console.Write(cultura.Name + "\t");
            }
            Console.ReadKey();
        }
    }
}
