﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading;

namespace fechas
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTimeFormatInfo formato1Fecha = new CultureInfo(
                "en-US",false).DateTimeFormat;
            DateTimeFormatInfo formato2Fecha =
            Thread.CurrentThread.CurrentCulture.DateTimeFormat;
            Console.WriteLine("Formato 1 de la fecha: {0}", formato1Fecha.ShortDatePattern);
            Console.WriteLine("Formato 2 de la fecha: {0}", formato2Fecha.ShortDatePattern);
            string fechaActual = DateTime.Now.ToString(formato1Fecha);
            Console.WriteLine("Formato 1 de la fecha actual: {0}", fechaActual);
            fechaActual = DateTime.Now.ToString(formato2Fecha);
            Console.WriteLine("Formato 2 de la fecha actual: {0}", fechaActual);
            Console.ReadKey();
        }
    }
}
