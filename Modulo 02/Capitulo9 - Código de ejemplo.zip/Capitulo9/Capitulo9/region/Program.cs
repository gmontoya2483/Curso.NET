﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace region
{
    class Program
    {
        static void Main(string[] args)
        {
            RegionInfo region = new RegionInfo("AR");
            Console.WriteLine("Name: {0}", region.Name);
            Console.WriteLine("DisplayName: {0}", region.DisplayName);
            Console.WriteLine("CurrencySymbol: {0}", region.CurrencySymbol);
            Console.ReadKey();
        }
    }
}
