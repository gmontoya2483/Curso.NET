﻿using System;
using System.Text.RegularExpressions;

namespace cuantificadores3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Buscando con am*a (si aparece 'a', 0 o más 'm' y una 'a')");
            BuscarCoincidencias("amatista", @"am*a");
            BuscarCoincidencias("camarones", @"am*a");
            BuscarCoincidencias("enmaa", @"am*a");
            BuscarCoincidencias("ammmmmmma", @"am*a");

            Console.WriteLine("Buscando con am?a (si aparece una 'm' entre dos 'a')");
            BuscarCoincidencias("amatista", @"am?a");
            BuscarCoincidencias("camarones", @"am?a");
            BuscarCoincidencias("enmaa", @"am?a");
            BuscarCoincidencias("ammmmmmma", @"am?a");

            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex expRegular = new Regex(patron);
            bool hayCoincidencia = expRegular.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (hayCoincidencia)
                foreach (Match coincidencia in Regex.Matches(cadena, patron))
                    Console.WriteLine(coincidencia.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}
