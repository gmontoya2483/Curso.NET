﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace mutables
{
    class Program
    {
        static void Main(string[] args)
        {
            bool bandera = false;
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("El valor booleano es ").Append(bandera).Append(".");
            Console.WriteLine(sb.ToString());
            Console.WriteLine("-------------------------------------");
            decimal valor = 1346.19m;
            sb.Append('*', 5).Append(valor).Append('*', 5);
            Console.WriteLine(sb);
            Console.WriteLine("-------------------------------------");
            sb.AppendLine();
            int indiceAux = sb.Length - 2;
            string str = "El tercer planeta;Tierra;Venus;Marte";
            int indice = 0;
            int largo = str.IndexOf(';', indice);
            sb.Append(str, indice, largo).Append(", la ");
            indice += largo + 1;
            largo = str.IndexOf(';', indice) - indice;
            sb.Append(str, indice, largo).Append(", está entre ");
            indice += largo + 1;
            largo = str.IndexOf(';', indice) - indice;
            sb.Append(str, indice, largo).Append(" y ");
            indice += largo + 1;
            sb.Append(str, indice, str.Length - indice);
            Console.WriteLine(sb);
            Console.WriteLine("-------------------------------------");
            sb.Insert(indiceAux, "\nEn el sistema solar: ");
            Console.WriteLine(sb);
            Console.WriteLine("-------------------------------------");
            sb.Replace('*', '#');
            Console.WriteLine(sb);

            Console.ReadKey();
        }
    }
}
