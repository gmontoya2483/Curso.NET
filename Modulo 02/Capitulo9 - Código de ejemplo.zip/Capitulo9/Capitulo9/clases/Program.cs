﻿using System;
using System.Text.RegularExpressions;

namespace clases
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Buscando con o\\.\\sE");
            BuscarCoincidencias("Ejemplo. Esta es una cadena", @"o\.\sE");

            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex expRegular = new Regex(patron);
            bool hayCoincidencia = expRegular.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (hayCoincidencia)
                foreach (Match coincidencia in Regex.Matches(cadena, patron))
                    Console.WriteLine(coincidencia.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}
