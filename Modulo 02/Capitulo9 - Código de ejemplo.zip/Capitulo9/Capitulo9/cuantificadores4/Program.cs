﻿using System;
using System.Text.RegularExpressions;

namespace cuantificadores4
{
    class Program
    {
        static void Main(string[] args)
        {
            // {n} Exactamente n ocurrencias
            Console.WriteLine("Buscando con a{2} (si aparece  'a' 2 veces)");
            BuscarCoincidencias("amatista", @"a{2}");
            BuscarCoincidencias("camarones", @"a{2}");
            BuscarCoincidencias("enmaa", @"a{2}");
            BuscarCoincidencias("aaammmmmmma", @"a{2}");

            // {n,} Al menos n ocurrencias
            Console.WriteLine("Buscando con a{2,} (si aparece 'a' al menos 2 veces)");
            BuscarCoincidencias("amatista", @"a{2,}");
            BuscarCoincidencias("camarones", @"a{2,}");
            BuscarCoincidencias("enmaa", @"a{2,}");
            BuscarCoincidencias("aaammmmmmma", @"a{2,}");

            // {,n} Hasta n ocurrencias
            Console.WriteLine("Buscando con a{,2} (si aparece 'a' no más de 2 veces)");
            BuscarCoincidencias("amatista", @"a{,2}");
            BuscarCoincidencias("camarones", @"a{,2}");
            BuscarCoincidencias("enmaa", @"a{2,}");
            BuscarCoincidencias("aaammmmmmma", @"a{,2}");

            // {n,m} Entre n y m ocurrencias (inclusivo)
            Console.WriteLine("Buscando con a{2,3} (si aparece 'a' al menos 2 veces y hasta 3 inclusive)");
            BuscarCoincidencias("amatista", @"a{2,3}");
            BuscarCoincidencias("camarones", @"a{2,3}");
            BuscarCoincidencias("enmaa", @"a{2,3}");
            BuscarCoincidencias("aaammmmmmma", @"a{2,3}");
            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex expRegular = new Regex(patron);
            bool hayCoincidencia = expRegular.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (hayCoincidencia)
                foreach (Match coincidencia in Regex.Matches(cadena, patron))
                    Console.WriteLine(coincidencia.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}
