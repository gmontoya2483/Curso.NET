﻿using System;
using System.Text.RegularExpressions;

namespace gestion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Buscando con ^\\s?\\d{4}-?\\d{4}$");
            BuscarCoincidencias("4567-8910", @"^\s?\d{4}-?\d{4}$");
            BuscarCoincidencias(" 4567-8910", @"^\s?\d{4}-?\d{4}$");
            BuscarCoincidencias("  4567-8910", @"^\s?\d{4}-?\d{4}$");

            Console.WriteLine("Buscando con ^\\S?\\d{4}-?\\d{4}$");
            BuscarCoincidencias("4567-8910", @"^\S?\d{4}-?\d{4}$");
            BuscarCoincidencias(" 4567-8910", @"^\S?\d{4}-?\d{4}$");
            BuscarCoincidencias("  4567-8910", @"^\S?\d{4}-?\d{4}$");
            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex expRegular = new Regex(patron);
            bool hayCoincidencia = expRegular.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (hayCoincidencia)
                foreach (Match coincidencia in Regex.Matches(cadena, patron))
                    Console.WriteLine(coincidencia.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}