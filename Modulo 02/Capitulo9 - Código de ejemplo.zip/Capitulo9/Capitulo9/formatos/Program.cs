﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace formatos
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime dateValue = new DateTime(2009, 6, 1, 4, 37, 0);
            CultureInfo[] cultures = { new CultureInfo("es-AR"),
                                         new CultureInfo("en-US"), 
                                         new CultureInfo("fr-FR"),
                                         new CultureInfo("it-IT"),
                                         new CultureInfo("de-DE") };
            foreach (CultureInfo culture in cultures)
                Console.WriteLine("{0}: {1}", culture.Name, dateValue.ToString(culture));
            Console.ReadKey();
        }
    }
}
