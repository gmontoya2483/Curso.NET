﻿using System;
using System.Text.RegularExpressions;

namespace anclaje
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Buscando con ^am (que empiece con 'am')");
            BuscarCoincidencias("amatista", @"^am");
            BuscarCoincidencias("camarones", @"^am");
            BuscarCoincidencias("panam", @"^am");

            Console.WriteLine("Buscando con am$ (que termine con 'am')");
            BuscarCoincidencias("amatista", @"am$");
            BuscarCoincidencias("camarones", @"am$");
            BuscarCoincidencias("panam", @"am$");
            // Debe empezar y terminar exactamente con "am" 
            Console.WriteLine("Buscando con ^am$ (empezar y terminar exactamente con 'am')");
            BuscarCoincidencias("amatista", @"^am$");
            BuscarCoincidencias("amatista panam", @"^am$");
            BuscarCoincidencias("am", @"^am$");

            Console.ReadKey();
        }

        private static void BuscarCoincidencias(string cadena, string patron)
        {
            Regex expRegular = new Regex(patron);
            bool hayCoincidencia = expRegular.IsMatch(cadena);

            Console.WriteLine("Cadena de búsqueda: " + cadena);
            Console.WriteLine("------Valores encontrados---------");
            if (hayCoincidencia)
                foreach (Match coincidencia in Regex.Matches(cadena, patron))
                    Console.WriteLine(coincidencia.Value);
            else
                Console.WriteLine("No se encontraron coincidencias");

            Console.WriteLine("----------------------------------");
        }
    }
}
