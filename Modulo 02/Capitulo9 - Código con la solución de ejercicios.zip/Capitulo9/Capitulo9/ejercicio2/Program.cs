﻿using System;
using System.Collections;

namespace ejercicio2
{
    class Program
    {
        static ArrayList datosCliente = new ArrayList();

        static void Main(string[] args)
        {
            ClientesArgentina ca = new ClientesArgentina();

            string[] _clientes = ca.Clientes;

            foreach (string cadenaConCliente in _clientes)
            {
                Cliente nuevoCliente = new Cliente(cadenaConCliente);
                datosCliente.Add(nuevoCliente);
            }

            ClientesEEUU ceeuu = new ClientesEEUU();
            _clientes = ceeuu.Clientes;

            foreach (string cadenaConCliente in _clientes)
            {
                Cliente nuevoCliente = new Cliente(cadenaConCliente);
                datosCliente.Add(nuevoCliente);
            }

            Console.WriteLine("Salida de datos en formato unificado{0} ", Environment.NewLine);
            Imprimir();
            Console.ReadKey();
        }

        private static void Imprimir()
        {

            foreach (Cliente cliente in datosCliente)
            {
                Console.Write("Nombre: {0}", cliente.NombreCliente);
                Console.Write("\tTeléfono: {0}", cliente.Telefono);
                Console.Write("\tNacido el: {0}\n", cliente.FechaNacimiento);
            }
        }
    }
}
