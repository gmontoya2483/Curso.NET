﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    public class ClientesEEUU
    {
        private string[] _clientes = {
                "Volodin,Viktor,(676)-555-0123,03-13-1985" ,
                "Hess,Christian,(653)-555-0131,10-24-1953" ,
                "Kawai,Masato,(599)-555-0128,11-17-1951" ,
                "Skinner,Morgan,(406)-555-0124,06-25-1958" ,
                "Szymczak,Radoslaw,(199)-555-0186,10-25-1963" ,
                "Ringstrom,Titti,(457)-555-0123,06-15-1947" ,
                "Jónsdóttir,Gerda,(272)-555-0156,06-15-1947" ,
                "Petchdenlarp,Wirote,(396)-555-0177,11-17-1955" ,
                "Krebs,Peter J.,(188)-555-0134,04-26-1948" ,
                "Spanton,Ryan,(547)-555-0129,04-04-1964" ,
                "Cook,Patrick M.,(784)-555-0190,06-17-1971" ,
                "Levitan,Michal,(317)-555-0124,06-20-1947"};

        public string[] Clientes
        {
            get
            {
                return _clientes;
            }
        }
    }
}
