﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ejercicio2
{
	class Cliente
	{
        private string _nombre;
        private string _apellido;
        private string _telefono;
        private string _fechaNacimiento;

        public string NombreCliente
        {
            get
            {
                return String.Format("{0} {1}", _nombre, _apellido);
            }
        }

        public Cliente(string cadenaDelCliente)
        {
            string[] datosCliente = cadenaDelCliente.Split(',');
            _apellido = datosCliente[0];
            _nombre = datosCliente[1];
            _telefono = datosCliente[2];
            _fechaNacimiento = datosCliente[3];
            UnificarDatosClientes();
        }

        private void UnificarDatosClientes()
        {
            FormatoTelefonosClientes();
            UnificarFechaDeNacimiento();
        }
        
        private void FormatoTelefonosClientes()
        {
            Regex expRegTelefonos = ExpresionesRegulares.expRegTelEEUU;
            if (expRegTelefonos.IsMatch(_telefono))
            {
                Match coincidenciasExpReg = expRegTelefonos.Match(_telefono);

                _telefono = string.Format("01-{0}-{1}-{2}",
                    coincidenciasExpReg.Groups["NPA"],
                    coincidenciasExpReg.Groups["Exchange"],
                    coincidenciasExpReg.Groups["Station"]);
            }
            else
            {
                expRegTelefonos = ExpresionesRegulares.expRegTelAR;
                Match coincidenciasExpReg = expRegTelefonos.Match(_telefono);
                _telefono = string.Format("054-({0}){1}",
                    coincidenciasExpReg.Groups["Area"],
                    coincidenciasExpReg.Groups["Tel"]);
            }
        }

        public void UnificarFechaDeNacimiento()
        {
            Regex expRegFechas = ExpresionesRegulares.expRegFechaNacimientoEEUU;
            Match coincidenciasExpReg = Match.Empty;
            if (expRegFechas.IsMatch(_fechaNacimiento))
            {
                coincidenciasExpReg = expRegFechas.Match(_fechaNacimiento);
            }
            else
            {
                expRegFechas = ExpresionesRegulares.expRegFechaNacimientoAR;
                coincidenciasExpReg = expRegFechas.Match(_fechaNacimiento);
            }
            _fechaNacimiento = String.Format("{0}-{1}-{2}",
                coincidenciasExpReg.Groups["Anio"],
                coincidenciasExpReg.Groups["Mes"],
                coincidenciasExpReg.Groups["Dia"]);
        }

        public override string ToString()
        {
            StringBuilder stringBuilderCliente = new StringBuilder();
            stringBuilderCliente.Append(_apellido);
            stringBuilderCliente.AppendFormat(",{0}", _nombre);
            stringBuilderCliente.AppendFormat(",{0}", _telefono);
            stringBuilderCliente.AppendFormat(",{0}", _fechaNacimiento);
            return stringBuilderCliente.ToString();
        }
        public string Telefono
        {
            get
            {
                return _telefono;
            }
        }
        public string FechaNacimiento
        {
            get
            {
                return _fechaNacimiento;
            }
        }
    }
}
