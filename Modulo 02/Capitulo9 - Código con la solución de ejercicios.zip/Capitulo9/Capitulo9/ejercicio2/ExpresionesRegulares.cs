﻿using System.Text.RegularExpressions;

namespace ejercicio2
{
    class ExpresionesRegulares
    {
        /*
         * Paso 1: Generar la expresion regular que da formato a los
         *      teléfonos de Argentina
         */
        public static Regex expRegTelAR = new Regex
            (@"^\(54(?<Area>\d{3})\)[- /.](?<Tel>\d{6}\d?\d?)");
        public static Regex expRegTelEEUU = new Regex
            (@"^\((?<NPA>\d{3})\)[- /.](?<Exchange>\d{3})[- /.](?<Station>\d{4})");

        /*
         * Paso 2: Generar las fechas en el formato unificado definido para la Argentina
         */
        public static Regex expRegFechaNacimientoAR = new Regex
            (@"^(?<Dia>(0[1-9]|1[0-9]||2[0-9]|3[01]))/(?<Mes>(0[1-9]|1[012]))/(?<Anio>\d{4})$");
        public static Regex expRegFechaNacimientoEEUU = new Regex
            (@"^(?<Mes>(0[1-9]|1[012]))[- .](?<Dia>(0[1-9]|1[0-9]||2[0-9]|3[01]))[- .](?<Anio>\d{4})$");
    }
}
