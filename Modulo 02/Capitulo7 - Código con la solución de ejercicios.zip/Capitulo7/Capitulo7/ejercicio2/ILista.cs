﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    interface ILista<T>
    {
        // Métodos
        void Agregar(T x);
        void Insertar(int indice, T x);
        int IndiceDelObjeto(T x);
        bool Contiene(T x);
        void Borrar(T x);

        //Propiedades
        int Cantidad { get; }
        int Indice { get; }
        
        // Indexador
        T this[int index] { get; set; }
    }
}
