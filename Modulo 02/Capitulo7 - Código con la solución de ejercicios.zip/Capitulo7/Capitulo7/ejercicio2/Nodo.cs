﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    class Nodo<T>
    {
        private T _valor = default(T);
        private Nodo<T> _proximo;

        public Nodo(T valor, Nodo<T> proximo)
        {
            this._valor = valor;
            this._proximo = proximo;
        }

        public Nodo(T valor) : this(valor, null) { }

        ~Nodo()
        {
            // Asegurarse que no quede ninguna referencia
            _valor = default(T);
            _proximo = null;
        }
        public Nodo<T> Proximo
        {
            get
            {
                return _proximo;
            }
            set
            {
                _proximo = value;
            }
        }
        public T Valor
        {
            get
            {
                return _valor;
            }
            set
            {
                _valor = value;
            }
        }
    }
}
