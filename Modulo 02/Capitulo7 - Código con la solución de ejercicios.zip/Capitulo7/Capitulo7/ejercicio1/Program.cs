﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            ListaEnlazada<string> lista = new ListaEnlazada<string>();

            try
            {
                lista.IndiceDelObjeto("Uno");
            }
            catch (IndexOutOfRangeException e)
            {
                Console.WriteLine("Error: " + e.Message); 
            }

            lista.Agregar("Uno");
            lista.Agregar("Dos");
            lista.Agregar("Tres");

            MostrarLista(lista);

            lista.Borrar("Dos");
            MostrarLista(lista);

            lista.Borrar("Uno");
            MostrarLista(lista);

            lista.Insertar(1, "Fin");
            MostrarLista(lista);

            lista.Insertar(1, "Otro");
            MostrarLista(lista);

            lista.Insertar(0, "Primero");
            MostrarLista(lista);

            lista.Insertar(1, "El Medio");
            MostrarLista(lista);

            Console.WriteLine("Contiene 'El Medio' {0}", lista.Contiene("El Medio"));
            Console.WriteLine("El indice de 'El Medio' es {0}", lista.IndiceDelObjeto("El Medio"));
            Console.WriteLine("Contiene 'Dos' {0}", lista.Contiene("Dos"));
            Console.WriteLine("El indice de 'Dos' es {0}", lista.IndiceDelObjeto("Dos"));
            Console.WriteLine("Contiene 'Otro' {0}", lista.Contiene("Otro"));
            Console.WriteLine("El indice de 'Otro' es {0}", lista.IndiceDelObjeto("Otro"));
            Console.ReadKey();
        }

        public static void MostrarLista(ListaEnlazada<string> lista)
        {
            Console.WriteLine("---------------");
            for (int i = 0; i < lista.Cantidad; i++)
            {
                Console.WriteLine(lista[i].ToString());
            }
        }
    }
}
