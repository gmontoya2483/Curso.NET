﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    class Nodo<T>
    {
        public T valor = default(T);
        public Nodo<T> proximo;

        public Nodo(T valor, Nodo<T> proximo)
        {
            this.valor = valor;
            this.proximo = proximo;
        }

        public Nodo(T valor) : this(valor, null) { }

        ~Nodo()
        {
            // Asegurarse que no quede ninguna referencia
            valor = default(T);
            proximo = null;
        }
    }
}
