﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    class ListaEnlazada<T> : ILista<T>
    {
        Nodo<T> primero, ultimo;
        int cantidad;
        int indice = -1;

        public ListaEnlazada()
        {
            primero = ultimo = null;
            cantidad = 0;
        }

        public void Agregar(T x)
        {
            Nodo<T> nodo = new Nodo<T>(x);

            // Si la cantidad es cero se está en el primer nodo
            if (cantidad == 0)
            {
                primero = nodo;
                indice = 0;
            }
            else
            {
                // Agregar el nuevo nodo al final
                ultimo.proximo = nodo;
            }
            cantidad++;
            indice++;
            // el nuevo nodo es ahora el último
            ultimo = nodo;
        }

        public void Insertar(int indice, T x)
        {
            Nodo<T> nuevo = null;
            // Verificar que el índice este dentro del rango de nodos disponibles
            if (indice < 0 || indice > cantidad)
                throw new IndexOutOfRangeException("Valor de índice fuera de rango");
            if (indice == 0)
            {
                nuevo = new Nodo<T>(x, primero);
                primero = nuevo;
                cantidad++;
                return;
            }
            // Crear un nodo auxiliar para recorrer
            Nodo<T> aux = primero;

            // Recorrer los nodos hasta la posición anterior 
            // a la indicada en el indice recibido como argumento
            for (int i = 0; i < indice - 1; i++)
            {
                aux = aux.proximo;
            }

            // Crear un nodo nuevo para insertar el valor recibido
            // Actualizar al crear la dirección del próximo nodo 
            // en la lista
            nuevo = new Nodo<T>(x, aux.proximo);

            // Actualizar la dirección del nodo anterior
            // con la dirección de nuevo nodo insertado
            aux.proximo = nuevo;
            // Aumentar la cantidad de elementos
            cantidad++;
            // Dejar el índice apuntando al nodo actual
            this.indice = indice;
        }

        public int IndiceDelObjeto(T x)
        {
            //Nodo aux = primero;
            if (primero == null)
                throw new IndexOutOfRangeException("Valor de índice fuera de rango");

            indice = -1;
            for (Nodo<T> aux = primero; aux != null && !aux.valor.Equals(x); aux = aux.proximo)
            {
                indice++;
            }
            indice++;
            if (indice > cantidad - 1)
            {
                indice = -1;
            }
            return indice;
        }

        public bool Contiene(T x)
        {
            return IndiceDelObjeto(x) > -1;
        }

        public void Borrar(T x)
        {
            Nodo<T> anterior = null;
            Nodo<T> aux = null;
            for (aux = primero; aux != null && !aux.valor.Equals(x); aux = aux.proximo) anterior = aux;
            anterior.proximo = aux.proximo;
            cantidad--;
        }

        public int Indice
        {
            get
            {
                return indice;
            }
        }

        public int Cantidad
        {
            get
            {
                return cantidad;
            }
        }

        public T this[int index]
        {
            //Generación del indexador
            get
            {
                // Verificar el índice
                if (index >= 0 && index < cantidad)
                {
                    //Recorrer la lista hasta index 
                    Nodo<T> cursor = primero;
                    for (int i = 0; i < index; i++)

                        cursor = cursor.proximo;
                    // establecer el valor actual del índice
                    indice = index;
                    // Retornar el valor del nodo 
                    // que está en el índice 
                    return cursor.valor;
                }
                else throw new IndexOutOfRangeException("Indice fuera de rango");
            }

            //Asignación de valor por el indexador 
            set
            {
                // Verificar si está en la lista
                if (index >= 0 && index < cantidad)
                {
                    //Recorrer la lista hasta index 
                    Nodo<T> cursor = primero;
                    for (int i = 0; i < index; i++)

                        cursor = cursor.proximo;
                    //Cambiamos el valor del elemento 
                    //que está en index 
                    cursor.valor = value;
                    // establecer el valor actual del índice
                    indice = index;
                }
                else throw new IndexOutOfRangeException("Indice fuera de rango");
            }
        }
    }
}
