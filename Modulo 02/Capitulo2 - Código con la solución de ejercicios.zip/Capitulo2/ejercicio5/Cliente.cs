﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operacionesBancarias
{
    class Cliente
    {
        private String primerNombre;
        private String apellido;
        private Cuenta cuenta;

        public Cliente(String nombre, String apellido)
        {
            this.primerNombre = nombre;
            this.apellido = apellido;
        }

        public String PrimerNombre
        {
            get
            {
                return primerNombre;
            }
        }

        public String Apellido
        {
            get
            {
                return apellido;
            }
        }

        public Cuenta Cuenta
        {
            get
            {
                return cuenta;
            }
            set
            {
                this.cuenta = value;
            }
        }
    }
}
