﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3
{
    class TesteoMiPunto
    {
        static void Main(string[] args)
        {
            MiPunto comienzo, fin;

            comienzo = new MiPunto();
            fin = new MiPunto();

            comienzo.X = "10";
            comienzo.Y = "10";
            fin.X = "20";
            fin.Y = "10";

            fin.DiferenciaAlComienzo(comienzo);

            Console.WriteLine("El valor x del fin es " + fin.X);
            Console.WriteLine("El valor y del fin es " + fin.Y);
            Console.ReadKey();
        }
    }
}
