﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using transporteRefinamiento;
using animalesRefinamiento;

namespace interfaces
{
    class CampoDeAterrizaje
    {
        static void Main(string[] args)
        {
            CampoDeAterrizaje cda = new CampoDeAterrizaje();
            Helicoptero h = new Helicoptero();
            Hidroavion ha = new Hidroavion();
            Paloma p = new Paloma();
            p.Comer();
            Console.WriteLine("Autonomía del helicóptero");
            h.Autonomia();
            Console.WriteLine("Autonomía del hidroavión");
            ha.Autonomia();

            cda.PermisoParaAterrizar(h);
            cda.PermisoParaAterrizar(ha);
            cda.PermisoParaAterrizar(p);

            cda.PermisoParaDespegar(h);
            cda.PermisoParaDespegar(ha);
            cda.PermisoParaDespegar(p);
            Console.ReadKey();
        }

        public void PermisoParaAterrizar(IVolador v)
        {
            v.Aterrizar();
            //v.Autonomia(); Ilegal. No es accesible Autonomia()
        }
        public void PermisoParaDespegar(IVolador v)
        {
            v.Despegar();
        }
    }
}
