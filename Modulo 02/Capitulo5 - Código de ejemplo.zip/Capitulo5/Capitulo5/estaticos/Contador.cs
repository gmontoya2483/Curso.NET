﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace estaticos
{
    public class Contador
    {
        private static int contador = 0;
        private int numeroDeSerie;

        public Contador()
        {
            contador++;
            numeroDeSerie = contador;
        }

        public static int GetContador()
        {
            return contador;
        }

        public static void IncrementarContador()
        {
            contador++;
        }
    }
}
