﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace estaticos
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("El valor de contador es " + Contador.GetContador());
            Contador c = new Contador();
            Console.WriteLine("El valor de contador es " + Contador.GetContador());
            OtraClase o = new OtraClase();
            o.IncrementarNumero();
            Console.WriteLine("El valor de contador es " + Contador.GetContador());
            Console.ReadKey();
        }
    }
}
