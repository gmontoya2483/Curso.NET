﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace indexadores
{
    class PropiedadesPorDefecto
    {
        private int[] vec = { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 };

        // Implementación de propiedad por defecto
        // <modificador> <tipo retornado> this[Object <nombre>]
        public int this[int indice]
        {
            get
            {
                return vec[indice];
            }

            set
            {
                vec[indice] = value;
            }
        }
    }
}
