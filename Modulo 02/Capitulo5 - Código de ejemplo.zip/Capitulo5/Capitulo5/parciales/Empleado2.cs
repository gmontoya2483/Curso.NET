﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace parciales
{
    public partial class Empleado
    {
        public void Trabajar()
        {
            Console.WriteLine("El empleado está trabajando");
        }
    }
}
