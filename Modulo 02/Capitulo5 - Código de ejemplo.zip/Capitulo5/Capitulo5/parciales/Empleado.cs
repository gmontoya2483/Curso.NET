﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace parciales
{
    public partial class Empleado
    {
        private String nombre = "Juan Pérez";
        private double salario = 1500.00;

        public virtual String GetDetalles()
        {
            return "Nombre: " + nombre + "\nSalario: " + salario;
        }
        public String Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }
        public double Salario
        {
            get
            {
                return salario;
            }
            set
            {
                salario = value;
            }
        }
    }
}
