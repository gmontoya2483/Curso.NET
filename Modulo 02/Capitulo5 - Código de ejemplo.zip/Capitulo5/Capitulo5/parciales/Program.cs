﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace parciales
{
    class Program
    {
        static void Main(string[] args)
        {
            Empleado e = new Empleado();
            e.Trabajar();
            Console.ReadKey();
        }
    }
}
