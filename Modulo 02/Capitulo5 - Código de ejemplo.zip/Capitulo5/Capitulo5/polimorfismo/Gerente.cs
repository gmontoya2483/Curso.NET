﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class Gerente : Empleado
    {
        private int cantidadPersonal;
        private double bono;

        public Gerente(String nombre, String apellido, double salario,
                String departamento, int cantidadPersonal)
            : base(nombre, apellido, salario, departamento)
        {
            this.cantidadPersonal = cantidadPersonal;
        }

        public override double CalculaSalario()
        {
            return salario = salario - salario * 0.21 + bono;
        }

        public override String GetDetalles()
        {
            return base.GetDetalles() + "Gerente [cantidadPersonal="
                    + cantidadPersonal + ", bono=" + bono + "]";
        }

        public int GetCantidadPersonal()
        {
            return cantidadPersonal;
        }

        public void SetCantidadPersonal(int cantidadPersonal)
        {
            this.cantidadPersonal = cantidadPersonal;
        }

        public double GetBono()
        {
            return bono;
        }

        public void SetBono(double bono)
        {
            this.bono = bono;
        }
    }
}
