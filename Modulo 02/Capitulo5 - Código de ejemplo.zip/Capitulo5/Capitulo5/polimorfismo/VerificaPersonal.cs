﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class VerificaPersonal
    {
        static void Main(string[] args)
        {
            VerificaPersonal vp = new VerificaPersonal();
            // Empleado e = new Gerente("Pedro", "Gonzalez", 10000, "Sistemas", 15);
            // //legal
            // e.SetCantidadPersonal(15); // Intento ilegal de acceder a
            // un atributo del tipo Gerente
            // La variable de referencia es declarada como un tipo
            // Empleado, por lo tanto puede acceder a elementos que
            // existan en Empleado, aunque el objeto sea de tipo Gerente

            // e.GetDetalles();
            Gerente g = new Gerente("Juan", "Perez", 10000, "Sistemas", 15);
            Empleado e = new Empleado("Sebastián", "Dominguez", 5000, "Sistemas");
            double t = vp.Pol(g);
            Console.WriteLine("Empleado: " + g.GetDetalles());
            Console.WriteLine("Tiene un sueldo de: " + t);
            t = vp.Pol(e);
            Console.WriteLine("Empleado: " + e.GetDetalles());
            Console.WriteLine("Tiene un sueldo de: " + t);
            Console.ReadKey();
        }

        public double Pol(Empleado e)
        {
            return e.CalculaSalario();
        }
    }
}

