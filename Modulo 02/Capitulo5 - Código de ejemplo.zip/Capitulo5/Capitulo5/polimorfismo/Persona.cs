﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class Persona
    {
        private String nombre;
        private String apellido;

        public Persona(String nombre, String apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }

        public virtual String GetDetalles()
        {
            return "Persona [nombre=" + nombre + ", apellido=" + apellido + "]";
        }
    }
}
