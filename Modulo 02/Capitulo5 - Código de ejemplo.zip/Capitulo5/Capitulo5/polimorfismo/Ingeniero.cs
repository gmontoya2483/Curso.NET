﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class Ingeniero:Empleado
    {
        public Ingeniero(String nombre, String apellido, double salario,
        String departamento)
            : base(nombre, apellido, salario, departamento)
        {
        }

        public override double CalculaSalario()
        {
            return base.CalculaSalario();
        }

        public override String GetDetalles()
        {
            return base.GetDetalles();
        }
    }
}
