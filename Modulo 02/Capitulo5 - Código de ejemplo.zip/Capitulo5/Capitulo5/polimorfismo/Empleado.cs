﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class Empleado : Persona
    {
        protected double salario;
        private String departamento;

        public Empleado(String nombre, String apellido, double salario,
                String departamento)
            : base(nombre, apellido)
        {
           
            this.salario = salario;
            this.departamento = departamento;
        }

        public virtual double CalculaSalario()
        {
            return salario = salario - salario * 0.21;
        }

        public override String GetDetalles()
        {
            return base.GetDetalles() + "Empleado [salario=" + salario
                    + ", departamento=" + departamento + "]";
        }
    }
}
