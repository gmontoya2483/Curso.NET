﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporte
{
    public abstract class Maritimo : Vehiculo
    {
        public abstract double MaximoCalado();
        public abstract void Zarpar();
        public abstract void Atracar();
        public abstract void Navegar();
    }
}
