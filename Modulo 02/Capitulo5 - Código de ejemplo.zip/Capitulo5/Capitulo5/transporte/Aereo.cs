﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporte
{
    public abstract class Aereo : Vehiculo
    {
        public abstract double MaximaAltitud();
        public abstract void Despegar();
        public abstract void Aterrizar();
        public abstract void Volar();
    }
}
