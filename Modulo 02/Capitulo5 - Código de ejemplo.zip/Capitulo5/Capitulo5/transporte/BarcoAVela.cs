﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporte
{
    class BarcoAVela : Barco
    {
        public override double ConsumoCombustible()
        {
            return 0;
        }
    }
}
