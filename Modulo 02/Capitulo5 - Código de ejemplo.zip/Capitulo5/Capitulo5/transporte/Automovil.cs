﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporte
{
    class Automovil : Terrestre
    {
        public override double MaximaVelocidad()
        {
            return 0.0;
        }

        public override double ConsumoCombustible()
        {
            return 0.0;
        }

        public override double Autonomia()
        {
            return 0.0;
        }
    }
}
