﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporte
{
    public abstract class Terrestre : Vehiculo
    {
        public abstract double MaximaVelocidad();
    }
}
