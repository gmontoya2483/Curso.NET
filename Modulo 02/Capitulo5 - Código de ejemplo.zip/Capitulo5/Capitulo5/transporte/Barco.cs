﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporte
{
    class Barco : Maritimo
    {
        public override double MaximoCalado()
        {
            return 0.0;
        }

        public override void Zarpar()
        {
        }

        public override void Atracar()
        {
        }

        public override void Navegar()
        {
        }

        public override double ConsumoCombustible()
        {
            return 0.0;
        }

        public override double Autonomia()
        {
            return 0.0;
        }
    }
}
