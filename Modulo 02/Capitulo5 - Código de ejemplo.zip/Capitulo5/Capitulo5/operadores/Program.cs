﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class Program
    {
        static void Main(string[] args)
        {
            Complejo num1 = new Complejo(2, 3);
            Complejo num2 = new Complejo(3, 4);

            // Sumar dos objetos del tipo Complejo (num1 y num2)
            // usando el operador sobrecargado
            Complejo sum = num1 + num2;

            Console.WriteLine("Primer número complejo:  " + num1.GetComplejo());
            Console.WriteLine("Segundo número complejo: {0}", num2.GetComplejo());
            Console.WriteLine("La suma de los dos números: {0}", sum.GetComplejo());
            Console.ReadKey();
        }
    }
}
