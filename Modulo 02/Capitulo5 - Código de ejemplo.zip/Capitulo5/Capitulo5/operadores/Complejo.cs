﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class Complejo
    {
        private int real;
        private int imaginario;

        public Complejo(int real, int imaginario)
        {
            this.real = real;
            this.imaginario = imaginario;
        }

        // Declarar el operador a sobrecargar (+), los tipos
        // que se van a sumar (dos objetos del tipo Complejo)
        // y el tipo retornado (un objeto del tipo Complejo)
        public static Complejo operator +(Complejo c1, Complejo c2)
        {
            return new Complejo(c1.real + c2.real, c1.imaginario + c2.imaginario);
        }
        public string GetComplejo()
        {
            return (real + " + " +  imaginario + "i");
        }
    }
}
