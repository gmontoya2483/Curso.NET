﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace graficos
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangulo r = new Rectangulo();
            Circulo c = new Circulo();
            MetodoPolimorfico(r);
            MetodoPolimorfico(c);
            Console.ReadKey();
        }

        public static void MetodoPolimorfico(ObjetoGrafico o)
        {
            o.Dibujar();
        }
    }
}
