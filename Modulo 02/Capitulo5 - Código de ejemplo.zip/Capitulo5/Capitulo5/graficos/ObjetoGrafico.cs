﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace graficos
{
    public abstract class ObjetoGrafico
    {
        int x, y;

        public void MoverA(int nuevaX, int nuevaY)
        {
            x = nuevaX;
            y = nuevaY;
            Console.WriteLine("Moviendo a (" + x + ", " + y + ")");
        }
        public abstract void Dibujar();
    }
}

