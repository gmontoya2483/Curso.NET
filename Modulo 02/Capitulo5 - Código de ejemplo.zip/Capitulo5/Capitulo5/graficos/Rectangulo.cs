﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace graficos
{
    class Rectangulo : ObjetoGrafico
    {
        public override void Dibujar()
        {
            Console.WriteLine("Dibujando el rectángulo");
        }
    }
}
