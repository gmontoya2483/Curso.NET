﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractasInicio
{
    class Dermatologo : Medico
    {
        private float valorHora = 0F;
        private String[] operaciones;
        private String[] diagnosticos;

        public Dermatologo(String nombre, String apellido, String[] operaciones,
                String[] diagnosticos)
            : base(nombre, apellido)
        {
            this.operaciones = operaciones;
            this.diagnosticos = diagnosticos;
        }

        public float GetValorHora()
        {
            return valorHora;
        }

        public void SetValorHora(float valorHora)
        {
            this.valorHora = valorHora;
        }

        public void HaceBiopsia()
        {

        }

        public override bool Diagnosticar(String tipoDiagnostico)
        {
            for (int i = 0; i < diagnosticos.Length; i++)
            {
                if (diagnosticos[i] != null
                        && diagnosticos[i].Equals(tipoDiagnostico))
                    return true;
            }
            return false;
        }

        public override bool Operar(String tipoOperacion)
        {
            for (int i = 0; i < operaciones.Length; i++)
            {
                if (operaciones[i] != null && operaciones[i].Equals(tipoOperacion))
                    return true;
            }
            return false;
        }


        public String[] GetOperaciones()
        {
            return operaciones;
        }

        public String[] GetDiagnosticos()
        {
            return diagnosticos;
        }
    }
}
