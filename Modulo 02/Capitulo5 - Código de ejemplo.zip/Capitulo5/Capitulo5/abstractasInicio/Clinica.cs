﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractasInicio
{
    class Clinica
    {
        static void Main(string[] args)
        {
            AdministracionDeTurnos adt = AdministracionDeTurnos.GetAdministracionDeTurnos();
            String[] operacionest = { "neurofibromatosis", "hernia de disco", "fracturas simples", "fracturas expuestas" };
            String[] diagnosticost = { "lumbalgia", "psoriasis", "fracturas", "dolores", "cervicales" };
            Traumatologo t = new Traumatologo("Iván", "Lacarra", operacionest, diagnosticost);
            adt.AgregarMedico(t);

            String[] operacionesd = { "neurofibromatosis", "carcinoma", "lipoma" };
            String[] diagnosticosd = { "liquen plano", "psoriasis", "lepra" };
            Dermatologo d = new Dermatologo("Pedro", "Rivero", operacionesd, diagnosticosd);
            adt.AgregarMedico(d);

            Kinesiologo k = new Kinesiologo("Alberto", "Tati");
            adt.AgregarMedico(k);

            String[] operacionesn = { "neurofibromatosis", "neurinoma" };
            String[] diagnosticosn = { "vértigo", "psoriasis", "náuseas", "ACV" };
            Neurologo n = new Neurologo("Pedro", "Pomar", operacionesn, diagnosticosn);
            adt.AgregarMedico(n);

            ReporteDeMedicos rm = new ReporteDeMedicos();
            rm.GenerarReporteActividades();

            Console.ReadKey();
        }
    }
}
