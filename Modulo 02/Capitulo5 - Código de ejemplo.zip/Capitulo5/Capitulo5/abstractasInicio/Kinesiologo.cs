﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractasInicio
{
    class Kinesiologo  : Medico
    {
        private float valorHora;

        public Kinesiologo(String nombre, String apellido)
            : base(nombre, apellido)
        {

        }

        public void HacerMasajes()
        {

        }

        public float GetValorHora()
        {
            return valorHora;
        }

        public void SetValorHora(float valorHora)
        {
            this.valorHora = valorHora;
        }

        public override bool Diagnosticar(String tipoDiagnostico)
        {
            return false;
        }

        public override bool Operar(String tipoOperacion)
        {
            return false;
        }
    }
}
