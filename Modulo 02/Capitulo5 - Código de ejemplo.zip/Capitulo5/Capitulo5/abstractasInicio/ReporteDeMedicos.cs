﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractasInicio
{
    class ReporteDeMedicos
    {
        public void GenerarReporteActividades()
        {
            AdministracionDeTurnos adt = AdministracionDeTurnos
                    .GetAdministracionDeTurnos();
            Medico[] listaMedicos = adt.GetListaMedicos();
            int indice = adt.GetIndice();
            String tipoDiagnostico = "psoriasis";
            String tipoOperacion = "neurofibromatosis";

            for (int i = 0; i < indice; i++)
            {
                Console.WriteLine("El médico " + listaMedicos[i].GetNombre() + " "
                        + listaMedicos[i].GetApellido());
                if (listaMedicos[i].Operar(tipoOperacion))
                    Console.WriteLine("Opera " + tipoOperacion);
                else
                    Console.WriteLine("No opera");
                if (listaMedicos[i].Diagnosticar(tipoDiagnostico))
                    Console.WriteLine("Diagnostica " + tipoDiagnostico);
                else
                    Console.WriteLine("No diagnostica");
            }
        }
    }
}
