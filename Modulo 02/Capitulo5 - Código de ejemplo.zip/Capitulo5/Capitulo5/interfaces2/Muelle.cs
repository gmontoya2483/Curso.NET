﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using transporteRefinamiento;

namespace interfaces2
{
    public class Muelle
    {
        public static void Main(string[] args)
        {
            Muelle m = new Muelle();
            Hidroavion ha = new Hidroavion();
            BarcoAVela b = new BarcoAVela();

            m.PermisoParaAtracar(ha);
            m.PermisoParaAtracar(b);

            m.PermisoParaZarpar(ha);
            m.PermisoParaZarpar(b);
        }

        public void PermisoParaZarpar(IAcuatico a)
        {
            a.Zarpar();
        }
        public void PermisoParaAtracar(IAcuatico a)
        {
            a.Atracar();
        }
    }

}
