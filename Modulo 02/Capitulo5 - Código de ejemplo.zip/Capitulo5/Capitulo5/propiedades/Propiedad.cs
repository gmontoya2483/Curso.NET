﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propiedades
{
    class Propiedad
    {
        private string cadena;

        public string Cadena
        {
            get { return cadena; }
            set { cadena = value; }
        }
    }
}
