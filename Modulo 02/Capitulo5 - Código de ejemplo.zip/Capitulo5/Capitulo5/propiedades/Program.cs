﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propiedades
{
    class Program
    {
        static void Main(string[] args)
        {
            Propiedad p = new Propiedad();
            p.Cadena = "Hola";
            Console.WriteLine(p.Cadena + " mundo!!");

            Automaticas a = new Automaticas();
            a.Nombre = "Juan";
            a.Apellido = "Pérez";
            Console.WriteLine("Nombre y Apellido: " + a.Nombre+" " + a.Apellido);

            Empleado e1 = new Empleado
            {
                Nombre = "Juan Pérez",
                Departamento = "Ventas",
                Salario = 1000
            };

            Empleado e2 = new Empleado("Oscar Toma", 20000)
            {
                Departamento = "Ingeniería"
            };

            Console.WriteLine(e1.GetDetalles());
            Console.WriteLine(e2.GetDetalles());

            Console.ReadKey();
        }
    }
}
