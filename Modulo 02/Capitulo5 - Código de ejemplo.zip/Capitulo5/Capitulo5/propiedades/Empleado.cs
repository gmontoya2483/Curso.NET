﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propiedades
{
    public class Empleado
    {
        public string Nombre { get; set; }
        public double Salario { get; set; }
        public string Departamento { get; set; }

        public Empleado(string nombre, double salario, string departamento)
        {
            Nombre = nombre;
            Salario = salario;
            Departamento = departamento;
        }

        public Empleado(string nombre, double salario)
        {
            Nombre = nombre;
            Salario = salario;
        }

        public Empleado()
        {
        }

        public virtual String GetDetalles()
        {
            return "Nombre: " + Nombre + "\nSalario: " + Salario + "\nDepartamento: " + Departamento;
        }
    }
}
