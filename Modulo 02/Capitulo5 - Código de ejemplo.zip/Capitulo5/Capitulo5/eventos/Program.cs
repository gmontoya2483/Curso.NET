﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eventos
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear un objeto Cuenta.
            Cuenta _cuenta = new Cuenta("Juan Pérez");
            // Manejar el evento CuentaConCredito en el objeto Cuenta.
            _cuenta.CuentaConCredito += OnCuentaConCredito;
            _cuenta.CuentaEnDeficit += OnCuentaEnDeficit;
            // Depositar y retirar algo de dinero.
            _cuenta.Retiro(100);
            _cuenta.Deposito(50);
            _cuenta.Deposito(70);

            Console.ReadKey();
        }
        // Manejador del evento CuentaConCredito.
        static void OnCuentaConCredito(object sender, EventArgs args)
        {
            double balance = ((CuentaEventArgs)args).Balance;
            Console.WriteLine("Cuenta con crédito, el nuevo balance es: " + balance);
        }

        // Manejador del evento CuentaEnDeficit.
        static void OnCuentaEnDeficit(object sender, EventArgs args)
        {
            double balance = ((CuentaEventArgs)args).Balance;
            Console.WriteLine("Cuenta conn déficit, el nuevo balance es: " + balance);
        }
    }
}