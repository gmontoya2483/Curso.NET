﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eventos
{
    // Clase para argumento del evento personalizada.
    public class CuentaEventArgs : EventArgs
    {
        private double _balance;
        public CuentaEventArgs(double b)
        {
            _balance = b;
        }
        public double Balance
        {
            get { return _balance; }
        }
    }
}
