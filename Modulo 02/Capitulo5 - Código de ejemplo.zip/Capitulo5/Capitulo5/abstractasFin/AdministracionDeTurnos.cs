﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractasFin
{
    class AdministracionDeTurnos
    {
        private Medico[] listaMedicos = new Medico[50];
        private int indice = 0;
        private static AdministracionDeTurnos administracionDeTurnos = new AdministracionDeTurnos();

        private AdministracionDeTurnos()
        {
        }

        public void AgregarMedico(Medico medico)
        {
            this.listaMedicos[indice++] = medico;
        }

        public Medico ObtenerMedico(int indice)
        {
            return listaMedicos[indice];
        }

        public Medico[] GetListaMedicos()
        {
            return listaMedicos;
        }

        public int GetIndice()
        {
            return indice;
        }

        public static AdministracionDeTurnos GetAdministracionDeTurnos()
        {
            return administracionDeTurnos;
        }
    }
}
