﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractasFin
{
    public abstract class Medico
    {

        private String nombre;
        private String apellido;
        protected int turnosPorHora = 0;

        public Medico(String nombre, String apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }

        public abstract bool Diagnosticar(String tipoDiagnostico);

        public abstract bool Operar(String tipoOperacion);

        public String GetNombre()
        {
            return nombre;
        }

        public void SetNombre(String nombre)
        {
            this.nombre = nombre;
        }

        public String GetApellido()
        {
            return apellido;
        }

        public void SetApellido(String apellido)
        {
            this.apellido = apellido;
        }

        public int GetTurnosPorHora()
        {
            return turnosPorHora;
        }

        public void SetTurnosPorHora(int turnosPorHora)
        {
            this.turnosPorHora = turnosPorHora;
        }
    }
}