﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anidadas
{
    class Program
    {
        static void Main(string[] args)
        {
            Exterior1 afuera1 = new Exterior1();
            Exterior2 afuera2 = new Exterior2();
            Exterior1.Anidada a1 = new Exterior1.Anidada();
            // Error, Exterior2.Anidada es private 
            // Exterior2.Anidada a2 = new Exterior2.Anidada();

            Console.WriteLine("El valor de var es " + afuera1.Var);
            afuera1.VerificaAnidada();
            Console.WriteLine("El valor de var es " + afuera1.Var);
            afuera2.VerificaAnidada();
            Console.WriteLine("El valor de var es " + afuera2.Var);
            Console.ReadKey();
        }
    }
}
