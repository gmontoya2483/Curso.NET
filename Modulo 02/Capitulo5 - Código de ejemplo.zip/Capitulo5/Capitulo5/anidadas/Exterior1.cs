﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anidadas
{
    public class Exterior1
    {
        private int var=10;

        public int Var
        {
            get
            {
                return var;
            }
        }
        /* Declaración de una clase anidada llamada Anidada */
        internal class Anidada
        {
            private Exterior1 e;
            public Anidada(Exterior1 e)
            {
                this.e = e;
            }
            public Anidada():this(new Exterior1())
            {
            }
            public void HaceAlgo()
            {
                // La clase anidada tiene acceso a la variable var
                // de la clase exterior
                e.var=0;
                e.var++;
                Console.WriteLine("El valor de Exterior1.var en Exterior1.Anidada.haceAlgo es " + e.Var);
          }
        }

        public void VerificaAnidada()
        {
            Anidada i = new Anidada();
            i.HaceAlgo();
        }
    }
}
