﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace anidadas
{
    public class Exterior2
    {
        private int var = 88;

        public int Var
        {
            get
            {
                return var;
            }
        }

        private class Anidada
        {
            private int var = 99;
            private Exterior2 e;
            public Anidada(Exterior2 e)
            {
                this.e = e;
            }
             public Anidada()
                : this(new Exterior2())
            {
            }

            public void HaceAlgo(int var)
            {
                var++; // El parámetro local
                this.var++; // atributo del objeto anidado
                this.e.var++; // atributo del objeto exterior
                Console.WriteLine("El valor de Exterior2.var en Exterior2.Anidada.haceAlgo es " + e.Var);
            }
            public int Var
            {
                get
                {
                    return var;
                }
            }
        }
        public void VerificaAnidada()
        {
            Anidada i = new Anidada();
            i.HaceAlgo(10);
        }
    }
}
