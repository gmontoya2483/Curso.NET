﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodosParciales
{
    // La clase Cuenta define dos eventos públicos
    public partial class Cuenta
    {
        public event EventHandler CuentaEnDeficit;
        public event EventHandler CuentaConCredito;

        private double _balance;
        private String _nombre;

        public Cuenta(String nombre)
        {
            this._nombre = nombre;

            // Manejar el evento CuentaConCredito en el objeto Cuenta.
            CuentaConCredito += OnCuentaConCredito;
            CuentaEnDeficit += OnCuentaEnDeficit;
        }

        partial void OnCuentaConCredito(object sender, EventArgs args);
        partial void OnCuentaEnDeficit(object sender, EventArgs args);

        public void Deposito(double cantidad)
        {
            _balance += cantidad;
            if (_balance > 0 && _balance <= cantidad)
            {
                // Se acaba de obtener crédito por balance positivo, de manera que
                // se lanza el evento CuentaConCredito. Se crea una copia del objeto
                // del evento para prevenir una condición de carrera (race condition).
                EventHandler manejador = CuentaConCredito;
                if (manejador != null)
                {
                    CuentaEventArgs args = new CuentaEventArgs(_balance);
                    manejador(this, args);
                }
            }
            else
            {
                // Se acaba de obtener crédito con balance negativo, de manera que
                // se lanza el evento CuentaEnDeficit. Se crea una copia del objeto
                // del evento para prevenir una condición de carrera (race condition).
                EventHandler manejador = CuentaEnDeficit;
                if (manejador != null)
                {
                    CuentaEventArgs args = new CuentaEventArgs(_balance);
                    manejador(this, args);
                }
            }
        }

        public void Retiro(double cantidad)
        {
            _balance -= cantidad;
            if (_balance <= 0)
            {
                // Se acaba de obtener crédito con balance negativo, de manera que
                // se lanza el evento CuentaEnDeficit. Se crea una copia del objeto
                // del evento para prevenir una condición de carrera (race condition).
                EventHandler manejador = CuentaEnDeficit;
                if (manejador != null)
                {
                    CuentaEventArgs args = new CuentaEventArgs(_balance);
                    manejador(this, args);
                }
            }
        }
    }
}
