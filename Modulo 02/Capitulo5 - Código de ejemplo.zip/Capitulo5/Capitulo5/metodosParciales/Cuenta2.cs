﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodosParciales
{
    public partial class Cuenta
    {
        // Manejador del evento CuentaConCredito.
        partial void OnCuentaConCredito(object sender, EventArgs args)
        {
            double balance = ((CuentaEventArgs)args).Balance;
            Console.WriteLine("Cuenta con crédito, el nuevo balance es: " + balance);
        }

        // Manejador del evento CuentaEnDeficit.
        partial void OnCuentaEnDeficit(object sender, EventArgs args)
        {
            double balance = ((CuentaEventArgs)args).Balance;
            Console.WriteLine("Cuenta conn déficit, el nuevo balance es: " + balance);
        }
    }
}
