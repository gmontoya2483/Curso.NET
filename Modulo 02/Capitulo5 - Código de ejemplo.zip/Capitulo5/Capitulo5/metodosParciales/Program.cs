﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodosParciales
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear un objeto Cuenta.
            Cuenta _cuenta = new Cuenta("Juan Pérez");
            
            // Depositar y retirar algo de dinero.
            _cuenta.Retiro(100);
            _cuenta.Deposito(50);
            _cuenta.Deposito(70);

            Console.ReadKey();
        }

    }
}