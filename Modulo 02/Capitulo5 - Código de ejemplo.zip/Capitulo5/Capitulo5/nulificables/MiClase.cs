﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace nulificables
{
    class MiClase
    {
        public void UnMetodo(int a)
        {
        }

        public void OtroMetodo(int? a)
        {
            if (a.HasValue)
                Console.WriteLine("El valor es: " + a.Value);
        }
    }
}
