﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace nulificables
{
    class Program
    {
        static void Main(string[] args)
        {
            MiClase m = new MiClase();
            m = null;
            int a;
            m = new MiClase();
            // No se puede usar a sin inicializarla
            //m.UnMetodo(a); 
            //a = null;
            a = 5;
            m.UnMetodo(a);
            int? b = null;

            //if (b == null)
            //{
            //    b = 5;
            //    m.UnMetodo(b);
            //}

            if (b == null)
            {
                b = 5;
                m.OtroMetodo(b);
            }
            Console.ReadKey();
        }
    }
}
