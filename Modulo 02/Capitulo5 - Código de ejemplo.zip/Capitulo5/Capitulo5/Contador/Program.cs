﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace contador
{
    class Program
    {
        static void Main(string[] args)
        {
            Contador c1 = new Contador();
            Console.WriteLine("El valor de contador es {0}" , Contador.contador);
            Contador c2 = new Contador();
            Console.WriteLine("El valor de contador es {0}", Contador.contador);
            Console.ReadKey();
        }
    }
}
