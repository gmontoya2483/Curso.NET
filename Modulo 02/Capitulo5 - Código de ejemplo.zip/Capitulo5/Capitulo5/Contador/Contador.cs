﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace contador
{
    public class Contador
    {
        public static int contador = 0;
        private int numeroDeSerie;

        public Contador()
        {
            contador++;
            numeroDeSerie = contador;
        }
    }
}
