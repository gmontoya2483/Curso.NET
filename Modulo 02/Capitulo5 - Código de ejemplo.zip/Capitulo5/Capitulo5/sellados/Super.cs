﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sellados
{
    public class Super
    {
        internal int unNumero=0;
        public void met() { }
        public virtual void met2(){}
    }
}
