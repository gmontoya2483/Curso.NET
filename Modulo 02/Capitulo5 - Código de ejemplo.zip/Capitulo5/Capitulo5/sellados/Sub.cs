﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sellados
{
    public class Sub : Super
    {
        internal new int unNumero=1;

        public Sub()
        {
            int ej = base.unNumero;
        }

        public sealed override void met2()
        {
            base.met2();
        }

        //public override void met()
        //{ // ERROR

        //}
    }
}
