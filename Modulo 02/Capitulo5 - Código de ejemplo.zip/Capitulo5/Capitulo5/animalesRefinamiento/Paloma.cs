﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animalesRefinamiento
{
    public class Paloma : Aves
    {
        public override void Comer()
        {
        }

        public override void Despegar()
        {
        }

        public override void Aterrizar()
        {
        }

        public override void Volar()
        {
        }
    }
}
