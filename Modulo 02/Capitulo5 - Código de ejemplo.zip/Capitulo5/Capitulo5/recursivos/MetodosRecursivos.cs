﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recursivos
{
    class MetodosRecursivos
    {
        public long CalculaFactorial(int i)
        {
            return ((i <= 1) ? 1 : (i * CalculaFactorial(i - 1)));
        }

        public int Fib(int n)
        {
            if (n < 2)
                return n;
            else
                return Fib(n - 1) + Fib(n - 2);
        }
    }
}
