﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recursivos
{
    class Program
    {
        static void Main(string[] args)
        {
            MetodosRecursivos m = new MetodosRecursivos();

            Console.WriteLine("El factorial de 10 es: {0}", m.CalculaFactorial(10));
            Console.WriteLine("La serie de Fibonacci de 10 es: {0}", m.Fib(10));
            Console.ReadKey();
        }
    }
}
