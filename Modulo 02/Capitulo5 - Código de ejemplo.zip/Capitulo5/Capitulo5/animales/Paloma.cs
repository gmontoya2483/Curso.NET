﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    class Paloma : Aves
    {
        public override void Despegar()
        {
        }

        public override void Aterrizar()
        {
        }

        public override void Volar()
        {
        }

        public override void Comer()
        {
        }
    }
}
