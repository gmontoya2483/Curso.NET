﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
public abstract class Aves : Animal {
	public abstract void Despegar();
	public abstract void Aterrizar();
	public abstract void Volar();
	}
}
