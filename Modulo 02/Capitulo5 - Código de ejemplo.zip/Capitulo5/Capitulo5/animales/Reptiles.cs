﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    public abstract class Reptiles : Animal
    {
    }
}
