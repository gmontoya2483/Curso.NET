﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    class Lagarto : Reptiles
    {
        public override void Comer()
        {
        }
    }
}
