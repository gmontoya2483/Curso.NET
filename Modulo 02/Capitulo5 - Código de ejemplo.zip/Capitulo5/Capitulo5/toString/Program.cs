﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace toString
{
    class Program
    {
        static void Main(string[] args)
        {
            Fecha f1 = new Fecha(10, 10, 2012);
            Empleado e1 = new Empleado("Juan", f1);

            Console.WriteLine(e1);

            Console.ReadKey();
        }
    }
}
