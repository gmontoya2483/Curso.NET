﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace delegados
{
    class Program
    {
        static void Main(string[] args)
        {
            // Paso 3: Crear los objetos. Uno tiene el delegado, 
            // el otro el método a asignar al delegado
            Delegado unObjetoQueTieneDelegados = new Delegado();
            UnaClase unObjetoConUnMetodo = new UnaClase();
            UnaClase unObjetoConUnMetodo2 = new UnaClase();
            OtraClase unObjetoConUnMetodo3 = new OtraClase();

            // Paso 4: Obtener el delegado a un método privado en la clase Delegado  
            DelegadoContador metodo = unObjetoQueTieneDelegados.MetodoConContador;

            // Paso 5: Invocar al método privado en la clase Delegado como si fuera público  
            metodo();
            metodo();
            metodo();
            metodo();

            Console.WriteLine();

            // Paso 6: Agregar las firmas de las funciones a invocar
            unObjetoQueTieneDelegados.AgregaFirmaAlDelegado(unObjetoConUnMetodo.AvisemeAqui);
            unObjetoQueTieneDelegados.AgregaFirmaAlDelegado(unObjetoConUnMetodo2.AvisemeAqui);
            unObjetoQueTieneDelegados.AgregaFirmaAlDelegado(unObjetoConUnMetodo2.AvisemeAquiTambien);
            unObjetoQueTieneDelegados.AgregaFirmaAlDelegado(unObjetoConUnMetodo3.AvisemeAqui);
            unObjetoQueTieneDelegados.AgregaFirmaAlDelegado(unObjetoConUnMetodo3.AvisemeAquiTambien);

            // Paso 7: Llamar al método en la clase Delegado que invoca a las funciones 
            // agregadas al delegado
            unObjetoQueTieneDelegados.InvocaDelegados("Hola Mundo de Delegados");

            // Paso 9: Quitar una firma de las funciones a invocar
            unObjetoQueTieneDelegados.QuitaFirmaAlDelegado(unObjetoConUnMetodo2.AvisemeAqui);
            unObjetoQueTieneDelegados.QuitaFirmaAlDelegado(unObjetoConUnMetodo2.AvisemeAquiTambien);

            // Paso 10: Llamar al método en la clase Delegado que invoca a las funciones 
            // agregadas al delegado
            unObjetoQueTieneDelegados.InvocaDelegados("Hola Mundo con menos Delegados");

            unObjetoQueTieneDelegados.CalculaSerieDeFibonacci(10);

            Console.ReadKey();
        }
    }
}
