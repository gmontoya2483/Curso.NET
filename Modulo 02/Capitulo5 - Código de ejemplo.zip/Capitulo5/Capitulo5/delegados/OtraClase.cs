﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace delegados
{
    class OtraClase
    {
        public string AvisemeAqui(string texto)
        {
            Console.WriteLine("Gracias por avisar a OtraClase. " +
                "Método AvisemeAqui. " +
                "Este es el mensaje recibido: {0}", texto);
            return "Se recibió " + texto;
        }
        public string AvisemeAquiTambien(string texto)
        {
            Console.WriteLine("Gracias por avisar a OtraClase. " +
                "Método AvisemeAquiTambien. " + 
                "Este es el mensaje recibido: {0}", texto);
            return "Se recibió " + texto;
        }
    }
}
