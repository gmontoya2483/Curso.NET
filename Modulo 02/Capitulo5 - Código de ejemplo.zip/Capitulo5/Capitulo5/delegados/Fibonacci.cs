﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace delegados
{
    public class Fibonacci
    {
        private DelegadoFibonacci metodoParaCalcular;

        public Fibonacci()
        {
            metodoParaCalcular = Fib;
        }

        private int Fib(int n)
        {
            if (n < 2)
                return n;
            else
                return Fib(n - 1) + Fib(n - 2);
        }
        public DelegadoFibonacci MetodoParaCalcular
        {
            get
            {
                return metodoParaCalcular;
            }
        }
    }
}
