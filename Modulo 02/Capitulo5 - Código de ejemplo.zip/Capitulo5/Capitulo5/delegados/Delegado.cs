﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace delegados
{
    public delegate int DelegadoFibonacci(int valor);
    public delegate void DelegadoContador();

    public class Delegado
    {
        //Paso 1: Definir el tipo de firma de métodos a publicar
        public delegate string FirmaMetodoAInvocar(string texto);

        //Paso 2: Definir la variable para guardar las direcciones 
        //de las funciones a invocar
        private FirmaMetodoAInvocar metodoAInvocar;
        private DelegadoContador _metodoConContador;
        private int contadorDeLlamados = 0;

        public Delegado()
        {
            _metodoConContador = MetodoConContadorYMensaje;
        }
   
        public void AgregaFirmaAlDelegado(FirmaMetodoAInvocar metodoAInvocar)
        {
            this.metodoAInvocar += metodoAInvocar; 
        }

        public void QuitaFirmaAlDelegado(FirmaMetodoAInvocar metodoAInvocar)
        {
            this.metodoAInvocar -= metodoAInvocar;
        }

        public void InvocaDelegados(string texto)
        {
            //Paso 8: Invocar las funciones
            Console.WriteLine(metodoAInvocar(texto) + Environment.NewLine);
        }

        public void CalculaSerieDeFibonacci(int n)
        {
            Fibonacci f = new Fibonacci();
            DelegadoFibonacci df = f.MetodoParaCalcular;
            Console.WriteLine("La serie de Fibonacci para {0} es: {1}", n, df(n));
        }

        private void MetodoConContadorYMensaje()
        {
            contadorDeLlamados++;
            Console.WriteLine("Este es el llamado Nro: " + contadorDeLlamados);
        }
        public DelegadoContador MetodoConContador
        {
            get
            {
                return _metodoConContador;
            }
        }
    }
}
