﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace objeto
{
    class Empleado
    {
        private String nombre;
        private const double SALARIO_BASE = 1500.00;
        private double salario = 1500.00;
        private Fecha fechaNacimiento;

        public Empleado(String nombre, double salario, Fecha fDN)
        {
            this.nombre = nombre;
            this.salario = salario;
            this.fechaNacimiento = fDN;
        }
        public Empleado(String nombre, double salario) :
            this(nombre, salario, null)
        {
        }

        public Empleado(String nombre, Fecha fDN) :
            this(nombre, SALARIO_BASE, fDN)
        {
        }

        public Empleado(String nombre) :
            this(nombre, SALARIO_BASE)
        {
        }

        public override int GetHashCode()
        {
            const int primo = 31;
            int resultado = 1;
            resultado = primo * resultado
                    + ((fechaNacimiento == null) ? 0 : fechaNacimiento.GetHashCode());
            resultado = primo * resultado + ((nombre == null) ? 0 : nombre.GetHashCode());
            long temp;
            // Convertir a bits los puntos flotante para evitar errores
            // de redondeo en el resultado
            temp = BitConverter.DoubleToInt64Bits(salario);
            resultado = primo * resultado + (int)(temp ^ (temp >> 32));
            return resultado;
        }

        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (GetType() != obj.GetType())
                return false;
            Empleado otro = (Empleado)obj;
            if (fechaNacimiento == null)
            {
                if (otro.fechaNacimiento != null)
                    return false;
            }
            else if (!fechaNacimiento.Equals(otro.fechaNacimiento))
                return false;
            if (nombre == null)
            {
                if (otro.nombre != null)
                    return false;
            }
            else if (!nombre.Equals(otro.nombre))
                return false;
        // Convertir a bits los puntos flotante para evitar errores
        // de redondeo en el resultado
            if (BitConverter.DoubleToInt64Bits(salario) != 
                    BitConverter.DoubleToInt64Bits(otro.salario))
                return false;
            return true;
        }
    }
}
