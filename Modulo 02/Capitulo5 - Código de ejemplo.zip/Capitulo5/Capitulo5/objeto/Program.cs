﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace objeto
{
    class Program
    {
        static void Main(string[] args)
        {
            Fecha f1 = new Fecha(10, 10, 2012);
            Empleado e1 = new Empleado("Juan", f1);
            Empleado e2 = new Empleado("Juan", f1);

            Console.WriteLine(e1.Equals(e2));
            Console.WriteLine(e1.Equals(new Empleado("Juan")));

            if (e1 == e2)
            {
                Console.WriteLine("e1 es identico a e2");
            }
            else
            {
                Console.WriteLine("e1 no es identico a e2");
            }
            if (e1.Equals(e2))
            {
                Console.WriteLine("e1 es igual a e2");
            }
            else
            {
                Console.WriteLine("e1 no es igual a e2");
            }
            Console.WriteLine("asignar e2 = e1");
            e2 = e1;
            if (e1 == e2)
            {
                Console.WriteLine("e1 es identico a e2");
            }
            else
            {
                Console.WriteLine("e1 no es identico a e2");
            }
            Console.ReadKey();
        }
    }
}
