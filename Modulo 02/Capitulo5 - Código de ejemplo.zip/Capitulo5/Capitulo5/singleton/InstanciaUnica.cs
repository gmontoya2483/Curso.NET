﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace singleton
{
    public class InstanciaUnica
    {
        private static InstanciaUnica _instanciaUnica = new InstanciaUnica();

        private InstanciaUnica()
        {
            Console.WriteLine("Creando instancia única");
        }

        public static InstanciaUnica GetInstanciaUnica()
        {
            return _instanciaUnica;
        }

        public void OtroMetodo()
        {
            Console.WriteLine("Estoy en OtroMetodo");
        }

        public void OtroMetodo2()
        {
            Console.WriteLine("Estoy en OtroMetodo2");
        }
    }
}
