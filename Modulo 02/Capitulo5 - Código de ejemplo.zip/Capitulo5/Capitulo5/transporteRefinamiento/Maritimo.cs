﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporteRefinamiento
{
    public abstract class Maritimo : Vehiculo, IAcuatico
    {
        public abstract double MaximoCalado();

        public override double ConsumoCombustible()
        {
            return 0.0;
        }

        public override double Autonomia()
        {
            return 0.0;
        }

        public virtual void Zarpar()
        {
        }

        public virtual void Atracar()
        {
        }

        public virtual void Navegar()
        {
        }
    }
}
