﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporteRefinamiento
{
    public interface IVolador
    {
        void Despegar();
        void Aterrizar();
        void Volar();
    }
}
