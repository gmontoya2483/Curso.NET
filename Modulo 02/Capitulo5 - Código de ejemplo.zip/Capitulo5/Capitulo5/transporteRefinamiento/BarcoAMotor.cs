﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporteRefinamiento
{
    public class BarcoAMotor : Barco
    {
        public override double ConsumoCombustible()
        {
            return 0;
        }
    }
}
