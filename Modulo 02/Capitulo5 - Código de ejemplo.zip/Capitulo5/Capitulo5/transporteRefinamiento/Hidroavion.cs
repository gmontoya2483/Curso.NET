﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporteRefinamiento
{
    public class Hidroavion : Avion, IAcuatico
    {
        public void VerificarFlotadores()
        {

        }

        public override double ConsumoCombustible()
        {
            return 0;
        }

        public void Zarpar()
        {
        }

        public void Atracar()
        {
        }

        public void Navegar()
        {
        }
    }
}

