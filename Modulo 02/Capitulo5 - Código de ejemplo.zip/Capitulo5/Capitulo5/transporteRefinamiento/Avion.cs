﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporteRefinamiento
{
    public class Avion : Aereo
    {

        public override double MaximaAltitud()
        {
            return 0.0;
        }

        public override void Despegar()
        {
         
        }

        public override void Aterrizar()
        {
      
        }

        public override void Volar()
        {
           
        }

        public override double ConsumoCombustible()
        {
            return 0.0;
        }

        public override double Autonomia()
        {
            return 0.0;
        }
    }
}
