﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace transporteRefinamiento
{
    public abstract class Vehiculo
    {
        private String combustible;

        public abstract double ConsumoCombustible();
        public abstract double Autonomia();
    }
}
