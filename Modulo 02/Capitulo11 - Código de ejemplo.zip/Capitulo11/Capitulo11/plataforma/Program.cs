﻿using System;
using System.Collections;

namespace plataforma
{
    class Program
    {
        static void Main(string[] args)
        {
            OperatingSystem so = Environment.OSVersion;
            PlatformID idSo = so.Platform;
            String str;
            string[] unidades = Environment.GetLogicalDrives();
            string cadenaConUnidades = "";
            foreach (string unidad in unidades)
            {
                cadenaConUnidades += unidad + ", ";
            }
            cadenaConUnidades = cadenaConUnidades.TrimEnd(' ', ',');

            Console.WriteLine("Nombre de la máquina: \t" + Environment.MachineName);
            Console.WriteLine("Sistema operativo: \t" + Environment.OSVersion);
            Console.WriteLine("ID del sistema operativo:\t" + idSo);
            Console.WriteLine("Carpeta actual: \t" + Environment.CurrentDirectory);
            Console.WriteLine("Procesadores: \t" + Environment.ProcessorCount);
            Console.WriteLine("Nombre de usuario: \t" + Environment.UserName);
            Console.WriteLine("Versión del CLR: \t" + Environment.Version);
            Console.WriteLine("Memoria física asignada: \t" + Environment.WorkingSet);
            Console.WriteLine("Unidades presentes: \t" + cadenaConUnidades);
            Console.WriteLine("Directorio del sistema: {0}", Environment.SystemDirectory);
            Console.WriteLine("NewLine: {0}  Primera línea{0}  Segunda Línea{0}  Tercera Línea",
                                  Environment.NewLine);
            String consulta = "La unidad del sistema operativo es %SystemDrive% y la raíz del sistema es %SystemRoot%";
            str = Environment.ExpandEnvironmentVariables(consulta);
            Console.WriteLine("Variables de entorno del sistema: {0}  {1}", Environment.NewLine, str);

            Console.WriteLine("Variables de entorno - GetEnvironmentVariables: ");
            IDictionary variablesDeEntorno = Environment.GetEnvironmentVariables();
            foreach (DictionaryEntry de in variablesDeEntorno)
            {
                Console.WriteLine("  {0} = {1}", de.Key, de.Value);
            }

            Console.WriteLine("Camino al directorio System: {0}",
                          Environment.GetFolderPath(Environment.SpecialFolder.System));

            Console.ReadKey();
        }
    }
}
