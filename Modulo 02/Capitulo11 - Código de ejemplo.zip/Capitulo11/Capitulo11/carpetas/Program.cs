﻿using System;

namespace carpetas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Program Files: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles));
            Console.WriteLine("Common Program Files:\t" +
                Environment.GetFolderPath(Environment.SpecialFolder.CommonProgramFiles));
            Console.WriteLine("Windows Desktop: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));
            Console.WriteLine("Favorites: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.Favorites));
            Console.WriteLine("History: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.History));
            Console.WriteLine("Personal (My Documents:\t" +
                Environment.GetFolderPath(Environment.SpecialFolder.Personal));
            Console.WriteLine("Start Menu's Program:\t" +
                Environment.GetFolderPath(Environment.SpecialFolder.Programs));
            Console.WriteLine("Recent: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.Recent));
            Console.WriteLine("Send To: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.SendTo));
            Console.WriteLine("Start Menu: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.StartMenu));
            Console.WriteLine("Startup: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.Startup));
            Console.WriteLine("Windows System: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.System));
            Console.WriteLine("Application Data: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData));
            Console.WriteLine("Common Application:\t" +
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData));
            Console.WriteLine("Local Application Data:\t" +
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData));
            Console.WriteLine("Cookies: \t" +
                Environment.GetFolderPath(Environment.SpecialFolder.Cookies));
            Console.ReadKey();
        }
    }
}
