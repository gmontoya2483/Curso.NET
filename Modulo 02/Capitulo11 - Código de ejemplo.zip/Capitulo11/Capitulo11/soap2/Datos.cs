﻿using System;

namespace soap2
{
    [Serializable]
    public class Datos
    {
        private string datosPrivados = "Estos son datos privados";
        public string datosPublicos = "Estos son datos públicos";

        public string DatosPrivados
        {
            get
            {
                return datosPrivados;
            }
        }

    }
}
