﻿using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace soap2
{
    class Program
    {
        static void Main(string[] args)
        {
            Datos _datos = new Datos();
            using (FileStream fs = new FileStream(@"C:\DatosSoap.txt",
            FileMode.Create, FileAccess.Write))
            {
                SoapFormatter soapFormatter = new SoapFormatter();
                soapFormatter.Serialize(fs, _datos);
                fs.Close();
            }
        }
    }
}
