﻿using System.IO;
using System.Text;
using System;

namespace archivo
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"c:\MiArchivo.txt";

            string str1 = "Hola";
            string str2 = "Mundo";
            string str3 = "De";
            string str4 = "Archivos";

            byte[] b1 = Encoding.Unicode.GetBytes(str1);
            byte[] b2 = Encoding.Unicode.GetBytes(str2);
            byte[] b3 = Encoding.Unicode.GetBytes(str3);
            byte[] b4 = Encoding.Unicode.GetBytes(str4);

            if (File.Exists(path) == true)
            {
                File.Delete(path);
            }
            byte[] nuevaLinea = new UTF8Encoding(true).GetBytes(Environment.NewLine);
            FileStream fs = File.OpenWrite(path);
            fs.Write(b1, 0, b1.Length);
            fs.Write(nuevaLinea, 0, 2);
            fs.Write(b2, 0, b2.Length);
            fs.Write(nuevaLinea, 0, 2);
            fs.Write(b3, 0, b3.Length);
            fs.Write(nuevaLinea, 0, 2);
            fs.Write(b4, 0, b4.Length);
            fs.Flush();
            fs.Close();

            FileStream sr = File.OpenRead(path);
            while (sr.Position < sr.Length)
            {
                Console.Write(Convert.ToChar(sr.ReadByte()));
            }
            sr.Close();

            Console.ReadKey();
        }
    }
}
