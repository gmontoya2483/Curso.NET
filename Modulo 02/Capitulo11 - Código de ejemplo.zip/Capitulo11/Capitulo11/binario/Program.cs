﻿using System;
using System.IO;

namespace binario
{
    class Program
    {
        const string nombreDeArchivo = @"C:\AppSettings.dat";

        static void Main()
        {
            EscribirValoresPorDefecto();
            MostrarValoresPorDefecto();
            Console.ReadKey();
        }

        public static void EscribirValoresPorDefecto()
        {
            using (BinaryWriter escritor = new BinaryWriter(File.Open(nombreDeArchivo, FileMode.Create)))
            {
                escritor.Write(1.250F);
                escritor.Write(@"c:\Temp");
                escritor.Write(10);
                escritor.Write(true);
            }
        }

        public static void MostrarValoresPorDefecto()
        {
            float radioDelAspecto;
            string directorioTemporal;
            int tiempoDeAutoGuardado;
            bool mostrarBarraDeEstado;

            if (File.Exists(nombreDeArchivo))
            {
                using (BinaryReader lector = new BinaryReader(File.Open(nombreDeArchivo, FileMode.Open)))
                {
                    radioDelAspecto = lector.ReadSingle();
                    directorioTemporal = lector.ReadString();
                    tiempoDeAutoGuardado = lector.ReadInt32();
                    mostrarBarraDeEstado = lector.ReadBoolean();
                }

                Console.WriteLine("El radio del aspecto es: " + radioDelAspecto);
                Console.WriteLine("El directorio temporal es: " + directorioTemporal);
                Console.WriteLine("El tiempo de auto guardado: " + tiempoDeAutoGuardado);
                Console.WriteLine("¿Mostrar la barra de estado?: " + mostrarBarraDeEstado);
            }
        }
    }
}
