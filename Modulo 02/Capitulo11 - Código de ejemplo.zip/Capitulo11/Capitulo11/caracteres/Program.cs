﻿using System;
using System.Text;

namespace caracteres
{
    class Program
    {
        static void Main(string[] args)
        {
            // Caracteres para fuente Consolas: 03a3 = Σ, 2075 = ⁵, 03b2 = β
            string str1 = "\u03a3 \u2075 \u03b2";
            Encoding enc = Encoding.GetEncoding("us-ascii",
                                  new EncoderExceptionFallback(),
                                  new DecoderExceptionFallback());
            // Guardar la configuración de codificación actual
            Encoding en = Console.OutputEncoding;
            // Configurar la codificación de salida en UTF8
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("Salida con codificación: {0}", Console.OutputEncoding.ToString());
            Console.WriteLine(str1);
            
            // Configurar nuevamente la codificación original
            Console.OutputEncoding = en;
            Console.WriteLine("Salida con codificación: {0}", Console.OutputEncoding.ToString());
            Console.WriteLine(str1);

            Console.ReadKey();
        }
    }
}
