﻿using System;
using System.IO;

namespace rutas
{
    class Program
    {
        static void Main(string[] args)
        {
            string path1 = @"c:\temp\MiArchivo.txt";
            string path2 = @"c:\temp\MiArchivo";
            string path3 = @"temp";

            if (Path.HasExtension(path1))
            {
                Console.WriteLine("{0} tiene una extensión.", path1);
            }

            if (!Path.HasExtension(path2))
            {
                Console.WriteLine("{0} no tiene una extensión.", path2);
            }

            if (!Path.IsPathRooted(path3))
            {
                Console.WriteLine("La cadena {0} no contiene información de la raíz.", path3);
            }

            Console.WriteLine("La ruta completa de {0} es {1}.", path3, Path.GetFullPath(path3));
            Console.WriteLine("{0} es el lugar de los archivos temporarios.", Path.GetTempPath());
            Console.WriteLine("{0} es un archivo disponible para usar.", Path.GetTempFileName());

            Console.ReadKey();
        }
    }
}
