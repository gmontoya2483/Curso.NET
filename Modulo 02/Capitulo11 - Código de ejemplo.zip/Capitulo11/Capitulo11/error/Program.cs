﻿using System;

namespace error
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\nPrueba\a Retroceso\bRescribe");
            Console.Error.NewLine = "\r\n\r\n";
            Console.Error.WriteLine("Este es un error");
            Console.ReadKey();
        }
    }
}
