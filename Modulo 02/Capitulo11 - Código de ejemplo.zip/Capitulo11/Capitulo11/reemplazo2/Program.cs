﻿using System;
using System.Text;

namespace reemplazo2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Definir la codificación ASCII.
            Encoding cp1252r = Encoding.GetEncoding(1252,
                                              new EncoderReplacementFallback("*"),
                                              new DecoderReplacementFallback("*"));

            // Definir y mostrar una cadena de caracteres especiales.
            // Los caracteres son: Ⓢ, ⁵ , ∞
            string str1 = "\u24C8 \u2075 \u221E";
            Console.OutputEncoding = System.Text.Encoding.ASCII;
            Console.WriteLine(str1);
            foreach (var ch in str1)
                Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));

            Console.WriteLine();

            byte[] bytes = cp1252r.GetBytes(str1);
            string str2 = cp1252r.GetString(bytes);
            Console.WriteLine("¿Son iguales la cadena original y la decodificada?: {0}", str1.Equals(str2));
            if (!str1.Equals(str2))
            {
                Console.WriteLine(str2);
                foreach (var ch in str2)
                    Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));

                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
