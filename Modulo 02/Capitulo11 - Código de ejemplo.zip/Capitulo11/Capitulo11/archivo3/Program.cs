﻿using System;
using System.IO;

namespace archivo3
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"c:\MiArchivo.txt";

            string[] str1 = { "Hola", "Mundo", "De", "Archivos" };
            FileInfo fi = new FileInfo(path);
            if (fi.Exists == true)
            {
                fi.Delete();
            }

            using (StreamWriter sw = fi.CreateText())
            {
                foreach (string str in str1)
                {
                    sw.WriteLine(str);
                }
            }

            using (StreamReader sr = fi.OpenText())
            {
                string s = "";
                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }

            Console.ReadKey();
        }
    }
}
