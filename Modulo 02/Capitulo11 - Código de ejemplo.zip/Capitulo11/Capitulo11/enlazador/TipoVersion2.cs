﻿using System;
using System.Runtime.Serialization;
using System.Security.Permissions;
[Serializable]
class TipoVersion2 : ISerializable
{
    public Int32 x;
    public String nombre;

    void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
    {
        info.AddValue("x", x);
        info.AddValue("nombre", nombre);
    }

    private TipoVersion2(SerializationInfo info, StreamingContext contexto)
    {
        x = info.GetInt32("x");
        try
        {
            nombre = info.GetString("nombre");
        }
        catch (SerializationException)
        {
            // Este valor se crea porque la versión 1
            // no tiene esta variable de instancia
            nombre = "Valor por defecto rasonable";
        }
    }
}