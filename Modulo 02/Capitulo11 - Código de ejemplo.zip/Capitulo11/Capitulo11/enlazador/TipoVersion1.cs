﻿using System;
[Serializable]
class TipoVersion1
{
    public Int32 x;
}