﻿using System.Runtime.Serialization;
using System;
using System.Reflection;
sealed class DeserializationBinderDeTipoVersion1ATipoVersion2 : SerializationBinder
{
    public override Type BindToType(string nombreDelEnsamblado, string nombreDelTipo)
    {
        Type tipoParaDeserializar = null;

        // Para cada tipo diferente nombreDelEnsamblado / nombreDelTipo que 
        // se desea deserializar, establecer el tipo deseado.
        String assemVer1 = Assembly.GetExecutingAssembly().FullName;
        String _tipoVersion1 = "TipoVersion1";

        if (nombreDelEnsamblado == assemVer1 && nombreDelTipo == _tipoVersion1)
        {
            // Para utilizar un tipo de una versión de ensamblado diferente, 
            // cambiar el número de versión.
            // Para ello, descomentar la siguiente línea de código.
            // assemblyName = assemblyName.Replace("1.0.0.0", "2.0.0.0");

            // Para utilizar un tipo diferente del mismo 
            // ensamblaldo, cambiar el nombre del tipo.
            nombreDelTipo = "TipoVersion2";
        }

        // La siguiente línea retorna el tipo.
        tipoParaDeserializar = Type.GetType(String.Format("{0}, {1}",
            nombreDelTipo, nombreDelEnsamblado));

        return tipoParaDeserializar;
    }
}