﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace enlazador
{
    class Program
    {
        static void Main(string[] args)
        {
            Serializar();
            Deserializar();
            Console.ReadKey();
        }

        static void Serializar()
        {
            // Para serializar los objetos, primero se debe abrir
            // una corriente para escribir. Usar una corriente a archivo.
            FileStream fs = new FileStream(@"C:\ArchivoDeDatos.dat", FileMode.Create);

            try
            {
                // Construir un BinaryFormatter y usarlo
                // para serializar los datos en la corriente 
                BinaryFormatter formateador = new BinaryFormatter();

                // Construir un objeto del tipo TipoVersion1
                // y serializarlo
                TipoVersion1 obj = new TipoVersion1();
                obj.x = 123;
                formateador.Serialize(fs, obj);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Falló la serialización. Error: " + e.Message);
                throw;
            }
            finally
            {
                fs.Close();
            }
        }


        static void Deserializar()
        {
            TipoVersion2 obj = null;

            // Abrir el archivo que contiene los datos que desea deserializar.
            FileStream fs = new FileStream(@"C:\ArchivoDeDatos.dat", FileMode.Open);
            try
            {
                // Construir un BinaryFormatter y utilizaelo 
                // para deserializar los datos de la corriente.
                BinaryFormatter formateador = new BinaryFormatter();

                // Construir una instancia del tipo 
                // DeserializationBinderDeTipoVersion1ATipoVersion2. 
                // Este tipo puede deserializar un objeto TipoVersion1 
                // a un objeto TipoVersion2.
                formateador.Binder = new DeserializationBinderDeTipoVersion1ATipoVersion2();

                obj = (TipoVersion2)formateador.Deserialize(fs);
            }
            catch (SerializationException e)
            {
                Console.WriteLine("Falla al deserealizar. Error: " + e.Message);
                throw;
            }
            finally
            {
                fs.Close();
            }

            // Mostrar los datos para verificar como se deserealizó.
            Console.WriteLine("Tipo del objeto deserealizado: " + obj.GetType());
            Console.WriteLine("x = {0}, nombre = {1}", obj.x, obj.nombre);
        }
    }
}

