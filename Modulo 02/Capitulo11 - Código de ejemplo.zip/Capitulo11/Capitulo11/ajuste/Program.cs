﻿using System;
using System.Text;

namespace ajuste
{
    class Program
    {
        static void Main(string[] args)
        {
            // Obtener una codificación para la página de códigos 
            // 1252 (conjunto de caracteres de Europa occidental).
            Encoding cp1252 = Encoding.GetEncoding(1252);

            // Definir y mostrar una cadena de caracteres especiales.
            // Los caracteres son: Ⓢ, ⁵ , ∞
            string str = "\u24c8 \u2075 \u221e";
            Console.OutputEncoding = System.Text.Encoding.ASCII;
            Console.WriteLine("Cadena Original: " + str);
            Console.Write("Puntos de código en la cadena: ");
            foreach (var ch in str)
                Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));

            Console.WriteLine("\n");

            // Codificar una cadena Unicode.
            Byte[] bytes = cp1252.GetBytes(str);
            Console.Write("Bytes codificados: ");
            foreach (byte byt in bytes)
                Console.Write("{0:X2} ", byt);
            Console.WriteLine("\n");

            // Decodificar la cadena.
            string str2 = cp1252.GetString(bytes);
            Console.WriteLine("¿Son iguales la cadena original y la decodificada?: {0}", str.Equals(str2));
            if (!str.Equals(str2))
            {
                Console.WriteLine(str2);
                foreach (var ch in str2)
                    Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));
            }
            Console.ReadKey();
        }
    }
}
