﻿using System;

namespace soap3
{
    [Serializable]
    public class Datos
    {
        [NonSerialized]
        private string datosPrivados = "Estos son datos privados";
        public string datosPublicos = "Estos son datos públicos";
    }
}
