﻿using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace soap3
{
    class Program
    {
        static void Main(string[] args)
        {
            Datos data = new Datos();
            using (FileStream fileStream = new FileStream(@"C:\DatosSoap.txt",
            FileMode.Create, FileAccess.Write))
            {
                SoapFormatter soapFormatter = new SoapFormatter();
                soapFormatter.Serialize(fileStream, data);
                fileStream.Close();
            }
        }
    }
}