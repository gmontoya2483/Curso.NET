﻿using System;
using System.Text;
using System.IO;
using System.Collections.Generic;

namespace archivo2
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"c:\MiArchivo.txt";

            string[] str1 = {"Hola", "Mundo", "De", "Archivos"};

            if (File.Exists(path) == true)
            {
                File.Delete(path);
            }

            File.WriteAllLines(path, str1);

            FileStream fs = File.OpenRead(path);
            while (fs.Position < fs.Length)
            {
                Console.Write(Convert.ToChar(fs.ReadByte()));
            }
            fs.Close();

            Console.ReadKey();
        }
    }
}
