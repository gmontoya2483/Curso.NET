﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace soap1
{
    class Program
    {
        static void Main(string[] args)
        {
            string mensaje = "El costo del producto 9 es:";
            // El modificador M convierte el double a decimal
            decimal precio = 149.99M;
            using (FileStream fs = new FileStream(@"C:\DatosBinarios.dat",
            FileMode.OpenOrCreate, FileAccess.Write))
            {
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fs, mensaje);
                binaryFormatter.Serialize(fs, precio);
                binaryFormatter.Serialize(fs, String.Format("{0} {1}", mensaje, precio));
                fs.Close();
            }
        }
    }
}