﻿using System;
using System.Text;

namespace codificar
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] cadenas = { "Aquí está la primera oración del día. ",
                                 "Aquí está la segunda oración del día. "};
            Codificar(cadenas, Encoding.ASCII);
            Console.WriteLine("---------------------------");
            Codificar(cadenas, Encoding.UTF8);
            Console.ReadKey();
        }

        private static void Codificar(string[] cadenas, Encoding e)
        {
            // Crear el vector a usar.
            byte[] bytes = new byte[49];
            // Crear el índice para marcar la posición.
            int indice = 0;

            Console.WriteLine("Cadenas a codificar usando {0}:", e.EncodingName);
            foreach (var valorDeLaCadena in cadenas)
            {
                Console.WriteLine("   {0}", valorDeLaCadena);

                int contador = e.GetByteCount(valorDeLaCadena);
                if (contador + indice >= bytes.Length)
                    Array.Resize(ref bytes, bytes.Length + 50);

                int caracteresEscritos = e.GetBytes(valorDeLaCadena, 0,
                                                     valorDeLaCadena.Length,
                                                     bytes, indice);

                indice = indice + caracteresEscritos;
            }
            Console.WriteLine("\nBytes codificados:");
            Console.WriteLine("{0}", MostrarValoresEnBytes(bytes, indice));
            Console.WriteLine();

            // Decodificar el vector de bytes Unicode en una cadena.
            string nuevaCadena = e.GetString(bytes, 0, indice);
            Console.WriteLine("Bytes decodificados: {0}", nuevaCadena);
        }

        private static string MostrarValoresEnBytes(byte[] bytes, int ultimo)
        {
            string cadenaRetornada = "   ";
            for (int indice = 0; indice <= ultimo - 1; indice++)
            {
                if (indice % 20 == 0)
                    cadenaRetornada += "\n   ";
                cadenaRetornada += String.Format("{0:X2} ", bytes[indice]);
            }
            return cadenaRetornada;
        }
    }
}
