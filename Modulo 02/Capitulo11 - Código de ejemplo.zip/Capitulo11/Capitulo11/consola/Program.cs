﻿using System;

namespace consola
{
    class Program
    {
        static void Main(string[] args)
        {
            String s;
            Console.WriteLine("Presionar Ctrl + Z y luego Enter para finalizar");
            Console.WriteLine("Ingresar una línea ...");
            s = Console.ReadLine();
            while (s != null)
            {
                Console.WriteLine("Se leyó: {0}", s);
                Console.WriteLine("Ingresar una línea ...");
                s = Console.ReadLine();
            }
        }
    }
}
