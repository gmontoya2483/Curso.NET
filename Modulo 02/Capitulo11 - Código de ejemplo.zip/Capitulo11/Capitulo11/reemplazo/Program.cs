﻿using System;
using System.Text;

namespace reemplazo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Definir la codificación ASCII.
            Encoding enc = Encoding.ASCII;

            // Definir y mostrar una cadena de caracteres especiales.
            // Los caracteres son: Ⓢ, ⁵ , ∞
            string str1 = "\u24C8 \u2075 \u221E";
            Console.OutputEncoding = System.Text.Encoding.ASCII;
            Console.WriteLine(str1);
            foreach (var ch in str1)
                Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));

            Console.WriteLine("\n");

            // Codificar la cadena original usando codificación ASCII.
            byte[] bytes = enc.GetBytes(str1);
            Console.Write("Bytes codificados: ");
            foreach (var byt in bytes)
                Console.Write("{0:X2} ", byt);
            Console.WriteLine("\n");

            // Decodificar los bytes ASCII.
            string str2 = enc.GetString(bytes);
            Console.WriteLine("¿Son iguales la cadena original y la decodificada?: {0}", str1.Equals(str2));
            if (!str1.Equals(str2))
            {
                Console.WriteLine(str2);
                foreach (var ch in str2)
                    Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));

                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
