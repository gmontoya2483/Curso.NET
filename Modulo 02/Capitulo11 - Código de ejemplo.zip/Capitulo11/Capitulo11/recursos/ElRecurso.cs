﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace recursos
{
    class ElRecurso : IDisposable
    {
        public bool seguir = true;

        public void UsandoElRecurso()
        {
            Console.WriteLine("Se empieza a utilizar el recurso");
            Thread t = new Thread(this.Recurso);
            t.Start();
            Thread.Sleep(50);
        }

        public void Dispose()
        {
           Console.WriteLine("\nLiberando el recurso");
           seguir = false;
        }

        public void Recurso()
        {
            int i = 0;
            while (seguir)
            {
                Console.Write("{0}\t", i++);
                Thread.Sleep(1);
            }
        }
    }
}
