﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace recursos
{
    class Program
    {
        static void Main(string[] args)
        {
            using (ElRecurso recurso = new ElRecurso())
            {
                Thread t = new Thread(recurso.UsandoElRecurso);
                t.Start();
                t.Join();
            }
            Console.WriteLine("Fuera del bloque using.");
            Console.ReadLine();
        }
    }
}
