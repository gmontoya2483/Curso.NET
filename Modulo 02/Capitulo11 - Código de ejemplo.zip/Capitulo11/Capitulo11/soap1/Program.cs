﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;

namespace soap1
{
    class Program
    {
        static void Main(string[] args)
        {
            string mensaje = "El costo del producto 9 es:";
            // El modificador M convierte el double a decimal
            decimal precio = 149.99M;
            using (FileStream fs = new FileStream(@"C:\DatosSoap.txt",
            FileMode.OpenOrCreate, FileAccess.Write))
            {
                SoapFormatter soapFormatter = new SoapFormatter();
                soapFormatter.Serialize(fs, mensaje);
                soapFormatter.Serialize(fs, precio);
                soapFormatter.Serialize(fs, String.Format("{0} {1}", mensaje, precio));
                fs.Close();
            }
        }
    }
}
