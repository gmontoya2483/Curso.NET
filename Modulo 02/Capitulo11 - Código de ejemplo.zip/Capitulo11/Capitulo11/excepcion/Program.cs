﻿using System;
using System.Text;
using System.Globalization;

namespace excepcion
{
    class Program
    {
        static void Main(string[] args)
        {
            // Definir y mostrar una cadena de caracteres especiales.
            // Los caracteres son: Ⓢ, ⁵ , ∞
            string str1 = "\u24C8 \u2075 \u221E";

            Encoding enc = Encoding.GetEncoding("us-ascii",
                                  new EncoderExceptionFallback(),
                                  new DecoderExceptionFallback());

            Console.OutputEncoding = System.Text.Encoding.ASCII;

            Console.WriteLine(str1);

            foreach (var ch in str1)
            {
                Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));
            }
            Console.WriteLine("\n");

            // Codificar la cadena original usando codificación ASCII.
            byte[] bytes = { };
            try
            {
                bytes = enc.GetBytes(str1);
                Console.Write("Bytes codificados: ");
                foreach (var byt in bytes)
                    Console.Write("{0:X2} ", byt);

                Console.WriteLine();
            }
            catch (EncoderFallbackException e)
            {
                Console.Write("Excepción: ");
                if (e.IsUnknownSurrogate())
                    Console.WriteLine("No es posible codificar el par sustituto 0x{0:X4} 0x{1:X3} en el índice {2}.",
                                      Convert.ToUInt16(e.CharUnknownHigh),
                                      Convert.ToUInt16(e.CharUnknownLow),
                                      e.Index);
                else
                    Console.WriteLine("No es posible codificar 0x{0:X4} en el índice {1}.",
                                      Convert.ToUInt16(e.CharUnknown),
                                      e.Index);
                Console.ReadKey();
                return;
            }
            Console.WriteLine();

            // Decodificar los bytes ASCII .
            try
            {
                string str2 = enc.GetString(bytes);
                Console.WriteLine("¿Son iguales la cadena original y la decodificada?: {0}", str1.Equals(str2));
                if (!str1.Equals(str2))
                {
                    Console.WriteLine(str2);
                    foreach (var ch in str2)
                        Console.Write("{0} ", Convert.ToUInt16(ch).ToString("X4"));

                    Console.WriteLine();
                }
            }
            catch (DecoderFallbackException e)
            {
                Console.Write("No es posible decodificar byte(s) ");
                foreach (byte unknown in e.BytesUnknown)
                    Console.Write("0x{0:X2} ");

                Console.WriteLine("en el índice {0}", e.Index);
            }
        }
    }
}