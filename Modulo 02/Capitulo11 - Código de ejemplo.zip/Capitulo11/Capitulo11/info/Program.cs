﻿using System;
using System.IO;

namespace info
{
    class Program
    {
        public static long LongitudDirectorio(DirectoryInfo d)
        {
            long longitud = 0;
            // Agregar el tamaño de los archivos.
            FileInfo[] fis = d.GetFiles();
            foreach (FileInfo fi in fis)
            {
                longitud += fi.Length;
            }
            // Agregar el tamaño de los subdirectorios.
            DirectoryInfo[] dis = d.GetDirectories();
            foreach (DirectoryInfo di in dis)
            {
                longitud += LongitudDirectorio(di);
            }
            return (longitud);
        }
        public static void Main(string[] args)
        {
            // Proveer un directorio existente en caso de no existir!!!!
            DirectoryInfo d = new DirectoryInfo(@"C:\Temp");
            Console.WriteLine("El tamaño de {0} y sus subdirectorios es {1} bytes.", d, LongitudDirectorio(d));
            Console.ReadKey();
        }
    }
}
