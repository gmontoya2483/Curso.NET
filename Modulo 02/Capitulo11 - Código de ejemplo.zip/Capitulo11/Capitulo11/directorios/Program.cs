﻿using System;
using System.IO;

namespace directorios
{
    class Program
    {
        static void Main(string[] args)
        {
            // Especificar con qué directorios trabajar.
            string ruta = @"c:\MiDirectorio";
            string destino = @"c:\DirectorioDePrueba";

            try
            {
                // Determinar cuando existe un directorio.
                if (!Directory.Exists(ruta))
                {
                    // Crear el directorio si no existe.
                    Directory.CreateDirectory(ruta);
                }

                if (Directory.Exists(destino))
                {
                    // Borrar el destino para asegurarse que no está.
                    Directory.Delete(destino, true);
                }

                // Mover el directorio.
                Directory.Move(ruta, destino);

                // Crear un archivo en el directorio.
                File.CreateText(destino + @"\MiArchivo.txt");

                // Contar la cantidad de archivos en el directorio destino.
                Console.WriteLine("El número de archivos en {0} es {1}",
                    destino, Directory.GetFiles(destino).Length);
            }
            catch (Exception e)
            {
                Console.WriteLine("Falló el proceso: {0}", e.ToString());
            }
            finally { }

            Console.ReadKey();
        }
    }
}
