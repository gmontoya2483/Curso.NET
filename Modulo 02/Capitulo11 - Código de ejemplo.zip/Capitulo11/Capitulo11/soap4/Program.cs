﻿using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System;
using soap2;

namespace soap4
{
    class Program
    {
        static void Main(string[] args)
        {
            Datos datos = null;
            using (FileStream fs = new FileStream(@"C:\DatosSoap.txt",
            FileMode.Open, FileAccess.Read))
            {
                SoapFormatter _soapFormatter = new SoapFormatter();
                datos = _soapFormatter.Deserialize(fs) as Datos;

                Console.WriteLine("Privados: {0}\nPúblicos: {1}", datos.DatosPrivados, datos.datosPublicos);
                fs.Close();
                Console.ReadKey();
            }
        }
    }
}
