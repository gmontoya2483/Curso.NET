﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] vec = { 1, 2, 3, 4, 5, 6, 7, 8 };
                 for (int i = 0; true; i++)
                {
                    Console.WriteLine("vec[" + i + "] es '" + vec[i] + "'");
                }
            Console.ReadKey();
        }
    }
}
