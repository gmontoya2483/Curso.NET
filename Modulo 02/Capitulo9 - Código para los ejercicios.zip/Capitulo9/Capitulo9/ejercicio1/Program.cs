﻿using System;
using System.Collections.Generic;

namespace ejercicio1
{
    class Program
    {
        static List<Cliente> datosCliente = new List<Cliente>();

        static void Main(string[] args)
        {
            ClientesArgentina ca = new ClientesArgentina();

            string[] _clientes = ca.Clientes;

            foreach (string cadenaConCliente in _clientes)
            {
                Cliente nuevoCliente = new Cliente(cadenaConCliente);
                datosCliente.Add(nuevoCliente);
                Console.WriteLine(nuevoCliente.NombreCliente + " se convierte a ");
                Console.WriteLine(nuevoCliente);
            }

            Console.ReadKey();
        }
    }
}
