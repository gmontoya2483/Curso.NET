﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class ClientesArgentina
    {

        private string[] _clientes = {
                "Verettos,Corina,(54011) 42012345,02/06/1975",
                "Andersen,Elizabeth A.,(54011) 44678901,02/02/1992",
                "Perez,Jorge,(54011) 56012345,27/08/1992",
                "Almeida,Alicia,(54223) 5678901,04/10/1993",
                "Ran,Raúl,(54011) 47567890,10/06/1968",
                "Haban,Emilia,(54011) 48678901,06/01/1954",
                "Espexce,Francisco,(54223) 4678901,09/04/1966",
                "Sapiezynska,Berta,(54011) 45456789,04/02/1947",
                "Demitro,Augusto,(54223) 5456789,02/08/1983",
                "Muller,Patricio,(54011) 45012345,15/11/1973",
                "Mudafi,Miguel Gregorio,(54223) 4012345,12/08/1982",
                "Monasterio,Juan,(54223) 3345678,26/02/1977",
                "Cohen,Iván,(54011) 47678901,08/03/1964",
                "Scardelis,María,(54011) 47789012,07/02/1960",
                "Ozolins,Pedro,(54223) 5123456,19/09/1961",
                "Motte,Sebastián,(54011) 48678901,17/09/1968"};

        public string[] Clientes
        {
            get
            {
                return _clientes;
            }
        }


    }
}
