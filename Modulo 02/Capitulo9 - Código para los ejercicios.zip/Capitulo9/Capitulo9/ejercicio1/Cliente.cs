﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace ejercicio1
{
	class Cliente
	{
        private string _nombre;
        private string _apellido;
        private string _telefono;
        private string _fechaNacimiento;

        public Cliente(string cadenaDelCliente)
        {
            /*
             * Paso 1: Procesar la cadena recibida como argumento para
             *      separarla en sus componentes. Los mismos se diferencian
             *      porque están separados por comas. Usar el método Split
             *      de la clase String para separarla en sus componentes
             */

            /*
             * Paso 2: Asignar a cada variable de instancia los componentes 
             *      de la cadena analizada, loc cuales vienen en el siguiente
             *      orden: apellido, nombre, teléfono y fecha de nacimiento
             */
            UnificarDatosClientes();
        }

        public string NombreCliente
        {
            get
            {
                /*
                 * Paso 3: Retornar una cadena con el formato: Nombre Apellido.
                 *      Utilizar el método estático String.Format
                 */
                return null;
            }
        }

        private void UnificarDatosClientes()
        {
            FormatoTelefonosClientes();
            ModificarFechaDeNacimiento();
        }
        
        private void FormatoTelefonosClientes()
        {
            /*
             * Paso 4: Separar el código de área (incluye país y localidad)
             *      del teléfono. Para ello, buscar el espacio en blanco que 
             *      los separa y obtener el índice de la posición con el método
             *      IndexOf de String
             */
 
            /*
             * Paso 5: generar una cadena a partir de la subcadena
             *      que se obtiene desde el comienzo hasta el espacio 
             *      en blanco que determina el área y asignarla a una 
             *      variable con ese nombre
             */

            /*
             * Paso 6: generar una cadena a partir de la subcadena
             *      que se obtiene desde el espacio en blanco
             *      hasta el final que determina el teléfono y  
             *      asignarla a una variable con nombre tel
             */

            /*
             * Paso 7: Modificar el contenido de la variable de
             *      instancia _telefono para que tenga el formato
             *      (XXXXX)-XXXXXXXX ó (XXXXX)-XXXXXXX.
             *      Utilizar el método estático String.Format
             */

        }

        public void ModificarFechaDeNacimiento()
        {
            /*
            * Paso 8: Procesar la variable de instancia _fechaNacimiento para
            *      separarla en sus componentes. Los mismos se diferencian
            *      porque están separados por una barra. Usar el método Split
            *      de la clase String para separarla en sus componentes
            */


            /*
             * Paso 9: Modificar el contenido de la variable de
             *      instancia _fechaNacimiento para que tenga el formato
             *      año-mes-día. Utilizar el método estático String.Format
             */

        }

        public override string ToString()
        {
            /*
             * Paso 10: Utilizar la clase StringBuilder para generar la
             *      cadena que se va a retornar de manera que este separada
             *      por comas al igual que lo estaba antes de ser procesada.
             *      Para el primer elemento usar el método Append y para 
             *      los restantes usar AppendFormat de StringBuilder para
             *      conseguir el formato deseado.
             */
         
            return null;
        }
    }
}
