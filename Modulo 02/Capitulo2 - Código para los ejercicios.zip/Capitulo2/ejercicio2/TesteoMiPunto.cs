﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    class TesteoMiPunto
    {
        static void Main(string[] args)
        {
            MiPunto comienzo, fin;

            comienzo = new MiPunto();
            fin = new MiPunto();

            comienzo.X = "10";
            comienzo.Y = "10";
            fin.X = "20";
            fin.Y = "10";

            Console.WriteLine("El valor x del comienzo es " + comienzo.X);
            Console.WriteLine("El valor y del comienzo es " + comienzo.Y);
            Console.WriteLine("El valor x del fin es " + fin.X);
            Console.WriteLine("El valor y del fin es " + fin.Y);

            MiPunto otroPunto;
            otroPunto = fin;
            Console.WriteLine("El valor x del otroPunto es " + otroPunto.X);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.Y);
            Console.WriteLine("El valor x del fin es " + fin.X);
            Console.WriteLine("El valor y del fin es " + fin.Y);

            otroPunto.X = "40";
            otroPunto.Y = "50";

            Console.WriteLine("El valor x del otroPunto es " + otroPunto.X);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.Y);
            Console.WriteLine("El valor x del fin es " + fin.X);
            Console.WriteLine("El valor y del fin es " + fin.Y);

            otroPunto.X = "47";
            otroPunto.Y = "50";

            Console.WriteLine("El valor x del otroPunto es " + otroPunto.X);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.Y);
            Console.WriteLine("El valor x del fin es " + fin.X);
            Console.WriteLine("El valor y del fin es " + fin.Y);

            Console.WriteLine("----- Operaciones aritméticas ------");
            Console.WriteLine("El valor x del comienzo es " + comienzo.X);
            Console.WriteLine("El valor y del comienzo es " + comienzo.Y);
            int finX = Int32.Parse(fin.X) - 27;
            int finY = Int32.Parse(fin.Y) - 20;

            fin.X = finX.ToString();
            fin.Y = finY.ToString();

            Console.WriteLine("El valor x del otroPunto es " + otroPunto.X);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.Y);
            Console.WriteLine("El valor x del fin es " + fin.X);
            Console.WriteLine("El valor y del fin es " + fin.Y);

            finX = Int32.Parse(fin.X) + 27;
            finY = Int32.Parse(fin.Y) + 15;

            fin.X = finX.ToString();
            fin.Y = finY.ToString();

            Console.WriteLine("El valor x del otroPunto es " + otroPunto.X);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.Y);
            Console.WriteLine("El valor x del fin es " + fin.X);
            Console.WriteLine("El valor y del fin es " + fin.Y);


            Console.ReadKey();
        }
    }
}
