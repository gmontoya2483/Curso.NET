﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operacionesBancarias
{
    class Cuenta
    {
        private double balance;

        public Cuenta(double bal)
        {
            balance = bal;
        }

        public double Balance
        {
            get
            {
                return balance;
            }
        }
        public void deposita(double cantidad)
        {
            balance += cantidad;
        }
        public void retira(double cantidad)
        {
            balance -= cantidad;
        }
    }
}
