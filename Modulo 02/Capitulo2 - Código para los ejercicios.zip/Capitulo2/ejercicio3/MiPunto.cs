﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3
{
    class MiPunto
    {
        private String x;
        private String y;

        public String toString()
        {
            return ("[" + x + "," + y + "]");
        }

        public String X
        {
            get
            {
                return x;
            }
            set
            {
                this.x = value;
            }
        }

        public String Y
        {
            get
            {
                return y;
            }
            set
            {
                this.y = value;
            }
        }

    }
}
