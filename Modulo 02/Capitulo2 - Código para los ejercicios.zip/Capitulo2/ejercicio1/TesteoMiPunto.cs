﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class TesteoMiPunto
    {
        static void Main(string[] args)
        {

        }
    }
}
