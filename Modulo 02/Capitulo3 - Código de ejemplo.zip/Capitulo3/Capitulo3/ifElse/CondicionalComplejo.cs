﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ifElse
{
    class CondicionalComplejo
    {
        public void IfAnidado(int a, int b, int c)
        {
            if (a == b)
                if (b == c)
                {
                    Console.WriteLine("Equilátero");
                    return;
                }
                else
                {
                    Console.WriteLine("Isósceles");
                    return;
                }
            else
            {
                if (b == c)
                {
                    Console.WriteLine("Isósceles");
                    return;
                }
                else
                {
                    if (a == c)
                    {
                        Console.WriteLine("Isósceles");
                        return;
                    }
                    else
                    {
                        Console.WriteLine("Escaleno");
                    }
                }
            }
        }

        public void ElseIf()
        {
            int puntuacion = 65;
            String nota = null;
            if (puntuacion >= 90)
            {
                nota = "Sobresaliente";
            }
            else if (puntuacion >= 80)
            {
                nota = "Notable";
            }
            else if (puntuacion >= 70)
            {
                nota = "Bien";
            }
            else if (puntuacion >= 60)
            {
                nota = "Suficiente";
            }
            else
            {
                nota = "Insuficiente";
            }
            Console.WriteLine("la nota es: " + nota);
        }
    }
}
