﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ifElse
{
    class CondicionalSimple
    {
        public void SimpleIf(int a, int b)
        {
            if (a == b) Console.WriteLine("a is igual a b");
            if (a > b) Console.WriteLine("a es mayor que b");
            else Console.WriteLine("b es mayor que a");
        }

        public void IfComoOperadorTernario(int a, int b)
        {
            int c;
            c = a > b ? a : b;

            if (a > b) Console.WriteLine("c almacena el valor de a = " + a);
            else Console.WriteLine("c almacena el valor de b = " + b);

        }
    }
}
