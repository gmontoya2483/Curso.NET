﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ifElse
{
    class Program
    {
        static void Main(string[] args)
        {
            CondicionalSimple cs = new CondicionalSimple();
            CondicionalComplejo cc = new CondicionalComplejo();

            cs.SimpleIf(3,4);
            cs.IfComoOperadorTernario(3, 4);

            cc.IfAnidado(2, 3, 2);
            cc.ElseIf();

            Console.ReadKey();
        }
    }
}
