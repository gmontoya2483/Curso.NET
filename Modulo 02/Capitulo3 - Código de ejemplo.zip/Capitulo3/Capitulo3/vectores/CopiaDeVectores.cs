﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class CopiaDeVectores
    {
        public void Copiar()
        {
            // Crear e inicializar un nuevo vector de Int32.
            Int32[] vectorDeInt32Original = new Int32[5] ;
            for (int i = 0; i < vectorDeInt32Original.Length; i++)
                vectorDeInt32Original[i] = i + 1;

            // Crear e inicializar un nuevo vector de Int32.
            Int32[] otroVectorDeInt32 = new Int32[5];
            for (int i = 0; i < otroVectorDeInt32.Length; i++)
                otroVectorDeInt32[i] = i + 26;

            // Imprimir en pantalla los valores contenidos en ambos vectores.
            Console.WriteLine("Vector de Int32:");
            ImprimeVector(vectorDeInt32Original);
            Console.WriteLine("Otro Vector de Int32:");
            ImprimeVector(otroVectorDeInt32);

            // Copiar el primer elemento del vector de Int32 al del otro vector.
            Array.Copy(vectorDeInt32Original, 0, otroVectorDeInt32, 0, 1);
            // Copiar los últimos dos elementos del otro vector al de Int32 original.
            Array.Copy(otroVectorDeInt32, otroVectorDeInt32.Length - 2, vectorDeInt32Original, vectorDeInt32Original.Length - 2, 2);
            // Mostrar por pantalla los valores modificados de ambos vectores.
            Console.WriteLine("Vector de Int32 original - Los últimos dos elementos son iguales al del otro vector de Int32:");
            ImprimeVector(vectorDeInt32Original);
            Console.WriteLine("Otro vector de Int32 - El primer elemento es igual al del vector de Int32 original:");
            ImprimeVector(otroVectorDeInt32);
        }

        private void ImprimeVector(Int32[] vec)
        {
            Console.Write('<');
            for (int i = 0; i < vec.Length; i++)
            {
                // imprime un elemento
                Console.Write(vec[i]);
                // imprime una coma para delimitar si no es el último elemento
                if ((i + 1) < vec.Length)
                {
                    Console.Write(", ");
                }
            }
            Console.Write('>');
            Console.Write("\n");
        }
    }
}
