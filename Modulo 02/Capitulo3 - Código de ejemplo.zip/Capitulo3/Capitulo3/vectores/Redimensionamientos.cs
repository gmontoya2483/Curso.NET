﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class Redimensionamientos
    {
        public void Redimensionar()
        {
            // Crear e inicializar un nuevo vector de cadenas.
            String[] miVector = {"Esta", "es", "una", "historia", "corta", 
            "de", "viejos", "y", "queridos", "amigos"};
            
            // Mostrar los valores almacenados en el vector.
            Console.WriteLine(
                "El vector de cadenas continene incialmente los siguientes valores:");
            ImprimirIndicesYValores(miVector);

            // Redimensionar el vector a un tamaño mayor (cinco elementos más).
            Array.Resize(ref miVector, miVector.Length + 5);

            // Imprimir en pantalla los valores contenidos actualmente.
            Console.WriteLine("Luego de redimensionar a un tamaño mayor, ");
            Console.WriteLine("La cadena contiene los siguientes valores:");
            ImprimirIndicesYValores(miVector);

            // Redimensionar el vector a un tamaño menor (dejar cuatro elementos solamente).
            Array.Resize(ref miVector, 4);

            // Imprimir en pantalla los valores contenidos actualmente.
            Console.WriteLine("Luego de redimensionar a un tamaño menor, ");
            Console.WriteLine("La cadena contiene los siguientes valores:");
            ImprimirIndicesYValores(miVector);
        }

        public void ImprimirIndicesYValores(String[] miVector)
        {
            for (int i = 0; i < miVector.Length; i++)
            {
                Console.WriteLine("   [{0}] : {1}", i, miVector[i]);
            }
            Console.WriteLine();
        }
    }
}
