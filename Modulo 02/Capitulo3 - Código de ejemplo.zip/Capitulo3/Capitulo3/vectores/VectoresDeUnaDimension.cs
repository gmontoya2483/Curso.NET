﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class VectoresDeUnaDimension
    {
        private int x;
        private int y;

        public VectoresDeUnaDimension(int var1, int var2)
        {
            x = var1;
            y = var2;
        }

        public void Vectores()
        {
            int[] vec;
            int[] vec2 = { 2, 3, 4, 5, 6, 7 };
            VectoresDeUnaDimension[] vecObj;
            VectoresDeUnaDimension[] vecObj2 ={new VectoresDeUnaDimension(5,6), 
							new VectoresDeUnaDimension(7,8), 
							new VectoresDeUnaDimension(9,10), 
							new VectoresDeUnaDimension(11,12)};
            vec = new int[5];
            for (int i = 0; i < vec.Length; i++) vec[i] = i + 1;

            Console.WriteLine("Impimiendo vec: ");
            for (int i = 0; i < vec.Length; i++)
                Console.WriteLine("Elemento " + i + ":" + vec[i]);

            Console.WriteLine("Impimiendo vec2: ");
            for (int i = 0; i < vec2.Length; i++)
                Console.WriteLine("Elemento " + i + ":" + vec2[i]);

            vecObj = new VectoresDeUnaDimension[4];
            for (int i = 0; i < vecObj.Length; i++)
                vecObj[i] = new VectoresDeUnaDimension(i * i, i + i);

            Console.WriteLine("Impimiendo vecObj: ");
            for (int i = 0; i < vecObj.Length; i++)
                Console.WriteLine("Elemento " + i + ":" +
                    " Variable x = " + vecObj[i].X +
                    " Variable y = " + vecObj[i].Y);

            Console.WriteLine("Impimiendo vecObj2: ");
            for (int i = 0; i < vecObj2.Length; i++)
                Console.WriteLine("Elemento " + i + ":" +
                    " Variable x = " + vecObj2[i].X +
                    " Variable y = " + vecObj2[i].Y);

            Console.WriteLine("Impimiendo vec: ");
            imprimeVector(vec);
            Console.WriteLine("----------------");
            Console.WriteLine("Impimiendo vec2: ");
            imprimeVector(vec2);
            Console.WriteLine("----------------");
            Console.WriteLine("Impimiendo vecObj: ");
            imprimeVector(vecObj);
            Console.WriteLine("----------------");
            Console.WriteLine("Impimiendo vecObj2: ");
            imprimeVector(vecObj2);
        }

        public int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        /**
         * Imprime un vector del tipo int con formato
         */
        private void imprimeVector(int[] vec)
        {
            Console.Write('<');
            for (int i = 0; i < vec.Length; i++)
            {
                // imprime un elemento
                Console.Write(vec[i]);
                // imprime una coma para delimitar si no es el último elemento
                if ((i + 1) < vec.Length)
                {
                    Console.Write(", ");
                }
            }
            Console.Write('>');
            Console.Write("\n");
        }

        /**
         * Imprime un vector de objetos del tipo Vectores con formato
         */
        private void imprimeVector(VectoresDeUnaDimension[] vec)
        {
            Console.Write('<');
            for (int i = 0; i < vec.Length; i++)
            {
                // imprime un elemento
                Console.Write("[" + vec[i].X + "," + vec[i].Y + "]");
                // imprime una coma para delimitar si no es el último elemento
                if ((i + 1) < vec.Length)
                {
                    Console.Write("; ");
                }
            }
            Console.Write('>');
            Console.Write("\n");
        }
    }
}
