﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class VectoresEscalonados
    {
        private int x;
        private int y;

        public VectoresEscalonados(int var1, int var2)
        {
            x = var1;
            y = var2;
        }
        /**
         * Mostrar el uso de VectoresEscalonados de tipos primitivos y referenciados
         */
        public void VectoresEscalonadosDeDosDimensiones()
        {
            int[][] dosDim = new int[4][];
            dosDim[0] = new int[5];
            dosDim[1] = new int[5];

            // se puede rescribir una dimensión
            dosDim[0] = new int[2];
            dosDim[1] = new int[4];
            dosDim[2] = new int[6];
            dosDim[3] = new int[8];


            // int[][] mat = new int [][4]; // Error

            int[][] mat1;
            int[][] mat2 = new int[][] {
	        	new int[]{0},
                new int[]{1, 2},
                new int[]{3, 4, 5},
                new int[]{6, 7, 8, 9}
		};

            VectoresEscalonados[][] matObj;
            VectoresEscalonados[][] matObj2 = new VectoresEscalonados[][] {
                new VectoresEscalonados[]{new VectoresEscalonados(11,22)},
                new VectoresEscalonados[]{new VectoresEscalonados(33,44),new VectoresEscalonados(55,66)},
                new VectoresEscalonados[]{new VectoresEscalonados(77,88),new VectoresEscalonados(99,100), new VectoresEscalonados(110,120)}};
            		
            matObj = new VectoresEscalonados[4][];
            for (int i = 0; i < matObj.Length; i++)
                matObj[i] = new VectoresEscalonados[i + 1];

            for (int i = 0; i < matObj.Length; i++)
                for (int j = 0; j < matObj[i].Length; ++j)
                    matObj[i][j] = new VectoresEscalonados(i * i, (i + 1) * (i + 1));

            mat1 = new int[4][];
            for (int i = 0; i < mat1.Length; i++) mat1[i] = new int[i + 1];
            for (int i = 0; i < mat1.Length; i++)
                for (int j = 0; j < mat1[i].Length; ++j)
                    mat1[i][j] = i + j;

            Console.WriteLine("Impimiendo mat: ");
            for (int i = 0; i < mat1.Length; i++)
                for (int j = 0; j < mat1[i].Length && j <= i; j++)
                    Console.WriteLine(mat1[i][j]);

            Console.WriteLine("Impimiendo mat2: ");
            for (int i = 0; i < mat2.Length; i++)
                for (int j = 0; j < mat2[i].Length && j <= i; j++)
                    Console.WriteLine(mat2[i][j]);

            Console.WriteLine("Impimiendo mat: ");
            for (int i = 0; i < mat1.Length; i++)
            {
                Console.WriteLine("Impimiendo fila: " + i);
                ImprimeVector(mat1[i]);
                Console.WriteLine("----------------");
            }

            Console.WriteLine("Impimiendo mat2: ");
            for (int i = 0; i < mat2.Length; i++)
            {
                Console.WriteLine("Impimiendo fila: " + i);
                ImprimeVector(mat2[i]);
                Console.WriteLine("----------------");
            }

            Console.WriteLine("Impimiendo mat: ");
            for (int i = 0; i < matObj.Length; i++)
            {
                Console.WriteLine("Impimiendo fila: " + i);
                ImprimeVector(matObj[i]);
                Console.WriteLine("----------------");
            }

            Console.WriteLine("Impimiendo mat2: ");
            for (int i = 0; i < matObj2.Length; i++)
            {
                Console.WriteLine("Impimiendo fila: " + i);
                ImprimeVector(matObj2[i]);
                Console.WriteLine("----------------");
            }
        }

        public int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public int Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }
        	
        /**
         * Imprime un vector del tipo int con formato
         */
        private void ImprimeVector(int[] vec)
        {
            Console.Write('<');
            for (int i = 0; i < vec.Length; i++)
            {
                // imprime un elemento
                Console.Write(vec[i]);
                // imprime una coma para delimitar si no es el último elemento
                if ((i + 1) < vec.Length)
                {
                    Console.Write(", ");
                }
            }
            Console.Write('>');
            Console.Write("\n");
        }
        /**
         * Imprime un vector de objetos del tipo VectoresEscalonados con formato
         */
        private void ImprimeVector(VectoresEscalonados[] vec)
        {
            Console.Write('<');
            for (int i = 0; i < vec.Length; i++)
            {
                // imprime un elemento
                Console.Write("[" + vec[i].X + "," + vec[i].Y + "]");
                // imprime una coma para delimitar si no es el último elemento
                if ((i + 1) < vec.Length)
                {
                    Console.Write("; ");
                }
            }
            Console.Write('>');
            Console.Write("\n");
        }
    }
}
