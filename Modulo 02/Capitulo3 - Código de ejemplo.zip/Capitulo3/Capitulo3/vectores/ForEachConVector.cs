﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class ForEachConVector
    {
        public char[] CrearVector()
        {
            char[] s;
            s = new char[26];
            for (int i = 0; i < 26; i++)
            {
                s[i] = (char)('A' + i);
            }
            return s;
        }

        public void ImprimirVector(char[] vector)
        {
            int i = 0;
            Console.Write('<');
            foreach (char elemento in vector)
            {
                // imprimir un elemento
                Console.Write(elemento);
                // imprimir una coma para separar si no es el último elemento
                if ((i + 1) < vector.Length)
                {
                    Console.Write(", ");
                }
                i++;
            }
            Console.Write('>');
        }
    }
}
