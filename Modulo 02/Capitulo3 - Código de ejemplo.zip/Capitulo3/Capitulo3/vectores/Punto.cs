﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class Punto
    {
        private int x;
        private int y;

        public Punto(int var1, int var2)
        {
            x = var1;
            y = var2;
        }
        public int X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }
        public int Y
        {
            get
            {
                return y;
            }
        }

        public String Imprimir()
        {
            return ("[" + x + "," + y + "]");
        }
    }
}
