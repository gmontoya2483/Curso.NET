﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class ManejoDeVectores
    {

        static void Main(string[] args)
        {
            VectoresDeUnaDimension vecs = new VectoresDeUnaDimension(3, 2);
            vecs.Vectores();

            Console.WriteLine("*****************************************");
            Console.WriteLine("Vectores de una dimensión");
            VectoresDeTiposPrimitivos v = new VectoresDeTiposPrimitivos();
            char[] caracteres = v.CrearVector();
            Console.WriteLine("Vector de tipo primitivo con for");
            v.ImprimirVector(caracteres);
            Console.WriteLine();

            Console.WriteLine("*****************************************");
            Console.WriteLine("Vector de objetos con for");
            VectoresDeObjetos vecObj = new VectoresDeObjetos();
            Punto[] puntos = vecObj.CrearVector();

            vecObj.ImprimirVector(puntos);
            Console.WriteLine();

            Console.WriteLine("*****************************************");
            Console.WriteLine("Vector multidimensional de tipo primitivo");
            Inicializaciones iv = new Inicializaciones();
            iv.VectoresDeVariasDimensiones();

            Console.WriteLine("*****************************************");
            Console.WriteLine("Vector Escalonado");
            VectoresEscalonados ve = new VectoresEscalonados(2, 3);
            ve.VectoresEscalonadosDeDosDimensiones();

            ForEachConVector f = new ForEachConVector();
            Console.WriteLine("*****************************************");
            char[] characters = f.CrearVector();
            Console.WriteLine("Vector de tipo primitivo con foreach");
            f.ImprimirVector(characters);

            Console.WriteLine("*****************************************");
            Console.WriteLine("Redimensionamiento de vectores");
            Redimensionamientos r = new Redimensionamientos();
            r.Redimensionar();

            Console.WriteLine("*****************************************");
            Console.WriteLine("Copia de vectores");
            CopiaDeVectores cv = new CopiaDeVectores();
            cv.Copiar();

            Console.ReadKey();
        }
    }
}
