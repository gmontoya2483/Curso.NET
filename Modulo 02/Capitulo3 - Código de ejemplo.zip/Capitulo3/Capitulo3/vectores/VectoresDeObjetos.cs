﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class VectoresDeObjetos
    {
        public Punto[] CrearVector()
        {
            Punto[] p;
            p = new Punto[10];
            for (int i = 0; i < 10; i++)
                p[i] = new Punto(i, i + 1);
            return p;
        }

        public void ImprimirVector(Punto[] vector)
        {
            for (int i = 0; i < vector.Length; i++)
            {
                // imprimir un elemento
                Console.WriteLine(vector[i].Imprimir());
            }
        }
    }
}
