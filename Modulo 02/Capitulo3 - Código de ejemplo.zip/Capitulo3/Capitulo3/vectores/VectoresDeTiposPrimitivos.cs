﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vectores
{
    class VectoresDeTiposPrimitivos
    {
        public char[] CrearVector()
        {
            char[] s;

            s = new char[26];
            for (int i = 0; i < 26; i++)
            {
                s[i] = (char)('A' + i);
            }

            return s;
        }

        public void ImprimirVector(char[] vector)
        {
            Console.Write('<');
            for (int i = 0; i < vector.Length; i++)
            {
                // imprimir un elemento
                Console.Write(vector[i]);
                // Imprimir una coma para delimitarlos 
                // si no es el último elemento
                if ((i + 1) < vector.Length)
                {
                    Console.Write(", ");
                }
            }
            Console.Write('>');
        }
    }
}
