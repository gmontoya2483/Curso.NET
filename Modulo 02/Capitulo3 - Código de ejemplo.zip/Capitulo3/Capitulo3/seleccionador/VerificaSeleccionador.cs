﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace seleccionador
{
    class VerificaSeleccionador
    {
        public void ArmaAuto1(int modeloDeAuto)
        {
            Auto a = new Auto();
            switch (modeloDeAuto)
            {
                case Auto.DE_LUJO:
                    a.agregarAireAcondicionado();
                    a.agregarRadio();
                    a.agregarRuedas();
                    a.agregarMotor();
                    break;
                case Auto.ESTANDARD:
                    a.agregarRadio();
                    a.agregarRuedas();
                    a.agregarMotor();
                    break;
                default:
                    a.agregarRuedas();
                    a.agregarMotor();
                    break;
            }
        }

        public void ArmaAuto2(int modeloDeAuto)
        {
            Auto a = new Auto();
            switch (modeloDeAuto)
            {
                case Auto.DE_LUJO:
                    a.agregarAireAcondicionado();
                    goto case Auto.ESTANDARD;
                case Auto.ESTANDARD:
                    a.agregarRadio();
                    a.agregarRuedas();
                    a.agregarMotor();
                    break;
            }
        }

        static void Main(string[] args)
        {
            VerificaSeleccionador v = new VerificaSeleccionador();
            Console.WriteLine("Armando auto estándar con el método ArmaAuto1");
            v.ArmaAuto1(Auto.ESTANDARD);
            Console.WriteLine("Armando auto estándar con el método ArmaAuto2");
            v.ArmaAuto2(Auto.ESTANDARD);
            Console.WriteLine("Armando auto de lujo con el método ArmaAuto1");
            v.ArmaAuto1(Auto.DE_LUJO);
            Console.WriteLine("Armando auto de lujo con el método ArmaAuto2");
            v.ArmaAuto2(Auto.DE_LUJO);

            Console.WriteLine("Imprimiendo meses");
            Meses m = new Meses();
            for (int i = 1; i < 13; i++)
            {
                Console.Write("Mes: ");
                m.ImprimeMes(i);
                Console.Write("\tDías del mes: " + m.DiasDelMes(i, 2012).ToString() + "\n");
            }


            Console.ReadKey();
        }
    }
}
