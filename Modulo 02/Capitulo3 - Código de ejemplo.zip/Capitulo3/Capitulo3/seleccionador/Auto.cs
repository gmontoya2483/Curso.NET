﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace seleccionador
{
    class Auto
    {
        public const int DE_LUJO = 1;
        public const int ESTANDARD = 2;

        public void agregarMotor()
        {
            Console.WriteLine("Agregando Motor...");
        }

        public void agregarRuedas()
        {
            Console.WriteLine("Agregando Ruedas...");
        }

        public void agregarRadio()
        {
            Console.WriteLine("Agregando Radio...");
        }

        public void agregarAireAcondicionado()
        {
            Console.WriteLine("Agregando Aire Acondicionado...");
        }
    }
}
