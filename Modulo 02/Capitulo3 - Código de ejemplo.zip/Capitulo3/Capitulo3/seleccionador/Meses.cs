﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace seleccionador
{
    public class Meses
    {
        public void ImprimeMes(int mes)
        {
            switch (mes)
            {
                case 1: Console.Write("Enero"); break;
                case 2: Console.Write("Febrero"); break;
                case 3: Console.Write("Marzo"); break;
                case 4: Console.Write("Abril"); break;
                case 5: Console.Write("Mayo"); break;
                case 6: Console.Write("Junio"); break;
                case 7: Console.Write("Julio"); break;
                case 8: Console.Write("Agosto"); break;
                case 9: Console.Write("Septiembre"); break;
                case 10: Console.Write("Octubre"); break;
                case 11: Console.Write("Noviembre"); break;
                case 12: Console.Write("Diciembre"); break;
            }
        }

        public int DiasDelMes(int mes, int anio)
        {
            int numeroDias=0;

            switch (mes)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    numeroDias = 31;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    numeroDias = 30;
                    break;
                case 2:
                    if (((anio % 4 == 0) && !(anio % 100 == 0)) || anio % 400 == 0)
                        numeroDias = 29;
                    else
                        numeroDias = 28;
                    break;
            }
            return numeroDias;
        }
    }
}
