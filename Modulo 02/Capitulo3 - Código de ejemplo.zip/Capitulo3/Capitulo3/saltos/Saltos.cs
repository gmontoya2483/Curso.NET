﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace saltos
{

    class Saltos
    {
        public void SentenciaBreak()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.Write("\t" + i);
                if (i == 4) break;
            }

            Console.Write("\n");

            int j = 0;
            while (j < 10)
            {
                j++;
                Console.Write("\t" + j);
                if (j == 5) break;
            }
            Console.WriteLine("\nTerminé!!");
        }

        public void SentenciaContinue()
        {
            for (int i = 0; i < 10; i++)
            {
                if (i % 2 != 0)
                    continue;
                Console.Write("\t" + i);
            }

            Console.Write("\n");

            int j = 0;
            while (j < 10)
            {
                j++;
                if (j % 2 == 0)
                    continue;
                Console.Write("\t" + j);
            }
            Console.WriteLine("\nTerminé!!");
        }

        public void SentenciasBrakContinueJuntas()
        {
            for (int i = 0; i < 10; i++)
            {
                if (i % 2 != 0)
                    continue;
                Console.Write("\t" + i);
                if (i == 4) break;
            }

            Console.Write("\n");

            int j = 0;
            while (j < 10)
            {
                j++;
                if (j % 2 == 0)
                    continue;
                Console.Write("\t" + j);
                if (j == 5) break;
            }
            Console.WriteLine("\nTerminé!!");
        }


        static void Main(string[] args)
        {
            Saltos s = new Saltos();
            Console.WriteLine("Probando la sentencia break");
            s.SentenciaBreak();
            Console.WriteLine("Probando la sentencia continue");
            s.SentenciaContinue();
            Console.WriteLine("Probando las sentencias break y continue juntas");
            s.SentenciasBrakContinueJuntas();
            Console.ReadKey();
        }
    }
}
