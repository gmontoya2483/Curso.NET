﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    public abstract class Animal
    {
        protected int piernas;

        protected Animal(int piernas)
        {
            this.piernas = piernas;
        }

        public abstract void Come();

        public virtual void Camina()
        {
            Console.WriteLine("Este animal camina en " + piernas + " piernas.");
        }
    }
}
