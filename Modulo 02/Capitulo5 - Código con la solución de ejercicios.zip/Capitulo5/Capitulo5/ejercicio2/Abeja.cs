﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    public class Abeja : Animal
    {
        public Abeja()
            : base(6)
        {
        }
        public override void Come()
        {
            Console.WriteLine("Las abejas comen jalea real, polen y néctar.");
        }

    }
}
