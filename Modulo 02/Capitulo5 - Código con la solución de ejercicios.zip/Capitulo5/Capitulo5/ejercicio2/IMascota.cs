﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    public interface IMascota
    {
        void SetNombre(string nombre);
        string GetNombre();
        void Jugar();
    }
}
