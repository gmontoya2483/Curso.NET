﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    class Gato : Animal, IMascota
    {
        private string nombre;

        public Gato(string nombre)
            : base(4)
        {
            this.nombre = nombre;
        }

        public Gato()
            : this("")
        {
        }

        public void SetNombre(string nombre)
        {
            this.nombre = nombre;
        }

        public string GetNombre()
        {
            return nombre;
        }

        public void Jugar()
        {
            Console.WriteLine("A " + nombre + " le gusta jugar con ovillos de lana.");
        }

        public override void Come()
        {
            Console.WriteLine("Le gusta comer ratones y arañas.");
        }

        public override void Camina()
        {
            Console.WriteLine("Los gatos: ");
            base.Camina();
        }
    }
}
