﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace animales
{
    public class Pez : Animal, IMascota
    {
        private string nombre;

        public Pez()
            : base(0)
        {
        }

        public void SetNombre(string nombre)
        {
            this.nombre = nombre;
        }
        public String GetNombre()
        {
            return nombre;
        }
        public void Jugar()
        {
            Console.WriteLine("Los peces nadan y juegan con la comida.");
        }

        public override void Camina()
        {
            base.Camina();
            Console.WriteLine("Los peces NO CAMINAN, sólo nadan.");
        }

        public override void Come()
        {
            Console.WriteLine("Los peces comen algas.");
        }
    }
}
