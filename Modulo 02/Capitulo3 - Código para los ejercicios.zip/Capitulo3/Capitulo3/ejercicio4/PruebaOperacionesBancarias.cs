﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using operacionesBancarias;

namespace verificaciones
{
    class PruebaOperacionesBancarias
    {
        static void Main(string[] args)
        {
            Cuenta cuenta;
            Console.WriteLine("Creando al cliente Juan Perez.");
            Cliente cliente = new Cliente("Juan", "Perez");

            // crea una cuenta que tiene 500.00 de balance.
            Console.WriteLine("Creando una cuenta con 500.00 de balance.");
            cuenta = new Cuenta(500.00);

            cliente.Cuenta=cuenta;

            Console.WriteLine("Retira 150.00 : " + cuenta.Retira(150.00));
            // cuenta.retira(150.00);

            Console.WriteLine("Deposita 22.50 : " + cuenta.Deposita(22.50));
            cuenta.Deposita(22.50);

            Console.WriteLine("Retira 47.62 : " + cuenta.Retira(47.62));
            // cuenta.retira(47.62);

            // Imprime el balance final
            Console.WriteLine("La cuenta tiene un balance de " + cuenta.Balance);
            Console.WriteLine("Cliente [" + cliente.Apellido + ", " +
                cliente.PrimerNombre + "] tiene un balance de " + cuenta.Balance);
            Console.ReadKey();
        }
    }
}
