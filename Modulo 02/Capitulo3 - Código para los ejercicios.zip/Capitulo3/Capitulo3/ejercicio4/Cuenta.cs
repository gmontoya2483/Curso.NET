﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operacionesBancarias
{
    class Cuenta
    {
        private double balance;

        public Cuenta(double bal)
        {
            balance = bal;
        }

        public void Deposita(double cantidad)
        {
            balance = balance + cantidad;
        }
        public void Retira(double cantidad)
        {
            if (balance > cantidad)
            {
                balance = balance - cantidad;
            }
        }
        public double Balance
        {
            get
            {
                return balance;
            }
        }
    }
}
