﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using operacionesBancarias;

namespace verificaciones
{
    class PruebaOperacionesBancarias
    {
        static void Main(string[] args)
        {
            Banco banco = new Banco();
            Cliente cliente;

            banco.AgregaCliente("Juan", "Pérez");
            banco.AgregaCliente("Pedro", "García");
            banco.AgregaCliente("Oscar", "Toma");
            banco.AgregaCliente("María", "Soley");

            for (int i = 0; i < banco.NumeroDeClientes; i++)
            {
                cliente = banco.GetCliente(i);
                Console.WriteLine("Cliente [" + i + "] es " + cliente.PrimerNombre + " " + cliente.Apellido);
            }
            Console.ReadKey();
        }
    }
}
