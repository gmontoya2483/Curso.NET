﻿using System;
using System.IO;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"C:\MiArchivo.txt";



            Console.ReadKey();
        }
    }
}
