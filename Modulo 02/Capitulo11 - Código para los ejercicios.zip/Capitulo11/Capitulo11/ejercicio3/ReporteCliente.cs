﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using operacionesBancarias.dominio;
using System.IO;

namespace operacionesBancarias.reportes
{
    class ReporteCliente
    {
        public static void GenerarReporte()
        {
            Banco banco = Banco.getBanco();
            Cliente cliente;
            string path = @"C:\Reporte.txt";


        }
    }
}
