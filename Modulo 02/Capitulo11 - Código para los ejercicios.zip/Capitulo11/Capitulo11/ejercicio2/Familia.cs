﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    /***
    * Paso 1: declarar que la clase Familia es serializable.
    ***/

    public class Familia
    {
        // Asociaciones
        private Persona _madre = null;
        private Persona _padre = null;
        private List<Persona> _hijos = new List<Persona>();

        public Familia()
        {
        }

        public void AddHijo(Persona p)
        {
            _hijos.Add(p);
        }

        public Persona Madre
        {
            get
            {
                return _madre;
            }
            set
            {
                _madre = value;
            }
        }
        public Persona Padre
        {
            get
            {
                return _padre;
            }
            set
            {
                _padre = value;
            }
        }
        public List<Persona> Hijos
        {
            get
            {
                return _hijos;
            }
            set
            {
                _hijos = value;
            }
        }

        public Persona EncontrarHijo(String primerNombre)
        {
            Persona resultado = null;

            foreach (Persona _hijo in _hijos)
            {
                if (_hijo.PrimerNombre.Equals(primerNombre))
                {
                    resultado = _hijo;
                }
            }
            return resultado;
        }
    }
}
