﻿using System;

namespace ejercicio2
{
    /***
    * Paso 2: declarar que la clase Persona es serializable.
    ***/
 
    public class Persona
    {
        private String _primerNombre;
        private String _apellido;

        /**
         * Paso 3: declarar que el atributo numeroDeHermanos no se va a serializar.
         */
 
        private int _numeroDeHermanos;

        private Familia _familia = null;

        public Persona(Familia fam, String pn, String ap)
        {
            _primerNombre = pn;
            _apellido = ap;
            _familia = fam;
            if (_familia != null)
            {
                _familia.AddHijo(this);
            }
            _numeroDeHermanos = 0;
        }

         public int NumeroDeHermanos
        {
            get
            {
                /***
                * Paso 4: Calcular el atributo numeroDeHermanos Esto deberá hacerse (el
                * cálculo) una sola vez por ejecución.
                ***/
 
                return _numeroDeHermanos;
            }
        }
        public String PrimerNombre
        {
            get
            {
                return _primerNombre;
            }
            set
            {
                _primerNombre = value;
            }
        }

        public String Apellido
        {
            get
            {
                return _apellido;
            }
            set
            {
                _apellido = value;
            }
        }
    }
}
