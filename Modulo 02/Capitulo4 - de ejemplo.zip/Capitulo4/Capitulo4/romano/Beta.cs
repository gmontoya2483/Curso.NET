﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using griego;

namespace romano
{
    class Beta
    {
        public void metodoAccesor()
        {
            Alfa a = new Alfa();
            a.soyPublico = 10; // legal
            a.metodoPublico(); // legal
        }
    }
}
