﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace romano
{
    class Program
    {
        static void Main(string[] args)
        {
            Gamma g = new Gamma();

            g.metodoPublico();
            Console.ReadKey();
        }
    }
}
