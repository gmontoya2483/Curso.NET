﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace romano
{
    class Gamma
    {
        public void metodoPublico()
        {
            // Error: Beta no es visible para el 
            // espacio de nombres griego por estar 
            // en otro ensamblado y ser internal
            // por más que tenga una referencia al
            // ensamblado
            // griego.Beta b = new griego.Beta();

            griego.Alfa a = new griego.Alfa();

            //a.metodoProtegido(); // ilegal
            //a.metodoInterno(); // ilegal
        }
    }
}
