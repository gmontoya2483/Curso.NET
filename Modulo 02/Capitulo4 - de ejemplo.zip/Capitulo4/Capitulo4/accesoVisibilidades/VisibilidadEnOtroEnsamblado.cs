﻿using visibilidades;

namespace visibilidades
{
    class VisibilidadEnOtroEnsambladoMismoEspacioDeNombres : VisibilidadDeMienbros
    {
        public void AccedientoMetodosMismoEspacioDeNombres()
        {
            VisibilidadDeMienbros vm = new VisibilidadDeMienbros();
            vm.var1 = 1; // Por notación de punto, sólo se accede a public
            var4 = 4;
            var6 = 9;
            vm.Met1();
            Met4();
            Met6();
        }
    }
}
