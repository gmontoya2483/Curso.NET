﻿using System;
using visibilidades;
using accesoVisibilidades;

namespace visibilidades
{
    class Program
    {
        static void Main(string[] args)
        {
            VisibilidadDeMienbros vm = new VisibilidadDeMienbros();
            vm.var1 = 111;
            vm.Met1();

            VisibilidadEnOtroEnsambladoMismoEspacioDeNombres voeme = new VisibilidadEnOtroEnsambladoMismoEspacioDeNombres();
            voeme.AccedientoMetodosMismoEspacioDeNombres();
            voeme.var1 = 1111;
            voeme.Met1();

            VisibilidadEnOtroEnsambladoOtroEspacioDeNombres voeoe = new VisibilidadEnOtroEnsambladoOtroEspacioDeNombres();
            voeoe.AccedientoMetodosOtroEspacioDeNombres();
            voeoe.var1 = 2222;
            voeoe.Met1();

            Console.ReadKey();
        }
    }
}
