﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using visibilidades;

namespace accesoVisibilidades
{
    class VisibilidadEnOtroEnsambladoOtroEspacioDeNombres : VisibilidadDeMienbros
    {
        public void AccedientoMetodosOtroEspacioDeNombres()
        {
            VisibilidadDeMienbros vm = new VisibilidadDeMienbros();
            vm.var1 = 1; // Por notación de punto, sólo se accede a public
            var4 = 4;
            var6 = 9;
            vm.Met1();
            Met4();
            Met6();
        }
    }
}
