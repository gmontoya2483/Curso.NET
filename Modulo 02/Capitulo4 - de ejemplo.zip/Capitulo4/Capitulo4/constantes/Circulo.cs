﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constantes
{
    class Circulo
    {
        private const double PI = 3.1416;

        public double CalculaArea(double radio)
        {
            return radio * PI * PI;
        }

        public double CalculasPerimetro(double radio)
        {
            return 2 * radio * PI;
        }
    }
}
