﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constantes
{
    class Program
    {
        static void Main(string[] args)
        {
            Circulo c = new Circulo();
            Console.WriteLine("El perímetro del circulo de radio 2,5 es: " + c.CalculasPerimetro(2.5));
            Console.WriteLine("Y su área es: " + c.CalculaArea(2.5));
            Console.ReadKey();
        }
    }
}
