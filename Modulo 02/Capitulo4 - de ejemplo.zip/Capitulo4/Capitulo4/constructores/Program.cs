﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constructores
{
    class Program
    {
        static void Main(string[] args)
        {
            Ejemplo e = new Ejemplo(8);
            constructores.defecto.Ejemplo e2 = new constructores.defecto.Ejemplo(9);
            constructores.sobrecargados.Ejemplo e3 = new constructores.sobrecargados.Ejemplo(10);
            constructores.sobrecargados.Ejemplo e4 = new constructores.sobrecargados.Ejemplo('a');
        }
    }
}
