﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constructores
{
    class Ejemplo
    {
        private int atrib1;
        private char atrib2;
        public Ejemplo(int a) { atrib1 = a; }
        public void metodo()
        {
            //[sentencias;]
        }
    }
}
