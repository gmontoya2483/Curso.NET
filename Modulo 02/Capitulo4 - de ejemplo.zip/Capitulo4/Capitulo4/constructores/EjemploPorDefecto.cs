﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constructores.defecto
{
    class Ejemplo
    {
        private int atrib1;
        private char atrib2;
        public Ejemplo(int a) { atrib1 = a; }
        public Ejemplo() { atrib1 = 5; }
        public void metodo()
        {
            //[sentencias;]
        }
    }
}
