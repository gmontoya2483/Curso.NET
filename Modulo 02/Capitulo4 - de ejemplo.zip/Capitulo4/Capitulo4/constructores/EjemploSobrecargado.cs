﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constructores.sobrecargados
{
    class Ejemplo
    {
        private int atrib1;
        private char atrib2;
        public Ejemplo(int a) { atrib1 = a; }
        public Ejemplo(char a) { atrib2 = a; }
        public void metodo()
        {
            //[sentencias;]
        }
    }
}
