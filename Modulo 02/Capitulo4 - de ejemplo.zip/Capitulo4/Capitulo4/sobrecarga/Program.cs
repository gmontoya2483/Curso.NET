﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sobrecarga
{
    class Program
    {
        static void Main(string[] args)
        {
            DibujodeDatos d = new DibujodeDatos();
            d.Dibujar(8);
            d.Dibujar("Cuadrado");
            d.Dibujar(3.14F);
            Console.ReadKey();
        }
    }
}
