﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sobrecarga
{
    class DibujodeDatos
    {
        public void Dibujar(String s)
        {
            Console.WriteLine("Dibujando con un string: " + s);
        }
        public void Dibujar(int i)
        {
            Console.WriteLine("Dibujando con un int: " + i);
        }
        public void Dibujar(float f)
        {
            Console.WriteLine("Dibujando con un float: " + f);
        }
    }
}
