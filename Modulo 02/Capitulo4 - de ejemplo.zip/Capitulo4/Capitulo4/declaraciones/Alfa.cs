﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace declaraciones
{
    class Alfa
    {
        private int soyPrivado;
        private void metodoPrivado()
        {
            Console.WriteLine("metodoPrivado");
        }
    }
}
