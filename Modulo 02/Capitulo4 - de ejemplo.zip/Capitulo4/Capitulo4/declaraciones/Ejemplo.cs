﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace declaraciones
{
    class Ejemplo
    {
        private int atrib1;
        private char atrib2;
        public void metodo() { }
    }
}
