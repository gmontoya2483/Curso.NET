﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace declaraciones
{
    class Beta
    {
        void metodoAccesor()
        {
            Alfa a = new Alfa();
            //		a.soyPrivado = 10; // ilegal
            //		a.metodoPrivado(); // ilegal
        }
    }
}
