﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herenciaConstructores
{
    class Empleado
    {
        private String nombre;
        private double salario = 1500.00;
        private Fecha fechaNacimiento;
        public Empleado(String n, Fecha fDN)
        {
            // Llamado implícito a base;
            nombre = n;
            fechaNacimiento = fDN;
        }
        public Empleado(String n)
            : this(n, null)
        {
            
        }
    }
}
