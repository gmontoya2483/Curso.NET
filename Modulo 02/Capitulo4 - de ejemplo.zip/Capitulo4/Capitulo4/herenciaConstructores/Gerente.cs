﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herenciaConstructores
{
    class Gerente : Empleado
    {
        private String departamento;
        public Gerente(String n, String d): base(n)
        {
            departamento = d;
        }
    }
}
