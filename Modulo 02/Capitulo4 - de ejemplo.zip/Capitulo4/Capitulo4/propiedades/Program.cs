﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propiedades
{
    class Program
    {
        static void Main(string[] args)
        {
            Punto p = new Punto(3.3, 4.4);
            p.X = 5.5;
            p.Y = 6.6;
            Console.WriteLine("El valor X del punto es: " + p.X);
            Console.WriteLine("El valor Y del punto es: " + p.Y);
            Console.ReadKey();
        }
    }
}
