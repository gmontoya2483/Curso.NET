﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace destructores
{
    class Clase3
    {
        public Clase3()
        {
            Console.WriteLine("Construyendo la clase 3");
        }
        ~Clase3()
        {
            Console.WriteLine("Destruyendo la clase 3");
            Console.ReadKey();
        }
    }
}
