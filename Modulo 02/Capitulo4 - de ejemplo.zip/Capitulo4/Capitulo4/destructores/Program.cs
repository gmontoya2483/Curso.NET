﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace destructores
{
    class Program
    {
        static void Main(string[] args)
        {
            Clase1 c1 = new Clase1();
            c1 = null;

            Clase2 c2 = new Clase2();
            c2 = null;

            Clase3 c3 = new Clase3();
            c3 = null;

            Console.WriteLine("Notar que al destructor lo llama el garbage collector");

            Console.WriteLine("");
            Console.WriteLine("Presione un tecla para salir.");
            Console.ReadKey();
        }
    }
}
