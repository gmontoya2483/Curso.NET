﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace destructores
{
    class Clase2
    {        
        public Clase2()
        {
            Console.WriteLine("Construyendo la clase 2");
        }
        ~Clase2()
        {
            Console.WriteLine("Destruyendo la clase 2");
        }
    }
}
