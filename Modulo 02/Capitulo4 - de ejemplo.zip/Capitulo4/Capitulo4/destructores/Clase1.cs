﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace destructores
{
    class Clase1
    {
        public Clase1()
        {
            Console.WriteLine("Construyendo la clase 1");
        }
        ~Clase1()
        {
            Console.WriteLine("Destruyendo la clase 1");
        }
    }
}
