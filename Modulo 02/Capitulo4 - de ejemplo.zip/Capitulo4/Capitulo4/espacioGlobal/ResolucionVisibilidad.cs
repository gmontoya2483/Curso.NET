﻿namespace espacioGlobal
{
    class ResolucionVisibilidad
    {
        // Definir una clase nueva llamada 'System' para causar problemas.
        // y ocultar el espacio de nombres System
        public class System { }

        // Definir una constante llamada 'Console' para causar más problemas.
        // y ocultar la clase Console
        const int Console = 7;
        const int numero = 66;

        static void Main()
        {
            // Error: Accede a ResolucionVisibilidad.Console
            // Console.WriteLine(number);
            // Error: Accede a ResolucionVisibilidad.System
            // System.Console.WriteLine(number);
            // Esto está bien!!!
            global::System.Console.WriteLine(numero);
            global::System.Console.ReadKey();
        }
    }
}

