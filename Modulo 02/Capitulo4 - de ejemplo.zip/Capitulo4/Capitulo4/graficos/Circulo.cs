﻿namespace graficos
{
    class Circulo
    {
    }
}
