﻿namespace graficos
{
    class Rectangulo
    {
    }
}
