﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class OtraClase : MiClase
    {
        new internal bool unaVariable;

        internal override void UnMetodo()
        {
            unaVariable = false;
            base.UnMetodo();
            Console.WriteLine(unaVariable);
            Console.WriteLine(base.unaVariable);
        }
    }
}
