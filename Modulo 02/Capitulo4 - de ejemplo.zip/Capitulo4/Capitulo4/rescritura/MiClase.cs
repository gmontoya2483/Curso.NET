﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class MiClase
    {
        internal bool unaVariable;

        internal virtual void UnMetodo()
        {
            unaVariable = true;
        }
    }
}
