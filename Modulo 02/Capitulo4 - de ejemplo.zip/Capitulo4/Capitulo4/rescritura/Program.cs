﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class Program
    {
        static void Main(string[] args)
        {
            OtraClase o = new OtraClase();
            o.UnMetodo();

            Empleado e = new Empleado();
            Console.WriteLine(e.getDetalles());

            Gerente g = new Gerente();
            Console.WriteLine(g.getDetalles());

            Console.ReadKey();
        }
    }
}
