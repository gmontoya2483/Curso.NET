﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class Empleado
    {
        private String nombre;
        private double salario = 1500.00;
        private Fecha fechaNacimiento;

        public virtual String getDetalles()
        {
            return "Nombre: " + nombre + "\nSalario: " + salario;
        }
        public String Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }
        public double Salario
        {
            get
            {
                return salario;
            }
            set
            {
                salario = value;
            }
        }
        public Fecha FechaNacimiento
        {
            get
            {
                return fechaNacimiento;
            }
            set
            {
                fechaNacimiento = value;
            }
        }
    }
}
