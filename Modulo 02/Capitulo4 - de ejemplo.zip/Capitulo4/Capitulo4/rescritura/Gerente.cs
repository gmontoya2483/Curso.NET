﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class Gerente : Empleado
    {
        private String departamento = "legales";

        public override String getDetalles()
        {
            return base.getDetalles() + "\nDepartamento: " + departamento;
        }
        public String Departamento
        {
            get
            {
                return departamento;
            }
            set
            {
                departamento = value;
            }
        }
    }
}
