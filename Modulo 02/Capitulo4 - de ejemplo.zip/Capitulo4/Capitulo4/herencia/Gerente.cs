﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia
{
    class Gerente : Empleado
    {
        private String departamento;

        public String getDetalles()
        {
            return "detalles";
        }

        public String Departamento
        {
            get { return departamento; }
            set { departamento = value; }
        }
    }
}
