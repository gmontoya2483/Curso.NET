﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia
{
    class Program
    {
        static void Main(string[] args)
        {
            Sub s = new Sub();
            Console.WriteLine("El valor retornado es: " + s.RetornaValor());
            Console.ReadKey();
        }
    }
}
