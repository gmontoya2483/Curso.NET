﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia
{
    class Secretaria : Empleado
    {
        private String idioma;

        public String Idioma
        {
            get { return idioma; }
            set { idioma = value; }
        }
    }
}
