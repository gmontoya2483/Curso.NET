﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia
{
    class Sub: Super
    {
        new internal float unNumero = 3.3F;

        public Sub()
        {
            int ej = base.unNumero;
        }

        public float RetornaValor()
        {
            return unNumero + base.unNumero;
        }
    }
}
