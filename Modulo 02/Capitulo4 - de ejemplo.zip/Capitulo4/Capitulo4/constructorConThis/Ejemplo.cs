﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constructorConThis
{
    class Ejemplo
    {
        public Ejemplo(int a) { atrib1 = a; }
        public Ejemplo(int a, float b):this(a)
        {
            atrib2 = b;
        }
        private int atrib1;
        private float atrib2;
        public void metodo()
        {
            //[sentencias;]
        }
    }
}
