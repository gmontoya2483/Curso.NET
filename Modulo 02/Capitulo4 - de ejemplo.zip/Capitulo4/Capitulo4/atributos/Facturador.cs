﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atributos
{
    class Facturador
    {
        private readonly double impuesto;
        private double monto;

        public Facturador(double impuesto)
        {
            this.impuesto = impuesto;
        }

        public double Total(double monto)
        {
            this.monto = monto;
            return monto * impuesto;
        }
    }
}
