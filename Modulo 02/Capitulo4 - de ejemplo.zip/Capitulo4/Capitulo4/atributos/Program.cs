﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace atributos
{
    class Program
    {
        static void Main(string[] args)
        {
            Facturador f = new Facturador(0.21);
            Console.WriteLine("El total a facturar es: " + f.Total(225.15));
            Console.ReadKey();
        }
    }
}
