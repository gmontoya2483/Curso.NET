﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ambiguedad
{
    class Program
    {
        static void Main(string[] args)
        {
            Ejemplo e1 = new Ejemplo(8);
            Ejemplo e2 = new Ejemplo('a');
            Ejemplo e3 = new Ejemplo('a', 8);
        }
    }
}
