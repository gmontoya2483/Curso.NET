﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ambiguedad
{
    class Ejemplo
    {
        private int atrib1;
        private char atrib2;
        public Ejemplo(int a) { atrib1 = a; }
        public Ejemplo(char a) { atrib2 = a; }
        public Ejemplo(char atrib2, int atrib1)
        {
            this.atrib1 = atrib1;
            this.atrib2 = atrib2;
        }
        public void metodo()
        {
            //[sentencias;]
            atrib2 = 'a';
        }
    }
}
