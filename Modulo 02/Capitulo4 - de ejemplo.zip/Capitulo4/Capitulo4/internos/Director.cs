﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace internos
{
    class Director : Empleado
    {
        private String cargoEnJunta;

        public Director(String c)
        {
            cargoEnJunta = c;
        }

        public String CargoEnJunta
        {
            get { return cargoEnJunta; }
            set { cargoEnJunta = value; }
        }

        protected internal void MostrarCartel()
        {
            Console.WriteLine("Estoy en Director");
        }
    }
}
