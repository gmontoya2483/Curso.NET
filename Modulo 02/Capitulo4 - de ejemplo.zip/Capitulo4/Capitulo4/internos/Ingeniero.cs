﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace internos
{
    class Ingeniero : Empleado
    {
        private String especialidad;

        public String Especialidad
        {
            get { return especialidad; }
            set { especialidad = value; }
        }

        protected internal void MostrarCartel()
        {
            Console.WriteLine("Estoy en Ingeniero");
        }
    }
}
