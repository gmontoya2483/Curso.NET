﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace internos
{
    class Program
    {
        static void Main(string[] args)
        {
            Gerente g = new Gerente();
            g.MostrarCartel();

            Console.ReadKey();
        }
    }
}
