﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace internos
{
    class Empleado
    {
        protected internal String nombre;
        protected internal double salario = 1500.00;
        protected internal Fecha fechaNacimiento;

        public String getDetalles()
        {
            return "Nombre: " + nombre + "\nSalario: " + salario;
        }

        protected internal void MostrarCartel()
        {
            Console.WriteLine("Estoy en Empleado");
        }
    }
}
