﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace internos
{
    class Secretaria : Empleado
    {
        private String idioma;

        public String Idioma
        {
            get { return idioma; }
            set { idioma = value; }
        }

        protected internal void MostrarCartel()
        {
            Console.WriteLine("Estoy en Secretaria");
        }
    }
}
