﻿namespace N1.N2
{
    public class C3   // N1.N2.C3
    {
    }
}
