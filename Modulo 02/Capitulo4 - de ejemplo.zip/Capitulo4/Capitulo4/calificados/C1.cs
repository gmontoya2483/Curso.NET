﻿namespace N1     // N1
{
    public class C1      // N1.C1
    {
        public class C2   // N1.C1.C2
        {
        }
    }
    namespace N2  // N1.N2
    {
        public class C2   // N1.N2.C2
        {
        }
    }
}
