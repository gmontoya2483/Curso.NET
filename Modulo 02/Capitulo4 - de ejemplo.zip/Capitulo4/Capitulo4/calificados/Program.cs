﻿namespace calificados
{
    class Program
    {
        static void Main(string[] args)
        {
            N1.C1 c1 = new N1.C1();
            N1.C1.C2 c2= new N1.C1.C2();
            N1.N2.C3 c3 = new N1.N2.C3();
        }
    }
}
