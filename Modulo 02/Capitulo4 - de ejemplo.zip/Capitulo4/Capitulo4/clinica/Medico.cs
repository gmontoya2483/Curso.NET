﻿using System;
using System.Collections.Generic;
using clinica.utilidades;

namespace clinica
{
    namespace medicos
    {
        class Medico
        {
            private String nombre;
            private String apellido;
            private String especialidad;
            private int turnosPorHora = 0;
            private HashSet<Horario> horarios = new HashSet<Horario>();

            public String Nombre
            {
                get
                {
                    return nombre;
                }
                set
                {
                    nombre = value;
                }
            }
            public String Apellido
            {
                get
                {
                    return apellido;
                }
                set
                {
                    apellido = value;
                }
            }
            public String Especialidad
            {
                get
                {
                    return especialidad;
                }
                set
                {
                    especialidad = value;
                }
            }
            public int TurnosPorHora
            {
                get
                {
                    return turnosPorHora;
                }
                set
                {
                    turnosPorHora = value;
                }
            }
            public HashSet<Horario> Horarios
            {
                get
                {
                    return horarios;
                }
                set
                {
                    horarios = value;
                }
            }

        }
    }
}
