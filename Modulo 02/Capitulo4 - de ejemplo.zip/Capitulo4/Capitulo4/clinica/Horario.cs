﻿using System;

namespace clinica.utilidades
{
    class Horario
    {
        private int dia = 0;
        private int horaComienzo = 0;
        private int minutosComienzo = 0;
        private int horaFin = 0;
        private int minutosFin = 0;
        private int turnosPorHora = 0;


        public Horario(int dia, int horaComienzo, int minutosComienzo, int horaFin,
                int minutosFin, int turnosPorHora)
        {
            this.dia = dia;
            this.horaComienzo = horaComienzo;
            this.minutosComienzo = minutosComienzo;
            this.horaFin = horaFin;
            this.minutosFin = minutosFin;
            this.turnosPorHora = turnosPorHora;
        }

        public Horario(Horario f)
        {
            this.dia = f.dia;
            this.horaComienzo = f.horaComienzo;
            this.minutosComienzo = f.minutosComienzo;
            this.horaFin = f.horaFin;
            this.minutosFin = f.minutosFin;
        }

        public Horario agregar(int masDias)
        {
            Horario nuevaFecha = new Horario(this);
            nuevaFecha.dia += masDias;
            return nuevaFecha;
        }

        public void imprimir()
        {
            Console.WriteLine("Horario: ");
            Console.WriteLine("Día: " + dia);
            Console.WriteLine("Hora de comienzo: " + horaComienzo);
            Console.WriteLine("Minutos de comienzo: " + minutosComienzo);
            Console.WriteLine("Hora de fin: " + horaFin);
            Console.WriteLine("Minutos de fin: " + minutosFin);
            Console.WriteLine("Turnos por hora:" + turnosPorHora);
        }
        public int Dia
        {
            get
            {
                return dia;
            }
        }
        public int HoraComienzo
        {
            get
            {
                return horaComienzo;
            }
        }
        public int MinutosComienzo
        {
            get
            {
                return minutosComienzo;
            }
        }
        public int HoraFin
        {
            get
            {
                return horaFin;
            }
        }
        public int MinutosFin
        {
            get
            {
                return minutosFin;
            }
        }
        public int TurnosPorHora
        {
            get
            {
                return turnosPorHora;
            }
        }
    }
}
