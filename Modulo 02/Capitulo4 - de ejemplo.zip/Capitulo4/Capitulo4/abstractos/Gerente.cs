﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractos
{
    class Gerente : Empleado
    {
        private String departamento="Ventas";

        public override String getDetalles()
        {
            return "Nombre: " + nombre + "\nSalario: " + salario 
                + "\nDep: " + departamento;
        }
    }
}