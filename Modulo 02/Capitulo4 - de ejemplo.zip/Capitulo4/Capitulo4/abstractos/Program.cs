﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractos
{
    class Program
    {
        static void Main(string[] args)
        {
            Gerente g = new Gerente();
            Console.WriteLine(g.getDetalles());
            Console.ReadKey();
        }
    }
}
