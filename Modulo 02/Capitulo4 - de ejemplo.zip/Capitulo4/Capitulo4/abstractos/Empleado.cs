﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstractos
{
    public abstract class Empleado
    {
        protected String nombre="Alberto";
        protected double salario = 1500.00;
        protected Fecha fechaNacimiento;

        public abstract String getDetalles();
    }
}
