﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class DeterminarInstancia
    {
        public void ConIs()
        {
            Empleado empleado = new Empleado("Alejandro", "Ignacio", "Fursi", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F);
            Gerente gerente = new Gerente("Juan", "Pedro", "Goyena", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F, 20);
            Director director = new Director("Daniel", "Federico", "Ruiz", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F, 20, "vocal");
            Secretaria secretaria = new Secretaria("María", "Juana", "Roldán", "20.202.020", "Ventas", "20", "10", 800.0F, "inglés");
            Ingeniero ingeniero = new Ingeniero("Marío", "Alberto", "Rojas", "20.333.025", "Producción", "20", "10", 2800.0F, "desarrollo");

            if (empleado is Empleado)
                Console.WriteLine("Empleado es del tipo Empleado");
            if (empleado is Persona)
                Console.WriteLine("Empleado es del tipo Persona");
            if (secretaria is Empleado)
                Console.WriteLine("Secretaria es del tipo Empleado");
            if (gerente is Empleado)
                Console.WriteLine("Gerente es del tipo Empleado");
            if (director is Empleado)
                Console.WriteLine("Director es del tipo Empleado");
            if (director is Empleado)
                Console.WriteLine("Director es del tipo Empleado");
            if (director is Persona)
                Console.WriteLine("Director es del tipo Persona");

            if (ingeniero is Gerente)
                Console.WriteLine("Ingeniero es una instancia de Gerente");
            else
                Console.WriteLine("Ingeniero NO es una instancia de Gerente");
        }

        public void ConTypeof()
        {
            Empleado empleado = new Empleado("Alejandro", "Ignacio", "Fursi", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F);
            Gerente gerente = new Gerente("Juan", "Pedro", "Goyena", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F, 20);
            Director director = new Director("Daniel", "Federico", "Ruiz", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F, 20, "vocal");
            Secretaria secretaria = new Secretaria("María", "Juana", "Roldán", "20.202.020", "Ventas", "20", "10", 800.0F, "inglés");
            Ingeniero ingeniero = new Ingeniero("Marío", "Alberto", "Rojas", "20.333.025", "Producción", "20", "10", 2800.0F, "desarrollo");

            if (empleado.GetType() == typeof(Empleado))
                Console.WriteLine("Empleado es una instancia de Empleado");
            if (empleado.GetType() == typeof(Persona))
                Console.WriteLine("Empleado es una instancia de Persona");
            if (secretaria.GetType() == typeof(Empleado))
                Console.WriteLine("Secretaria es una instancia de Empleado");
            else if (secretaria.GetType() == typeof(Secretaria))
                Console.WriteLine("secretaria es una instancia de Secretaria");
            if (gerente.GetType() == typeof(Empleado))
                Console.WriteLine("Gerente es una instancia de Empleado");
            else if (gerente.GetType() == typeof(Gerente))
                Console.WriteLine("gerente es una instancia de Gerente");
            if (director.GetType() == typeof(Empleado))
                Console.WriteLine("Director es una instancia de Empleado");
            else if (director.GetType() == typeof(Director))
                Console.WriteLine("director es una instancia de Director");
            if (director.GetType() == typeof(Empleado))
                Console.WriteLine("Director es una instancia de Empleado");
            if (director.GetType() == typeof(Persona))
                Console.WriteLine("Director es una instancia de Persona");

            if (ingeniero.GetType() == typeof(Gerente))
                Console.WriteLine("ingeniero es una instancia de Gerente");
            else
                Console.WriteLine("ingeniero NO es una instancia de Gerente");
        }

        public void ConAs()
        {
            Persona p;
            Empleado empleado = new Empleado("Alejandro", "Ignacio", "Fursi", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F);
            Gerente gerente = new Gerente("Juan", "Pedro", "Goyena", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F, 20);
            Director director = new Director("Daniel", "Federico", "Ruiz", "17.767.076",
                    "Ventas", "0", "GV50", 5500.0F, 20, "vocal");
            Secretaria secretaria = new Secretaria("María", "Juana", "Roldán", "20.202.020", "Ventas", "20", "10", 800.0F, "inglés");
            Ingeniero ingeniero = new Ingeniero("Marío", "Alberto", "Rojas", "20.333.025", "Producción", "20", "10", 2800.0F, "desarrollo");

            p = empleado as Persona;
            Console.WriteLine(p.Apellido + ", " + p.PrimerNombre+ " " + p.SegundoNombre);

            p = gerente as Persona;
            Console.WriteLine(p.Apellido + ", " + p.PrimerNombre + " " + p.SegundoNombre);

            p = director as Persona;
            Console.WriteLine(p.Apellido + ", " + p.PrimerNombre + " " + p.SegundoNombre);

            p = secretaria as Persona;
            Console.WriteLine(p.Apellido + ", " + p.PrimerNombre + " " + p.SegundoNombre);

            p = ingeniero as Persona;
            Console.WriteLine(p.Apellido + ", " + p.PrimerNombre + " " + p.SegundoNombre);
        }
    }
}
