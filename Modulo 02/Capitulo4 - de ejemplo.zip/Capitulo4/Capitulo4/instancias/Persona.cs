﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class Persona
    {
        private String primerNombre;
        private String segundoNombre;
        private String apellido;
        private String documento;

        public Persona(String p, String s, 
            String a, String d)
        {
            primerNombre = p;
            segundoNombre = s;
            apellido = a;
            documento = d;
        }
        public String PrimerNombre
        {
            get
            {
                return primerNombre;
            }
            set
            {
                primerNombre = value;
            }
        }
        public String SegundoNombre
        {
            get
            {
                return segundoNombre;
            }
            set
            {
                segundoNombre = value;
            }
        }
        public String Apellido
        {
            get
            {
                return apellido;
            }
            set
            {
                apellido = value;
            }
        }
        public String Documento
        {
            get
            {
                return documento;
            }
            set
            {
                documento = value;
            }
        }

    }
}
