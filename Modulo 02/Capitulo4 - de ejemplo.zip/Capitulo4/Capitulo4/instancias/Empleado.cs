﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class Empleado : Persona
    {
        private String departamento;
        private String id;
        private String idJefe;
        private float sueldo;

        public Empleado(String p, String s, String a, String doc,
         String dep, String i, String ij, float sdo)
            : base(p, s, a, doc)
        {
            departamento = dep;
            id = i;
            idJefe = ij;
            sueldo = sdo;
        }
        public String Departamento
        {
            get
            {
                return departamento;
            }
            set
            {
                departamento = value;
            }
        }
        public String Id
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }
        public String IdJefe
        {
            get
            {
                return idJefe;
            }
            set
            {
                idJefe = value;
            }
        }
        public float Sueldo
        {
            get
            {
                return sueldo;
            }
            set
            {
                sueldo = value;
            }
        }
    }
}
