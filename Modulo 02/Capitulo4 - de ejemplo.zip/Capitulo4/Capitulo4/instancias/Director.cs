﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class Director : Gerente
    {
        private String cargoEnJunta;

        public Director(String p,
            String s, String a, String doc,
            String dep, String i, String ij,
            float sdo, int ne, String c)
            : base(p, s, a, doc, dep, i, ij, sdo, ne)
        {
            cargoEnJunta = c;
        }
        public String CargoEnJunta
        {
            get
            {
                return cargoEnJunta;
            }
            set
            {
                cargoEnJunta = value;
            }
        }
    }
}
