﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class Ingeniero : Empleado
    {
        private String especialidad;

        public Ingeniero(
        String p, String s, String a,
        String doc, String dep,
        String i, String ij,float sdo, String e)
            : base(p, s, a, doc, dep, i, ij, sdo)
        {
            especialidad = e;
        }

        public String Especialidad
        {
            get { return especialidad; }
            set { especialidad = value; }
        }
    }
}
