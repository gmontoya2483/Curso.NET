﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class Gerente : Empleado
    {
        private int nroEmpleados = 10;

        public Gerente(
        String p, String s, String a,
        String doc, String dep, String i,
        String ij, float sdo, int ne)
            : base(p, s, a, doc, dep, i, ij, sdo)
        {
            nroEmpleados = ne;
        }
        public int NroEmpleados
        {
            get
            {
                return nroEmpleados;
            }
            set
            {
                nroEmpleados = value;
            }
        }
    }
}
