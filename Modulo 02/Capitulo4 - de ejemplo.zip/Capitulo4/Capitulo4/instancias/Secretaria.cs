﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class Secretaria : Empleado
    {
        private String idioma;

        public Secretaria(
        String p, String s, String a,
        String doc, String dep,
        String i, String ij,float sdo, String id)
            : base(p, s, a, doc, dep, i, ij, sdo)
        {
            idioma = id;
        }
        public String Idioma
        {
            get
            {
                return idioma;
            }
            set
            {
                idioma = value;
            }
        }
    }
}
