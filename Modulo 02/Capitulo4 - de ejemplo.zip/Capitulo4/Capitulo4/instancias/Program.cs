﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class Program
    {
        static void Main(string[] args)
        {
            DeterminarInstancia d = new DeterminarInstancia();

            Console.WriteLine("Usando el operador is");
            d.ConIs();
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Usando el operador typeof");
            d.ConTypeof();
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Usando el operador as");
            d.ConAs();
            Console.ReadKey();
        }
    }
}
