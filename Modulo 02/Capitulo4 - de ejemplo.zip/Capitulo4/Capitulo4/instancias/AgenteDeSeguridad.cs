﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace instancias
{
    class AgenteDeSeguridad:Persona
    {
        private String nroLicencia;

        public AgenteDeSeguridad(String p, String s, String a, String d)
            : base(p, s, a, d)
        {
        }
        public String NroLicencia
        {
            get
            {
                return nroLicencia;
            }
            set
            {
                nroLicencia = value;
            }
        }
    }
}
