﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herenciaConstructoresThis
{
    class Gerente : Empleado
    {
        private String departamento;

        public Gerente(String nombre, double salario, String dep)
            : base(nombre, salario)
        {
            departamento = dep;
        }
        public Gerente(String n, String d)
            : base(n)
        {
            departamento = d;
        }
        //	public Gerente(String dep) { // Error, no existe Empleado()
        //		departamento = dep;
        //	}
    }
}
