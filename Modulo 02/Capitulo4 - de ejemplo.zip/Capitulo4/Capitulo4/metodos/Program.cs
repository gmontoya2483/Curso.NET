﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodos
{
    class Program
    {
        static void Main(string[] args)
        {
            Parametros p = new Parametros();

            p.ProbandoPasajePorValor();
            p.ProbandoOut();
            p.ProbandoRef();
            p.ProbandoParams();
            Console.ReadKey();
        }
    }
}
