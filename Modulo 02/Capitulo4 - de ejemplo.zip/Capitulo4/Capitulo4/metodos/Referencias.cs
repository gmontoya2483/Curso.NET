﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodos
{
    class Parametros
    {
        private void PruebaRef(ref int uno, int dos)
        {
            // Esta asignación afectará al parámetro
            uno += dos;
            // Esta no afectará al valor usado como segundo argumento
            dos = 999;
        }

        public void ProbandoRef()
        {
            int uno = 5;
            int dos = 2;
            Console.WriteLine("Prueba de ref");
            Console.WriteLine("uno= {0}, dos = {1}", uno, dos);
            PruebaRef(ref uno, dos);
            Console.WriteLine("uno= {0}, dos = {1}", uno, dos);
        }

        private void PruebaOut(out int uno)
        {
            uno = 1;
        }

        public void ProbandoOut()
        {
            int valor = 0;
            Console.WriteLine("Prueba de out");
            Console.WriteLine("La variable valor antes de la llamada " + 
                "no está inicializada y no se puede usar.");
            PruebaOut(out valor);
            Console.WriteLine("Variable valor después de la llamada: " + valor);
        }

        public void PruebaPasajePorValor(int uno)
        {
            uno = 15;
        }

        public void ProbandoPasajePorValor()
        {
            int valor = 15;
            Console.WriteLine("Prueba de pasaje por valor");
            Console.WriteLine("Variable valor antes de la llamada: " + valor);
            PruebaPasajePorValor(valor);
            Console.WriteLine("Variable valor después de la llamada: " + valor);
        }

        public void PruebaParamsConTipoPorValor(params int[] lista)
        {
            for (int i = 0; i < lista.Length; i++)
                Console.WriteLine(lista[i]);
            Console.WriteLine();
        }

        public void PruebaParamsConObjetos(params object[] lista)
        {
            for (int i = 0; i < lista.Length; i++)
                Console.WriteLine(lista[i]);
            Console.WriteLine();
        }

        public void ProbandoParams()
        {
            Console.WriteLine("Prueba de params");
            PruebaParamsConTipoPorValor(1, 2, 3);
            PruebaParamsConObjetos(1, 'a', "test");

            int[] vec = new int[3] { 10, 11, 12 };
            PruebaParamsConTipoPorValor(vec);
       }
    }
}
