﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace indexadores
{
    class DiasSinIndice
    {
        private string[] dias = { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"};
        public int ObtenerNumeroDeDias()
        {
            return 7;
        }
        public string ObtenerDia(int indiceDia)
        {
            if (indiceDia > ObtenerNumeroDeDias()) return "No existe";
            else return dias[indiceDia];
        }
    }
}
