﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace indexadores
{
    class Program
    {
        static void Main(string[] args)
        {
            int cantidadDeDias;
            int indiceDeDia;
            DiasSinIndice diasDeLaSemanaSinIndexador = new DiasSinIndice();
            cantidadDeDias = diasDeLaSemanaSinIndexador.ObtenerNumeroDeDias();
            for (indiceDeDia = 0; indiceDeDia < cantidadDeDias; indiceDeDia++)
            {
                System.Console.WriteLine(diasDeLaSemanaSinIndexador.ObtenerDia(indiceDeDia));
            }

            System.Console.WriteLine("\nUso de un objeto con una propiedad indexada\n");
            // Usando el indexador
            int indiceDelDia;
            DiasIndexados diasIndexados = new DiasIndexados();
            string nombreDelDia;
            for (indiceDelDia = 0; indiceDelDia < diasIndexados.ObtenerNumeroDeDias; indiceDelDia++)
            {
                nombreDelDia = diasIndexados[indiceDelDia];
                System.Console.WriteLine(nombreDelDia);
            }

            Console.ReadKey();
        }
    }
}
