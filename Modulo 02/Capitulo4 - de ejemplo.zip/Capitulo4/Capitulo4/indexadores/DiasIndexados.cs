﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace indexadores
{
    class DiasIndexados
    {
        private string[] dias = { "Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado" };
        public int ObtenerNumeroDeDias
        {
            get
            {
                return 7;
            }
        }

        public string this[int indice]
        {
            get
            {
                if(indice > 7) return "No existe";
                return dias[indice]; 
            }
        }
    }
}
