﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using griego;

namespace latin
{
    class Delta : Alfa 
    {
        void metodoAccesor()
        {
            Alfa a = new Alfa();
            //a.estoyProtegido = 10; // ilegal
            soyProtegido = 10; // legal
            //a.metodoProtegido(); // ilegal
            metodoProtegido(); // legal
        }

    }
}
