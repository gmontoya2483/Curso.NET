﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace visibilidades
{
    class VisibilidadMismoEspacioDeNombres : VisibilidadDeMienbros
    {
        public void AccedientoMetodos()
        {
            VisibilidadDeMienbros vm = new VisibilidadDeMienbros();
            vm.var1 = 1;
            var4 = 4;
            vm.var5 = 5;
            vm.var6 = 6;
            vm.Met1();
            Met4();
            vm.Met5();
            vm.Met6();
        }
    }
}
