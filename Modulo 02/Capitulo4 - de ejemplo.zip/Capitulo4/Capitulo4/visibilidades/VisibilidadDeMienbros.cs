﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace visibilidades
{
    public class VisibilidadDeMienbros
    {
        public int var1;
        private int var2;
        int var3;
        protected int var4;
        internal int var5;
        protected internal int var6;

        public void Met1()
        {
            Console.WriteLine("Estoy en Met1. Es un miembro public");
        }

        private void Met2()
        {
            Console.WriteLine("Estoy en Met2. Es un miembro private");
        }

        void Met3()
        {
            Console.WriteLine("Estoy en Met3. Es un miembro public");
        }

        protected void Met4()
        {
            Console.WriteLine("Estoy en Met4. Es un miembro protected");
        }

        internal void Met5()
        {
            Console.WriteLine("Estoy en Met5. Es un miembro internal");
        }

        protected internal void Met6()
        {
            Console.WriteLine("Estoy en Met6. Es un miembro protected internal");
        }

    }
}
