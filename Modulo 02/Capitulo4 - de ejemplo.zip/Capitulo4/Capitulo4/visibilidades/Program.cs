﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace visibilidades
{
    class Program
    {
        static void Main(string[] args)
        {
            VisibilidadDeMienbros vm = new VisibilidadDeMienbros();
            vm.var1 = 1;
            vm.var5 = 5;
            vm.var6 = 6;
            vm.Met1();
            vm.Met5();
            vm.Met6();

            Console.ReadKey();
        }
    }
}
