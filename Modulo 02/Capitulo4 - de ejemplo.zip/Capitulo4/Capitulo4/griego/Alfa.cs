﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace griego
{
    public class Alfa
    {
        public int soyPublico;
        protected int soyProtegido;
        internal int soyInterno;

        public void metodoPublico()
        {
            Console.WriteLine("Método Público");
        }

        protected void metodoProtegido()
        {
            Console.WriteLine("Método Protegido");
        }

        internal void metodoInterno()
        {
            Console.WriteLine("Método Interno");
        }
    }
}
