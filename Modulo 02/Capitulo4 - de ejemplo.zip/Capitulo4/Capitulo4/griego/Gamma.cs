﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace griego
{
    class Gamma
    {
        public void metodoAccesor()
        {
            Alfa a = new Alfa();
            Beta b = new Beta();
            //a.estoyProtegido = 10; // ilegal
            //a.metodoProtegido(); // ilegal
            a.metodoInterno();
            b.metodoAccesor();
        }

    }
}
