﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace griego
{
    class Program
    {
        static void Main(string[] args)
        {
            Alfa a = new Alfa();
            Beta b = new Beta();
            Gamma g = new Gamma();

            g.metodoAccesor();
            b.metodoAccesor();

            Console.ReadKey();
        }
    }
}
