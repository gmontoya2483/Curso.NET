﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using griego;

namespace griego.protegido
{
    class Omega
    {
        public void MetodoEnOtroEspacioDeNombres()
        {
            Alfa a = new Alfa();
            // a.metodoProtegido(); // ilegal
        }
    }
}
