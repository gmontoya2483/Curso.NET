﻿using System;
using espaciosDeNombres.libros.inventario;

namespace espacios
{
    class Program
    {
        static void Main(string[] args)
        {
            Stock stk = new Stock();
            stk.AgregarInventario();
            Console.ReadKey();
        }
    }
}
