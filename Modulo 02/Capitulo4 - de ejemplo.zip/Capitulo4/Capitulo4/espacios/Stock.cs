﻿using System;

namespace espaciosDeNombres
{
    namespace libros
    {
        namespace inventario
        {
            class Stock
            {
                public void AgregarInventario()
                {
                    Console.WriteLine("Agregando inventario via AgregarInventario()!");
                }
            }
        }
    }
}
