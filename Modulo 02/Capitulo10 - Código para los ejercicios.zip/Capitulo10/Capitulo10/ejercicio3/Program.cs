﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Juan va a producir 5 trabajos rápidamente
            Productor juan = new Productor("Juan", 5, 5, 8000);
            // Nadia va a producir 3 trabajos grandes lentamente
            Productor nadia = new Productor("Nadia", 3, 25, 20000);
            // Simon va a producir 3 trabajos grandes
            Productor simon = new Productor("Simon", 3, 5, 10000);

            /*
             * Paso 1: Generar un nuevo thread para la impresora. Llamarlo
             *      threadImpresora e iniciar el delegado ThreadStart en el
             *      método EjecutarThread
             */
 
            /*
             * Paso 2: Configurar la prioridad del thread por encima de lo normal. Para
             *      ello utilizar el valor de la enumeración ThreadPriority.AboveNormal
             */

            /*
             * Paso 3: Iniciar el thread de la impresora
             */


            /*
             * Paso 4: Generar un nuevo thread para el Productor juan.
             *      Llamrlo t1 e iniciar el delegado ThreadStart en el
             *      método EjecutarThread
             */

            /*
             * Paso 5: Asignar el nombre "Juan" al thread
             */

            /*
             * Paso 6: Inciar el thread
             */

            /*
             * Paso 7: Generar un nuevo thread para el Productor nadia.
             *      Llamrlo t2 e iniciar el delegado ThreadStart en el
             *      método EjecutarThread
             */

            /*
             * Paso 8: Asignar el nombre "Nadia" al thread
             */

            /*
             * Paso 9: Inciar el thread
             */

            /*
             * Paso 10: Generar un nuevo thread para el Productor simon.
             *      Llamrlo t3 e iniciar el delegado ThreadStart en el
             *      método EjecutarThread
             */

            /*
             * Paso 11: Asignar el nombre "Simon" al thread
             */

            /*
             * Paso 12: Inciar el thread
             */


            // esperar hasta que todos los threads productores terminan
            // para luego terminar el thread de la impresora
            try
            {
                /*
                 * Paso 13: Unir todos los threads al proceso
                 *      principal (Main) para que el método
                 *      Detener de la impresora no se invoque
                 *      antes que finalicen todos los subprocesos
                 */

            }
            catch (ThreadInterruptedException e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
            Impresora.GetImpresora().Detener();
        }
    }
}
