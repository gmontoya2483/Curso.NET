﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3
{
    class ExcepcionDeColaVacia : Exception
    {
        private ICola cola;

        public ExcepcionDeColaVacia(ICola cola):base("La cola esta vacía.")
        {
            
            this.cola = cola;
        }

        public ICola Cola
        {
            get
            {
                return cola;
            }
        }
    }
}
