﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ejercicio3
{
    public class Impresora
    {
        private const int MILISEG_POR_PAGINA = 50;
        private ICola colaImpresion = new ColaCircular(10);
        private bool estadoEnEjecucion = true;

        /**
         * La clase Impresora también implementa el patrón de diseño 
         * Singleton por conveniencia
         */
        private static Impresora singleton = new Impresora();
        public static Impresora GetImpresora()
        {
            return singleton;
        }

        // El constructor debe ser privado para uso del Singleton
        private Impresora() { }

        public void AgregarTrabajo(TrabajoDeImpresion trabajo)
        {
            /*
             * Paso 1: El trabajo se agrega en memoria compartida.
             *      Se debe bloquear el acceso para mantener la
             *      información sin que la corrompa otro thread.
             *      Avisar a otros thread en espera
             */
                colaImpresion.AgregarAlFinal(trabajo);

        }

        private TrabajoDeImpresion GetTrabajoDeImpresion()
        {
            /*
             * Paso 2: El trabajo se obtiene de la memoria compartida.
             *      Se debe bloquear el acceso para mantener la
             *      información sin que la corrompa otro thread
             */
                return (TrabajoDeImpresion)colaImpresion.RemoverAlFrente();
        }

        public void Detener()
        {
            /*
             * Paso 3: El trabajo se detiene e informa en la memoria 
             *      compartida. Se debe bloquear el acceso para mantener 
             *      la información sin que la corrompa otro thread.
             *      Avisar a otros thread en espera
             */
                estadoEnEjecucion = false;
        }

        public void EjecutarThread()
        {
            TrabajoDeImpresion trabajo = null;

            Console.WriteLine("  C: El manejador de impresión esta levantando.");
            while (estadoEnEjecucion)
            {
                trabajo = null;

                lock (this)
                {
                    while (estadoEnEjecucion && colaImpresion.EstaVacio())
                    {
                        try
                        {
                            Console.WriteLine("  C: Esperando un trabajo de impresión.");
                            Monitor.Wait(this);
                        }
                        catch (ThreadInterruptedException e)
                        {
                            Console.WriteLine("Error: " + e.Message);
                        }
                    }
                    if (estadoEnEjecucion)
                    { // la cola de impresión no puede estar vacía
                        trabajo = GetTrabajoDeImpresion();
                    }
                }

                if (trabajo != null)
                {
                    Console.WriteLine("  C: Comenzando trabajo '" + trabajo.NombreDeTrabajo + "'");

                    // procesar el trabajo
                    try
                    {
                        Thread.Sleep(trabajo.NumeroDePaginas * MILISEG_POR_PAGINA);
                    }
                    catch (ThreadInterruptedException e)
                    {
                        Console.WriteLine("Error: " + e.Message);
                    }
                    // Informar que se ha consumido un trabajo de los producidos
                    Console.WriteLine("  C: Trabajo completado: '" + trabajo.NombreDeTrabajo + "'");
                }
            }

            // Procesar los trabajos que quedan antes de detener
            while (!colaImpresion.EstaVacio())
            {
                trabajo = GetTrabajoDeImpresion();
                // Informar que se comienza la capacidad de consumir trabajos producidos
                Console.WriteLine("  C: Comenzando el trabajo '" + trabajo.NombreDeTrabajo + "'");
                // procesar el trabajo
                try
                {
                    Thread.Sleep(trabajo.NumeroDePaginas * MILISEG_POR_PAGINA);
                }
                catch (ThreadInterruptedException e)
                {
                    Console.WriteLine("Error: " + e.Message);
                }
                Console.WriteLine("  C: Trabajo completado: '" + trabajo.NombreDeTrabajo + "'");
            }

            Console.WriteLine("  C: El manejador de trabajos de impresión se ha detenido.");
        }
    }
}