﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3
{
    class ExcepcionDeColaLlena : Exception
    {
        private ICola cola;

        public ExcepcionDeColaLlena(ICola cola):base("La cola esta llena.")
        {
            this.cola = cola;
        }

        public ICola Cola
        {
            get
            {
                return cola;
            }
        }
    }
}
