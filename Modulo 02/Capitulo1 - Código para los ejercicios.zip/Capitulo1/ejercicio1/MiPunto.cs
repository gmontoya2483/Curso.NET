﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class MiPunto
    {
        public int x;
        public int y;

        public String toString()
        {
            return ("[" + x + "," + y + "]");
        }
    }
}
