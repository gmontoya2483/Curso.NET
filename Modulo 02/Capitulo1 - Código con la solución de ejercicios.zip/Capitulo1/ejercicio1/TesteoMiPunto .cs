﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class TesteoMiPunto
    {
        static void Main(string[] args)
        {
            MiPunto comienzo, fin;

            comienzo = new MiPunto();
            fin = new MiPunto();

            comienzo.x = 10;
            comienzo.y = 10;
            fin.x = 20;
            fin.y = 30;
            Console.WriteLine("El valor x del comienzo es " + comienzo.x);
            Console.WriteLine("El valor y del comienzo es " + comienzo.y);
            Console.WriteLine("El valor x del fin es " + fin.x);
            Console.WriteLine("El valor y del fin es " + fin.y);

            MiPunto otroPunto;
            otroPunto = fin;
            Console.WriteLine("El valor x del otroPunto es " + otroPunto.x);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.y);
            Console.WriteLine("El valor x del fin es " + fin.x);
            Console.WriteLine("El valor y del fin es " + fin.y);

            otroPunto.x = 40;
            otroPunto.y = 50;

            Console.WriteLine("El valor x del otroPunto es " + otroPunto.x);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.y);
            Console.WriteLine("El valor x del fin es " + fin.x);
            Console.WriteLine("El valor y del fin es " + fin.y);

            otroPunto.x = 47;
            otroPunto.y = 30;

            Console.WriteLine("El valor x del otroPunto es " + otroPunto.x);
            Console.WriteLine("El valor y del otroPunto es " + otroPunto.y);
            Console.WriteLine("El valor x del fin es " + fin.x);
            Console.WriteLine("El valor y del fin es " + fin.y);
            Console.ReadKey();
        }
    }
}
