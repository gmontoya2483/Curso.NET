﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2_version1
{
    class PruebaVehiculos
    {
        static void Main(string[] args)
        {
            // Crear un a vehículo que pueda manejar 10,000 kilogramos de peso
            Console.WriteLine("Creando un a vehículo con un máximo de 10,000kg de carga.");
            Vehiculo vehiculo = new Vehiculo(10000.0);

            // Agregar algunas cajas
            Console.WriteLine("Agregar caja #1 (500kg)");
            vehiculo.carga = vehiculo.carga + 500.0;

            Console.WriteLine("Agregar caja #2 (250kg)");
            vehiculo.carga = vehiculo.carga + 250.0;

            Console.WriteLine("Agregar caja #3 (5000kg)");
            vehiculo.carga = vehiculo.carga + 5000.0;

            Console.WriteLine("Agregar caja #4 (4000kg)");
            vehiculo.carga = vehiculo.carga + 4000.0;

            Console.WriteLine("Agregar caja #5 (300kg)");
            vehiculo.carga = vehiculo.carga + 300.0;

            // Imprimir la carga final que soporta el vehículo
            Console.WriteLine("La carga del vehículo es " + vehiculo.carga + " kg");
            Console.ReadKey();
        }
    }
}
