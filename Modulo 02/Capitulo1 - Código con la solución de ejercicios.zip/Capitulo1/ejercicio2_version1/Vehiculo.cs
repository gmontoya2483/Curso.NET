﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2_version1
{
    class Vehiculo
    {
        public double cargaMaxima;
        public double carga;

        public Vehiculo(double carga_Maxima)
        {
            cargaMaxima = carga_Maxima;
        }
    }
}
