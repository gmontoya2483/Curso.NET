﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ejercicio2_version2;

namespace ejercicio2_version2
{
    class PruebaVehiculos
    {
        static void Main(string[] args)
        {
            // Crear un a vehículo que pueda manejar 10,000 kilogramos de peso
            Console.WriteLine("Creando un a vehículo con un máximo de 10,000kg de carga.");
            Vehiculo vehiculo = new Vehiculo(10000.0);

            // Agregar algunas cajas
            Console.WriteLine("Agregar caja #1 (500kg). Agregado = " + vehiculo.agregaCaja(500.0));
            Console.WriteLine("Agregar caja #2 (250kg). Agregado = " + vehiculo.agregaCaja(250.0));
            Console.WriteLine("Agregar caja #3 (5000kg). Agregado = " + vehiculo.agregaCaja(5000.0));
            Console.WriteLine("Agregar caja #4 (4000kg). Agregado = " + vehiculo.agregaCaja(4000.0));
            Console.WriteLine("Agregar caja #5 (300kg). Agregado = " + vehiculo.agregaCaja(300.0));

            // Imprimir la carga final que soporta el vehículo
            Console.WriteLine("La carga del vehículo es " + vehiculo.Carga + " kg");
            Console.ReadKey();
        }
    }
}
