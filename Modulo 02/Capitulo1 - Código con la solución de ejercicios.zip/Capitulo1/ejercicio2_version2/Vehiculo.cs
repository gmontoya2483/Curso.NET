﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2_version2
{
    class Vehiculo
    {
        private double cargaMaxima;
        private double carga;

        public Vehiculo(double carga_Maxima)
        {
            cargaMaxima = carga_Maxima;
        }

        public double CargaMaxima
        {
            get
            {
                return cargaMaxima;
            }
        }
        public double Carga
        {
            get
            {
                return carga;
            }
        }

        public bool agregaCaja(double nuevaCarga)
        {
            if ((nuevaCarga + carga) > cargaMaxima) return false;
            else carga = carga + nuevaCarga;
            return true;
        }
    }
}
