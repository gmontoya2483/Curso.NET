﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3.Utilidades
{
    class Horario
    {
        private int dia = 1;
        private int horaComienzo = 0;
        private int minutosComienzo = 0;
        private int horaFin = 0;
        private int minutosFin = 0;
        private int turnosPorHora = 0;

        public Horario(int d, int hc, int mc, int hf, int mf, int tph)
        {
            dia = d;
            horaComienzo = hc;
            minutosComienzo = mc;
            horaFin = hf;
            minutosFin = mf;
            turnosPorHora = tph;
        }

        public Horario(Horario f)
        {
            dia = f.dia;
            horaComienzo = f.horaComienzo;
            minutosComienzo = f.minutosComienzo;
            horaFin = f.horaFin;
            minutosFin = f.minutosFin;
        }

        public Horario agregar(int masDias)
        {
            Horario nuevaFecha = new Horario(this);
            nuevaFecha.dia += nuevaFecha.dia;
            return nuevaFecha;
        }

        public void imprimir()
        {
            Console.WriteLine("Horario: ");
            Console.WriteLine("Día: " + dia);
            Console.WriteLine("Hora de comienzo: " + horaComienzo);
            Console.WriteLine("Minutos de comienzo: " + minutosComienzo);
            Console.WriteLine("Hora de fin: " + horaFin);
            Console.WriteLine("Minutos de fin: " + minutosFin);
        }
        public int Dia
        {
            get
            {
                return dia;
            }
        }
        public int HoraComienzo
        {
            get
            {
                return horaComienzo;
            }
        }
        public int HoraFin
        {
            get
            {
                return horaFin;
            }
        }
        public int MinutosComienzo
        {
            get
            {
                return minutosComienzo;
            }
        }
        public int MinutosFin
        {
            get
            {
                return minutosFin;
            }
        }
        public int TurnosPorHora
        {
            get
            {
                return turnosPorHora;
            }
        }
    }
}
