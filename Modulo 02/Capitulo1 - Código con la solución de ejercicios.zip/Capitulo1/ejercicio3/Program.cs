﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ejercicio3.Utilidades;

namespace ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            int dia = 1;
            int horaComienzo = 9;
            int minutosComienzo = 30;
            int horaFin = 18;
            int minutosFin = 30;
            int turnosPorHora = 4;
            Horario h = new Horario(dia, horaComienzo, minutosComienzo,
                    horaFin, minutosFin, turnosPorHora);

            h.imprimir();

            Console.WriteLine("Día del horario: " + h.Dia);
            Console.WriteLine("Hora de comienzo del horario: " + h.HoraComienzo);
            Console.WriteLine("Minutos de comienzo del horario: " + h.MinutosComienzo);
            Console.WriteLine("Hora de fin del horario: " + h.HoraFin);
            Console.WriteLine("Minutos de fin del horario: " + h.MinutosFin);
            Console.WriteLine("Turnos por hora para el horario: " + h.TurnosPorHora);
            Console.ReadKey();
        }
    }
}
