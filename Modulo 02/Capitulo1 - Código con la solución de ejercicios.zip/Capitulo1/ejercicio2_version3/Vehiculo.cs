﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2_version3
{
    class Vehiculo
    {
        public double cargaMaxima;
        public double carga;
        private double KG_A_NEWTON = 9.8;

        public Vehiculo(double carga_Maxima)
        {
            cargaMaxima = kiloANewts(carga_Maxima);
        }

        public double CargaMaxima
        {
            get
            {
                return newtsAKilo(cargaMaxima);
            }
        }
        public double Carga
        {
            get
            {
                return newtsAKilo(carga);
            }
        }

        public bool agregaCaja(double nuevaCarga)
        {
            if ((kiloANewts(nuevaCarga) + carga) > cargaMaxima)
                return false;
            else
                carga = carga + kiloANewts(nuevaCarga);
            return true;
        }

        private double kiloANewts(double peso)
        {
            return (peso * KG_A_NEWTON);
        }

        private double newtsAKilo(double peso)
        {
            return (peso / KG_A_NEWTON);
        }
    }
}