﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class Nodo
    {
        public Object valor;
        public Nodo proximo;

        public Nodo(Object valor, Nodo proximo)
        {
            this.valor = valor;
            this.proximo = proximo;
        }

        public Nodo(Object valor) : this(valor, null) { }

        ~Nodo()
        {
            // Asegurarse que no quede ninguna referencia
            valor = proximo = null;
        }
    }
}
