﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recorrido
{
    class Dos
    {
        public void SegundoMetodo()
        {
            Tres t = new Tres();
            t.HaceAlgo();
        }
    }
}
