﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recorrido
{
    class Program
    {
        static void Main(string[] args)
        {
            Uno u = new Uno();
            u.PrimerMetodo();
            Console.ReadKey();
        }
    }
}
