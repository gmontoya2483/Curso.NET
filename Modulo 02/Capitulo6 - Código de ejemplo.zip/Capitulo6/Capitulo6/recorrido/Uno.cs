﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recorrido
{
    class Uno
    {
        public void PrimerMetodo()
        {
            Dos d = new Dos();
            try
            {
                d.SegundoMetodo();
            }
            catch (ArithmeticException e)
            {
                Console.WriteLine("Estoy en la clase Uno");
                Console.WriteLine("Se atrapó la excepción de la clase tres. " + e.Message);
            }
        }
    }
}
