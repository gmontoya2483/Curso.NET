﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recorrido
{
    class Tres 
    {
        public void HaceAlgo()
        {
            Console.WriteLine("Estoy en la clase Tres y lanzo una excepción");
            throw new ArithmeticException("Error en la clase Tres");
        }
    }
}
