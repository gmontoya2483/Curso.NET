﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace introduccion
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;

            String[] mensajes = { "Hola Mundo de Excepciones!", 
				"No, no se rompió!",
				"Acá tampoco!!" };

            while (i < 4)
            {
                Console.WriteLine(mensajes[i]);
                i++;
            }
        }
    }
}
