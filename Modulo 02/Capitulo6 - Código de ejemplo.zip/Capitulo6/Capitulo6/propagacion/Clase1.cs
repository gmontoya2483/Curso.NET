﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace propagacion
{
    class Clase1
    {
        public void Metodo1()
        {
            try
            {
                Console.WriteLine("Estoy en el Metodo1");
                Clase2 c = new Clase2();
                c.Metodo2();
            }
            catch (FileNotFoundException e)
            {
                Console.WriteLine("No se encontró el archivo. El error es: " + e.Message);
            }
        }
    }
}
