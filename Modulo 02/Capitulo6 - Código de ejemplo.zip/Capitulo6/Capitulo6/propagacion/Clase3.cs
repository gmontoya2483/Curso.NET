﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propagacion
{
    class Clase3
    {
        public void Metodo3()
        {
            Console.WriteLine("Estoy en el Metodo3");
            AccesoArchivos a = new AccesoArchivos();
            a.LeerArchivo();
        }
    }
}
