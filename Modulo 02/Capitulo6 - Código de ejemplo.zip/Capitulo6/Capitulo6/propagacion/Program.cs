﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propagacion
{
    class Program
    {
        static void Main(string[] args)
        {
            Clase1 c = new Clase1();
            c.Metodo1();
            Console.ReadKey();
        }
    }
}
