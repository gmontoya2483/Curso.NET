﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propagacion
{
    class Clase2
    {
        public void Metodo2()
        {
            Console.WriteLine("Estoy en el Metodo2");
            Clase3 c = new Clase3();
            c.Metodo3();
        }
    }
}
