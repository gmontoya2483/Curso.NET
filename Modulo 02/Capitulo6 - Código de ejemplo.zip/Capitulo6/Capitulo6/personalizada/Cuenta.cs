﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace personalizada
{
    class Cuenta
    {
        private double balance;

        public Cuenta(double balance)
        {
            this.balance = balance;
        }

        public void Deposita(double cantidad)
        {
            if (cantidad < 0)
                throw new ExcepcionFueraDeRango("No se puede depositar valores negativos", cantidad);
            else
                if(cantidad == 0)
                    throw new ExcepcionFueraDeRango("No se puede depositar 0", cantidad);
                else
                balance += cantidad;
        }

        public void Retira(double cantidad)
        {
            if (balance < cantidad)
                throw new ExcepcionSinSaldo("La cuenta no tiene suficiente saldo", cantidad);
            else
                balance -= cantidad;
        }
    }
}
