﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace personalizada
{
    class Program
    {
        static void Main(string[] args)
        {
            Cuenta c = new Cuenta(500.0);
            try
            {
                c.Deposita(0);
            }
            catch (ExcepcionFueraDeRango e)
            {
                Console.WriteLine("Se produjo una excepción: " + e.Message);
            }
            try
            {

                c.Retira(4000);
            }
            catch (ExcepcionSinSaldo e)
            {
                Console.WriteLine("Se produjo una excepción: " + e.Message);
                Console.WriteLine("Se intentó retirar: " + e.Cantidad);
            }

            try
            {
                c.Deposita(-2000);
            }
            catch (ExcepcionFueraDeRango e)
            {
                Console.WriteLine("Se produjo una excepción: " + e.Message);
                Console.WriteLine("Se intentó depositar: " + e.Cantidad);
            }

            Console.ReadKey();
        }
    }
}
