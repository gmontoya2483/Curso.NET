﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace personalizada
{
    class ExcepcionSinSaldo : Exception
    {
        private double cantidad;

        public ExcepcionSinSaldo(string mensaje, double cantidad)
            : base(mensaje)
        {
            this.cantidad = cantidad;
        }

        public double Cantidad
        {
            get
            {
                return cantidad;
            }
        }
    }
}
