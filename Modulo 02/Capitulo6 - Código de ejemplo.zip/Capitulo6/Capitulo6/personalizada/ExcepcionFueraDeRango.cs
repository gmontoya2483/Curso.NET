﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace personalizada
{
    class ExcepcionFueraDeRango : Exception
    {
        private double cantidad;

        public ExcepcionFueraDeRango(string mensaje, double cantidad):base(mensaje)
        {
            this.cantidad = cantidad;
        }
        public double Cantidad
        {
            get
            {
                return cantidad;
            }
        }
    }
}
