﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sencillo
{
    class EjemploExcepciones
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Ejecutando la sentencia try.");
                throw new NullReferenceException();
            }
           catch (NullReferenceException e)
            {
                Console.WriteLine("Atrapando la excepción #1.\n{0}", e.Message);
                Console.ReadKey();
            }
            catch
            {
                Console.WriteLine("Atrapando la excepción #2.");
            }
           finally
            {
                Console.WriteLine("ejecutando el bloque finally.");
                Console.WriteLine("");
                Console.WriteLine("Presione un tecla para salir.");
                Console.ReadKey();
            }
            Console.WriteLine("Siguiendo la ejecución");
            Console.WriteLine("Presione una tecla para salir ...");
            Console.ReadKey();
        }
    }
}

