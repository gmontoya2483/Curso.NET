﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace relanzar
{
    class Program
    {
        static void Main(string[] args)
        {
            Uno u = new Uno();

            try
            {
                u.PrimerMetodo();
            }
            catch (ArithmeticException e)
            {
                Console.WriteLine("Se atrapó la excepción de la clase Uno: " + e.Message);
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("Volcado de pila: " + e.StackTrace);
                Console.WriteLine("-------------------------------------"); 
                //Console.ReadKey(); 
                //Environment.Exit(0);
            }
            finally
            {
                Console.WriteLine("En Main. Limpia recursos para terminar");
            }

            Console.ReadKey();
        }
    }
}
