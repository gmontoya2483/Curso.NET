﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace framework
{
    class Empleado
    {
        // Crear una propiedad para el nivel del empleado
        private int nivel;

        public int Nivel
        {
            get { return nivel; }
            set { nivel = value; }
        }
    }
}
