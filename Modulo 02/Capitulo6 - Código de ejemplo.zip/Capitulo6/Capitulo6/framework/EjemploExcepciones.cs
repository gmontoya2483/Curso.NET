﻿using System;
using System.Collections.Generic;

namespace framework
{
    class EjemploExcepciones
    {
        public static void PromoverEmpleado(Object emp)
        {
            //Convertir el tipo del objeto a Empleado.
            Empleado e = (Empleado)emp;
            // Incrementar el nivel del empleado
            e.Nivel  = e.Nivel + 1;
        }

        public static void Main()
        {
            try
            {
                Object o = new Empleado();
                DateTime fecha = new DateTime(2001, 1, 1);
                //Promover al nuevo empleado.
                PromoverEmpleado(o);
                // Fecha de promoción: resulta en una InvalidCastException
                // porque fecha no es una instancia de Empleado
                PromoverEmpleado(fecha);
            }
            catch (InvalidCastException e)
            {
                Console.WriteLine("Error al pasar datos al método PromoverEmpleado. \n" + e.Message);
                Console.WriteLine("");
                Console.WriteLine("Presione un tecla para salir.");
                Console.ReadKey();
            }
        }
    }
}
