﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace notas
{
    class Alumnos
    {
        private String[] alumnos = { "Pedro", "Juan", "Helena", "Mónica",
			"Sebastián" };
        private int[] notas = { 7, 4, 6, 7, 8 };

        public String ControlDeNotas() {
		for (int i = 0; i < notas.Length; i++) {
			Console.WriteLine(notas[i]);
			Debug.Assert (notas[i] > 5 , DeterminarNota(i));
		}
		return "Control de Notas correcto";
	}

        public String DeterminarNota(int indice)
        {
            int noAprobado = notas[indice];
            String alumno = alumnos[indice];
            String resultado = "El alumno "
                    + alumno + " no aprueba con " + noAprobado + " de nota";
            return resultado;
        }
    }
}
