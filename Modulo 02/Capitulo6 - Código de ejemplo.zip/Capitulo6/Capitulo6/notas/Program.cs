﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace notas
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumnos examenes = new Alumnos();
            Console.WriteLine(examenes.ControlDeNotas());
            Console.ReadKey();
        }
    }
}
