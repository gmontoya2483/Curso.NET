﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class DerivadaA1 : BaseA
    {
	public override void MetodoA(){
        throw new DivideByZeroException("Se intentó dividir por cero"); 	
		}
    }
}
