﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class BaseA
    {
        public virtual void MetodoA()
        {
            throw new FormatException("Error de formato");
        }
    }
}
