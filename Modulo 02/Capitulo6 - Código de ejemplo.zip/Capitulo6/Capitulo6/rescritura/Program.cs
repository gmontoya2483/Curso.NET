﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class Program
    {
        static void Main(string[] args)
        {
            BaseA ba = new BaseA();
            DerivadaA1 da1 = new DerivadaA1();
            DerivadaA2 da2 = new DerivadaA2();

            try
            {
                ba.MetodoA();
            }
            catch (FormatException fe)
            {
                Console.WriteLine("Se lanzó la excepción: " + fe.Message);
            }

            try
            {
                da1.MetodoA();
            }
            catch (DivideByZeroException de)
            {
                Console.WriteLine("Se lanzó la excepción: " + de.Message);
            }

            try
            {
                da2.MetodoA();
            }
            catch (ArithmeticException ae)
            {
                Console.WriteLine("Se lanzó la excepción: " + ae.Message);
            }

            try
            {
                da1.MetodoA();
            }
            catch (ArithmeticException ae)
            {
                Console.WriteLine("Se lanzó la excepción: " + ae.Message);
            }

            Console.ReadKey();
        }
    }
}
