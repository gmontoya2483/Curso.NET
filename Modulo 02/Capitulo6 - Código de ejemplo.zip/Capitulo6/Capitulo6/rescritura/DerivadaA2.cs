﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rescritura
{
    class DerivadaA2 : DerivadaA1
    {
        public override void MetodoA()
        {
            throw new ArithmeticException("Acaba de ocurrir un error Aritmético"); 	
        }
    }
}
