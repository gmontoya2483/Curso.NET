﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace verificaciones
{
    class OverFlowTest
    {
        // Inicializar la variable con máximo entero posible.
        static int maxIntValue = 2147483647;

        // Utilizar la palabra clave checked.
        static int MetodoConVerificacion()
        {
            int z = 0;
            try
            {
                // La siguiente instrucción lanza una excepción
                // porque verifica el desbordamiento.
                z = checked(maxIntValue + 10);
            }
            catch (System.OverflowException e)
            {
                Console.WriteLine("Atapado a causa del checked:  " + e.ToString());
            }
            // El valor de z se conserva en 0.
            return z;
        }

        // Uso del cósfigo sin verificar
        static int MetodoSinVerificacion()
        {
            int z = 0;
            try
            {
                // Realizar el mismo cálculo sin verificar 
                // No lanza excepción alguna
                z = maxIntValue + 10;
            }
            catch (System.OverflowException e)
            {
                // Esto nunca se ejecuta.
                Console.WriteLine("Atapado a causa del checked:  " + e.ToString());
            }
            // Por no detectar el desbordamiento, la suma de 2147483647 + 10 es 
            // -2147483639 lo cual es el valor retornado.
            return z;
        }

        static void Main()
        {
            Console.WriteLine("\nEl valor de salida CON checked: {0}",
                              MetodoConVerificacion());
            Console.WriteLine("El valor de salida SIN checked: {0}",
                              MetodoSinVerificacion());
            Console.ReadKey();
        }
    }
}
