﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace postcondicion
{
    class Pila
    {
        private int[] vec = new int[10];
        private int indice = 0;
        private int elementos = 0;

        public void Agregar(int valor)
        {
            if (indice == 9)
                throw new ExcepcionPila("Pila llena");
            vec[indice] = valor;
            elementos = ++indice;
        }

        public int Sacar()
        {
            int resultado = 0;
            if (indice == 0)
                throw new ExcepcionPila("Pila vacía");
            elementos = --indice;
            resultado = vec[indice];
            Debug.Assert(elementos == indice);
            return resultado;
        }
    }
}
