﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace postcondicion
{
    class Program
    {
        static void Main(string[] args)
        {
 		Pila p = new Pila();
		try {
			p.Agregar(8);
			p.Agregar(4);
			p.Agregar(3);
			p.Agregar(4);
			p.Sacar();
			p.Sacar();
			p.Sacar();
			p.Sacar();
			p.Sacar();
		} catch (ExcepcionPila e) {
            Console.WriteLine(e.StackTrace);
		}
		Console.WriteLine();
        Console.ReadKey();
       }
    }
}
