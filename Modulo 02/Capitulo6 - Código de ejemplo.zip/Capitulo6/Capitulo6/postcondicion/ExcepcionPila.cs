﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace postcondicion
{
    class ExcepcionPila : Exception
    {
        public ExcepcionPila(String mensaje)
            : base(mensaje)
        {
        }
    }
}
