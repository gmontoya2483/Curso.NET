﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propiedades
{
    class DesbordamientoDeTablaDeLogException : Exception
    {
        const string mensajeDeDesbordamiento = "La tabla de log se desbordó.";

        public DesbordamientoDeTablaDeLogException(
            string mensajeAuxiliar, Exception interna) :
            base(String.Format("{0} - {1}",
                   mensajeDeDesbordamiento, mensajeAuxiliar), interna)
        {
            this.HelpLink = "http://msdn.microsoft.com";
            this.Source = "DesbordamientoDeTablaDeLogException";
        }

    }
}
