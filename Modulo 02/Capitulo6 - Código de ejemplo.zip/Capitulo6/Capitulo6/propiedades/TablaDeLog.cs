﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propiedades
{
    class TablaDeLog
    {
        protected string[] areaDeLog;
        protected int elementosEnUso;

        public TablaDeLog(int numElementos)
        {
            areaDeLog = new string[numElementos];
            elementosEnUso = 0;
        }

        // El método AgregarRegistro lanza una excepción derivada de Exception
        // si el límite del vector se sobrepasá y se lanza la excepción 
        public int AgregarRegistro(string nuevoRegistro)
        {
            try
            {
                areaDeLog[elementosEnUso] = nuevoRegistro;
                return elementosEnUso++;
            }
            catch (Exception e)
            {
                throw new DesbordamientoDeTablaDeLogException(
                    String.Format("El registro \"{0}\" no se guardó en el log.",
                        nuevoRegistro), e);
            }
        }
    }
}
