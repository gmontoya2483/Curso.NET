﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace propiedades
{
    class EjemploExcepcionDeUsuario
    {        
        // Crear una tabla de log y forzar un desbordamiento.
        public static void Main()
        {
            TablaDeLog log = new TablaDeLog(4);

            Console.WriteLine(
                "Este ejemplo de \n   Exception.Message, \n" +
                "   Exception.HelpLink, \n   Exception.Source, \n" +
                "   Exception.StackTrace, y \n   Exception." +
                "TargetSite \ngenera la siguiente salida.");

            try
            {
                for (int cantidad = 1; ; cantidad++)
                {
                    log.AgregarRegistro(
                        String.Format(
                            "Número de registro de log {0}", cantidad));
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nMessage (mensaje) ---\n{0}", ex.Message);
                Console.WriteLine(
                    "\nHelpLink (enlace para la ayuda) ---\n{0}", ex.HelpLink);
                Console.WriteLine("\nSource (fuente) ---\n{0}", ex.Source);
                Console.WriteLine(
                    "\nStackTrace (volcado de pila) ---\n{0}", ex.StackTrace);
                Console.WriteLine(
                    "\nTargetSite (sitio al que apunta) ---\n{0}", ex.TargetSite);
                Console.WriteLine("");
                Console.WriteLine("Presione un tecla para salir.");
                Console.ReadKey();
            }
        }
    }
}


