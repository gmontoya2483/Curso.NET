﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace simple
{
    class Program
    {
        static void Main(string[] args)
        {
            Meses m = new Meses();
            m.ImprimeMes(13);
        }
    }
}
