﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace registro
{
    class Uno
    {
        public void PrimerMetodo()
        {
            Dos d = new Dos();
            try
            {
                d.SegundoMetodo();
            }
            catch (ArithmeticException e)
            {
                Console.WriteLine("Se atrapó la excepción de la clase Dos");
                string fuente = "registro";
                string log = "Application";
                string mensaje = "Aplicación: registro. Clase: Uno. Método: PrimerMetodo. Error: " 
                    + e.Message + ". Volcado de pila: " + e.StackTrace;
                // Verificar si el origen del evento existe, y si no, crearlo.
                if (!EventLog.SourceExists(fuente))
                {
                    EventLog.CreateEventSource(fuente, log);
                }

                // Escribir el mensaje en el log de eventos de Windows.
                EventLog.WriteEntry(fuente, mensaje, EventLogEntryType.Error);

                throw new ArithmeticException("Error en la clase Uno");
            }
            finally
            {
                Console.WriteLine("Esto se ejecuta siempre. Estoy en la clase Uno");
            }
        }
    }
}
