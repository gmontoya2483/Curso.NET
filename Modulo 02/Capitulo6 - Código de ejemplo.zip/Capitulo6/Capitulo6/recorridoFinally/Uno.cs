﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recorridoFinally
{
    class Uno
    {
        public void PrimerMetodo()
        {
            Dos d = new Dos();
            try
            {
                d.SegundoMetodo();
            }
            catch (ArithmeticException e)
            {
                Console.WriteLine("Se atrapó la excepción de la clase Dos");
                Console.WriteLine("-------------------------------------");
                Console.WriteLine("Volcado de pila: " + e.StackTrace);
                Console.WriteLine("-------------------------------------");
                throw new ArithmeticException("Error en la clase Uno");
            }
            finally
            {
                Console.WriteLine("Esto se ejecuta siempre. Estoy en la clase Uno");
            }
        }
    }
}
