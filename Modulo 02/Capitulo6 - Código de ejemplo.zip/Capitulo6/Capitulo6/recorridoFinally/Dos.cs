﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recorridoFinally
{
    class Dos 
    {
        public void SegundoMetodo()
        {
            Tres t = new Tres();

            try
            {
                t.HaceAlgo();
            }

            finally
            {
                Console.WriteLine("Esto se ejecuta siempre. Estoy en la clase Dos");
            }
        }
    }
}
