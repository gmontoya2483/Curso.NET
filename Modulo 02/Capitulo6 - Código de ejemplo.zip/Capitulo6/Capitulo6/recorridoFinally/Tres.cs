﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace recorridoFinally
{
    class Tres 
    {
        public void HaceAlgo()
        {
            throw new ArithmeticException("Error en la clase Tres");
        }
    }
}
