﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vector
{
    class VectorConExcepcionManejada
    {
        public void ManejaVector()
        {
            int i = 0;
            int j = 0;

            String[] mensajes = { "Hola Mundo de Excepciones!",
				"No, no se rompió!", "Acá tampoco!!" };

            while (i < 4)
            {
                try
                {
                    Console.WriteLine(mensajes[i]);
                }
                catch (IndexOutOfRangeException e)
                {
                    Console.WriteLine("Error: " + e.Message);
                    Console.WriteLine("Reiniciando el valor del índice");
                    i = -1;
                }
                finally
                {
                    Console.WriteLine("Esto se imprime siempre");
                }
                i++;
                j++;
                if (j == 20)
                {
                    Console.WriteLine("Forzando la finalización del ciclo");
                    i = 4;
                }
            }
        }
    }
}
