﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vector
{
    class Inicio
    {
        public void ManejaVector()
        {
            int i = 0;

            String[] saludos = { "Hola Mundo de Excepciones!",
				"No, no se rompió!", "Acá tampoco!!" };

            while (i < 4)
            {
                Console.WriteLine(saludos[i]);
                i++;
            }
        }
    }
}
