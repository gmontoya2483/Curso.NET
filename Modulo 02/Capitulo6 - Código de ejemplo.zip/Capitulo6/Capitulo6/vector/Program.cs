﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace vector
{
    class Program
    {
        static void Main(string[] args)
        {
            //Inicio i = new Inicio();
            //i.ManejaVector();
            
            VectorConExcepcionManejada vcem = new VectorConExcepcionManejada();
            vcem.ManejaVector();
            Console.ReadKey();
        }
    }
}
