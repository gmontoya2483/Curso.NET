﻿using System;
using System.Threading;

namespace uniones
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread threadUno = new Thread(new ThreadStart(Metodo1));
            Thread threadDos = new Thread(new ThreadStart(Metodo2));
            threadUno.Start();
            threadDos.Start();
            threadUno.Join();
            Console.WriteLine("Finalizando Main");
            Console.ReadKey();
        }

        public static void Metodo1()
        {
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("El thread 1 escribe: {0}", i);
            }
        }

        public static void Metodo2()
        {
            for (int i = 10; i >= 5; i--)
            {
                Console.WriteLine("El thread 2 escribe: {0}", i);
            }
        }
    }
}