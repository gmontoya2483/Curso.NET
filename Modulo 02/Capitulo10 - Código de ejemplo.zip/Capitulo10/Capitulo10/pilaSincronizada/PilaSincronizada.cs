﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace pilaSincronizada
{
    class PilaSincronizada
    {
        private int indice = 0;
        private int[] datos = new int[20];

        public void Poner(int d)
        {
            lock (this)
            {
                datos[indice] = d;
                Console.WriteLine("Poner\t{0}\t Índice: {1}", Thread.CurrentThread.Name, indice);
                indice++;
            }
        }

        public int Sacar()
        {
            lock (this)
            {
                indice--;
                Console.WriteLine("Sacar\t{0}\tValor: {1}\tÍndice: {2}", Thread.CurrentThread.Name, datos[indice], indice);
                return datos[indice];
            }
        }
    }
}
