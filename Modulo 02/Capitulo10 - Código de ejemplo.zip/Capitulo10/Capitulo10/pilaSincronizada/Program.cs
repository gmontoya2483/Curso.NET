﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace pilaSincronizada
{
    class Program
    {
        private static  PilaSincronizada ps = new PilaSincronizada();

        static void Main(string[] args)
        {
            Thread[] threadsSincronizadosPoner = new Thread[6];
            for (int i = 0; i < threadsSincronizadosPoner.Length; i++)
            {
                threadsSincronizadosPoner[i] = new Thread(new ThreadStart(PonerDatosSincronizados));
                threadsSincronizadosPoner[i].Name = "Thread " + i;
                threadsSincronizadosPoner[i].Start();
            }

            Thread[] threadsSincronizadosSacar = new Thread[6];
            for (int i = 0; i < threadsSincronizadosSacar.Length; i++)
            {
                threadsSincronizadosSacar[i] = new Thread(new ThreadStart(SacarDatosSincronizados));
                threadsSincronizadosSacar[i].Name = "Thread " + i;
                threadsSincronizadosSacar[i].Start();
            }

            Console.ReadKey();
        }

        public static void PonerDatosSincronizados()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("El {0} intenta poner el valor {1}", Thread.CurrentThread.Name, i);
                ps.Poner(i);
            }
        }

        public static void SacarDatosSincronizados()
        {
            Thread.Sleep(500);
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("El {0} saca el valor {1}", Thread.CurrentThread.Name, ps.Sacar());
            }
        }
    }
}
