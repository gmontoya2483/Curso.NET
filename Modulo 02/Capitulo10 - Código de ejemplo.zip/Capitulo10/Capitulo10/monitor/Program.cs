﻿using System;
using System.Threading;

namespace monitor
{
    class Program
    {
        private static PilaSincronizada ps = new PilaSincronizada();

        static void Main(string[] args)
        {
            Thread[] threadsSincronizadosPoner = new Thread[6];
            for (int i = 0; i < threadsSincronizadosPoner.Length; i++)
            {
                threadsSincronizadosPoner[i] = new Thread(new ThreadStart(PonerDatosSincronizados));
                threadsSincronizadosPoner[i].Name = "Thread " + i;
                threadsSincronizadosPoner[i].Start();
//                threadsSincronizadosPoner[i].Join();
            }

            Thread[] threadsSincronizadosSacar = new Thread[6];
            for (int i = 0; i < threadsSincronizadosSacar.Length; i++)
            {
                threadsSincronizadosSacar[i] = new Thread(new ThreadStart(SacarDatosSincronizados));
                threadsSincronizadosSacar[i].Name = "Thread " + i;
                threadsSincronizadosSacar[i].Start();
//                threadsSincronizadosSacar[i].Join();
            }

            Console.ReadKey();
        }

        public static void PonerDatosSincronizados()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("El {0} intenta poner el valor {1}", Thread.CurrentThread.Name, i);
                ps.Poner(i);
            }
        }

        public static void SacarDatosSincronizados()
        {
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("El {0} saca el valor {1}", Thread.CurrentThread.Name, ps.Sacar());
            }
        }
    }
}
