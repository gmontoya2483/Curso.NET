﻿using System;
using System.Threading;

namespace monitor
{
    class PilaSincronizada
    {
        private int indice = 0;
        private int[] datos = new int[20];

        public void Poner(int d)
        {
            lock (this)
            {
                datos[indice] = d;
                Console.WriteLine("Poner\t{0}\t Índice: {1}", Thread.CurrentThread.Name, indice);
                indice++;
                Monitor.Pulse(this);
            }
        }

        public int Sacar()
        {

            int aux = 0;
            lock (this)
            {
                // Puede entrar el mismo thread u otro, pero
                // si no hay datos en el vector, esperar.
                while (datos.Length == 0)
                {
                    try
                    {
                        Monitor.Wait(this);
                    }
                    catch (SynchronizationLockException e)
                    {
                        Console.WriteLine(e);
                    }
                    catch (ThreadInterruptedException e)
                    {
                        Console.WriteLine(e);
                    }
                }
                indice--;
                aux = datos[indice];
                Monitor.Pulse(this);
            }
            Console.WriteLine("Sacar\t{0}\tValor: {1}\tÍndice: {2}", Thread.CurrentThread.Name, aux, indice);
            return aux;
        }
    }
}
