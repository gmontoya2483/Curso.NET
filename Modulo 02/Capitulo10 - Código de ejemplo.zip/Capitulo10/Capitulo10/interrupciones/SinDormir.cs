﻿using System;
using System.Threading;

namespace interrupciones
{
    class SinDormir
    {
        bool _aDormir = false;

        public bool ADormir
        {
            set { _aDormir = value; }
        }

        public SinDormir() { }

        public void EjecutarThread()
        {
            Console.WriteLine("El thread nuevoThread está ejecutando EjecutarThread().");
            while (!_aDormir)
            {
                // Usar SpinWait en lugar de Sleep para demostrar el 
                // efecto de llamar a Interrupt en un thread en ejecución
                // y asegurarse que no se llamó a Sleep todavía.
                Thread.SpinWait(10000000);
            }
            try
            {
                Console.WriteLine("El thread nuevoThread se va a dormir.");

                // Cuando nuevoThread se va a dormir es despertado
                // inmediatamente por una ThreadInterruptedException.
                Thread.Sleep(Timeout.Infinite);
            }
            catch (ThreadInterruptedException e)
            {
                Console.WriteLine("El thread nuevoThread no puede dormir - " +
                    "fue interrumpido por el thread de Main.");
                Console.WriteLine("El mensaje de excepción es: {0}", e.Message);
            }
        }
    }
}