﻿using System;
using System.Threading;

namespace interrupciones
{
    class Program
    {
        static void Main(string[] args)
        {
            SinDormir despierto = new SinDormir();
            Thread nuevoThread =
                new Thread(new ThreadStart(despierto.EjecutarThread));
            nuevoThread.Start();

            // La siguiente línea causa que se lanze una excepción
            // en EjecutarThread si esta actualmente bloqueado o se
            // bloquea en el futuro
            nuevoThread.Interrupt();
            Console.WriteLine("El thread de Main llama a Interrupt en nuevoThread.");

            // Indicarle a nuevoThread que duerma.
            despierto.ADormir = true;

            // Esperar que termine nuevoThread.
            nuevoThread.Join();
            Console.ReadKey();
        }
    }
}
