﻿using System;
using System.Threading;
using pila;
using producir;
using consumir;

namespace productorConsumidor
{
    class Program
    {
        static void Main(string[] args)
        {
            Pila<int> pila = new Pila<int>();

            Productor p1 = new Productor(pila);
            Thread prodT1 = new Thread(new ThreadStart(p1.Produciendo));
            prodT1.Start();
 //           prodT1.Join();

            Consumidor c1 = new Consumidor(pila);
            Thread consT1 = new Thread(new ThreadStart(c1.Consumiendo));
            consT1.Start();
 //           consT1.Join();

            Productor p2 = new Productor(pila);
            Thread prodT2 = new Thread(new ThreadStart(p2.Produciendo));
            prodT2.Start();
//            prodT2.Join();

            Consumidor c2 = new Consumidor(pila);
            Thread consT2 = new Thread(new ThreadStart(c2.Consumiendo));
            consT2.Start();
//            consT2.Join();

            Console.ReadKey();
        }
    }
}
