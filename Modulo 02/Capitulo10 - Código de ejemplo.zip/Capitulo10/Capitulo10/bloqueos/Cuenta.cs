﻿using System;

namespace bloqueos
{
    class Cuenta
    {
        private int balance;

        Random r = new Random();

        public Cuenta(int inicial)
        {
            balance = inicial;
        }

        int Retiro(int cantidad)
        {

            // Esta condición es siempre falsa salvo que
            // se comente la instrucción de bloqueo
            if (balance < 0)
            {
                throw new Exception("Balance Negativo");
            }

            // Si se comenta la próxima línea se puede
            // apreciar lo ocurrido cuando no se bloquea
            lock (this)
            {
                if (balance >= cantidad)
                {
                    Console.WriteLine("Balance antes de retirar:  " + balance);
                    Console.WriteLine("Cantidad a retirar      : -" + cantidad);
                    balance = balance - cantidad;
                    Console.WriteLine("Balance luego del retiro: " + balance);
                    return cantidad;
                }
                else
                {
                    return 0; // transacción rechazada
                }
            }
        }

        public void HacerTransacciones()
        {
            int aux = 0;
            int valor = 0;
            for (int i = 0; i < 50 && balance > 0; i++)
            {
                valor = r.Next(1, 100);
                aux = Retiro(valor);
                if (aux == 0)
                {
                    Console.WriteLine("Transacción rechazada para {0}", valor);
                }
            }
        }
    }
}
