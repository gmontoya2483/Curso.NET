﻿using System.Text;
using System.Threading;

namespace interbloqueo
{
    class Program
    {
        static StringBuilder texto = new StringBuilder();
        static StringBuilder otroTexto = new StringBuilder();

        static void Main(string[] args)
        {
            Thread primerThread = new Thread(new ThreadStart(Metodo1));
            Thread segundoThread = new Thread(new ThreadStart(Metodo2));
            primerThread.Start();
            segundoThread.Start();
        }

        public static void Metodo1()
        {
            lock (texto)
            {
                Thread.Sleep(10);
                for (int i = 1; i <= 20; i++)
                {
                    texto.Append(i.ToString() + " ");
                }
                lock (otroTexto)
                {
                    otroTexto.Append(texto.ToString());
                    for (int i = 1; i <= 20; i++)
                    {
                        otroTexto.Append(i.ToString() + " ");
                    }
                }
            }
        }
        public static void Metodo2()
        {
            lock (otroTexto)
            {
                Thread.Sleep(10);
                for (int i = 21; i <= 40; i++)
                {
                    otroTexto.Append(i.ToString() + " ");
                }
                lock (texto)
                {
                    texto.Append(otroTexto.ToString());
                    for (int i = 21; i <= 40; i++)
                    {
                        texto.Append(i.ToString() + " ");
                    }
                }
            }
        }
    }
}

