﻿using System;
using pila;

namespace producir
{
    public class Productor
    {
        private Pila<int> pila;
        private int nroThread;
        private static int contador = 1;

        public Productor(Pila<int> s)
        {
            pila = s;
            nroThread = contador++;
        }

        public void Produciendo()
        {
            for (int i = 0; i < 20; i++)
            {
                pila.Poner(i);
                Console.WriteLine("Productor " + nroThread + ": " + i);
            }
        }
    }
}
