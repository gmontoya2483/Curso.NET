﻿using System;
using System.Threading;

namespace finalizar
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            ControladorThread ct = new ControladorThread();
            ct.IniciarThread();
            while (i < 150) Console.WriteLine("Ciclo en Main: " + i++);
            ct.FinalizarThread();
            Console.ReadKey();
        }
    }
}
