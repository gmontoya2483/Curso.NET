﻿using System;

namespace finalizar
{
    class ThreadConFinalizacion
    {
        private bool terminar = false;

        public void EjecutarThread()
        {
            int i;
            i = 0;
            while (!terminar)
            {
                Console.WriteLine("Hola desde EjecutarThread " + i++);
            }
        }

        public void FinEjecucion()
        {
            terminar = true;
        }
    }
}
