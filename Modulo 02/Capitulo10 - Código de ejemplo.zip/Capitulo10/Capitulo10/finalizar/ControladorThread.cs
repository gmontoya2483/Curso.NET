﻿using System.Threading;

namespace finalizar
{
    public class ControladorThread
    {
        private ThreadConFinalizacion r = new ThreadConFinalizacion();
        private Thread t;

        public ControladorThread()
        {
            t = new Thread(new ThreadStart(r.EjecutarThread));
        }

        public void IniciarThread()
        {
            t.Start();
        }
        public void FinalizarThread()
        {
            //Usa la instancia específica de ThreadConFinalizacion
            r.FinEjecucion(); 
        }

    }
}
