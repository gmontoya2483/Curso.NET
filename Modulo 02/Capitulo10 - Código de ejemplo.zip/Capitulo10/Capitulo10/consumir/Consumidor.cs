﻿using System;
using pila;

namespace consumir
{
    public class Consumidor
    {
        private Pila<int> pila;
        private int nroThread;
        private static int contador = 1;

        public Consumidor(Pila<int> s)
        {
            pila = s;
            nroThread = contador++;
        }

        public void Consumiendo()
        {
            int aux = 0;

            for (int i = 0; i < 20; i++)
            {
                aux = pila.Sacar();
                Console.WriteLine("Consumidor " + nroThread + ": " + aux);
            }
        }
    }
}
