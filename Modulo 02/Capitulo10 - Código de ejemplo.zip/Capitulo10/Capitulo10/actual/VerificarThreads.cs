﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace actual
{
    class VerificarThreads
    {
        private Queue<String> nombresDeThreads = new Queue<String>();
        private int cantidadThreads = 10;

        public void VerificaThread()
        {
            Thread.CurrentThread.Name = "VerificaThread";

            // Impresión para guiar donde se realiza la salida
            Thread[] threads = new Thread[cantidadThreads];
            Console.WriteLine("Esto se imprime antes");
            Console.WriteLine("Thread actual que crea subprocesos: " + Thread.CurrentThread.Name);
          for (int i = 0; i < threads.Length; i++)
            {
                threads[i] = new Thread(new ThreadStart(this.EjecutarThread));
                threads[i].Name = "Thread " + i;
                threads[i].Start();
                threads[i].Join();
            }
            Console.WriteLine("Fin del Thread : " + Thread.CurrentThread.Name);
        }

        public void EjecutarThread()
        {
            nombresDeThreads.Enqueue("Agregado: " + Thread.CurrentThread.Name);
            Console.WriteLine("Fin del Thread " + Thread.CurrentThread.Name);
        }

        public Queue<String> NombresDeThreads
        {
            get
            {
                return nombresDeThreads;
            }
        }
    }
}