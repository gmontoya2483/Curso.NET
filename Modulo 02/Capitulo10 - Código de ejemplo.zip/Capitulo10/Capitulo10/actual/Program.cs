﻿using System;
using System.Threading;

namespace actual
{
    class Program
    {
        static void Main(string[] args)
        {
            Thread.CurrentThread.Name = "Main";
            // Impresión para guiar donde se realiza la salida
            Console.WriteLine("Thread actual" + Thread.CurrentThread.Name);
            VerificarThreads test = new VerificarThreads();
            Thread t = new Thread(new ThreadStart(test.VerificaThread));
            t.Start();
            t.Join();
            if (test.NombresDeThreads.Count == 0)
                Console.WriteLine("No hay nombres en la cola");
            // Impresión de todo los nombres de threads encolados
            foreach (String str in test.NombresDeThreads)
                Console.WriteLine("Nombre de Thread en cola: " + str);
            // Impresión para guiar donde se realiza la salida
            Console.WriteLine("Esto se imprime al final");
            Console.ReadKey();
        }
    }
}
