﻿using System;
using System.Threading;

namespace dormir
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            Tiempos r = new Tiempos();
            Thread t = new Thread(new ThreadStart(r.EjecutarThread));
            t.Start();
            while (true)
            {
                Console.WriteLine("Hola desde Main " + i++);
                if (i == 50)
                {
                    break;
                }
            }
            Console.ReadKey();
        }
    }
}
