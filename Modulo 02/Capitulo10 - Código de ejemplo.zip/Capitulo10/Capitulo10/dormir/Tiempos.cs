﻿using System;
using System.Threading;

namespace dormir
{
    class Tiempos
    {
        public void EjecutarThread()
        {
            int i;
            i = 0;
            // Pone a dormir el thread 2 segundos
            Thread.Sleep(2000);
            while (true)
            {
                Console.WriteLine("Hola desde EjecutarThread " + i++);
                if (i == 50)
                {
                    break;
                }
            }
        }
    }
}
