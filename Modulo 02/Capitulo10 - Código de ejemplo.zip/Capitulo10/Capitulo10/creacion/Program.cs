﻿using System;
using System.Threading;

namespace creacion
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            ThreadHola r = new ThreadHola();
            Thread t = new Thread(new ThreadStart(r.EjecutarThread));
            t.Start();
            while (true)
            {
                Console.WriteLine("Hola desde Main " + i++);
                if (i == 50)
                {
                    break;
                }
            }
            Console.ReadKey();
        }
    }
}
