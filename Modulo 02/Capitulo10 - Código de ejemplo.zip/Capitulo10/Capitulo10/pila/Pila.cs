﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace pila
{
    public class Pila<T>
    {
        private Stack<T> datos = new Stack<T>();

        public void Poner(T d)
        {
            lock (this)
            {
                datos.Push(d);
                Monitor.Pulse(this);
            }
            Console.WriteLine("Poner\t{0}\t Valor: {1}", Thread.CurrentThread.Name, d);
        }

        public T Sacar()
        {

            T aux = default(T);
            lock (this)
            {
                // Puede entrar el mismo thread u otro, pero
                // si no hay datos en el vector, esperar.
                while (datos.Count == 0) 
                {
                    try
                    {
                        Monitor.Wait(this);
                    }
                    catch (SynchronizationLockException e)
                    {
                        Console.WriteLine(e);
                    }
                    catch (ThreadInterruptedException e)
                    {
                        Console.WriteLine(e);
                    }
                }
                aux = datos.Pop();
                Monitor.Pulse(this);
            }
            Console.WriteLine("Sacar\t{0}\tValor: {1}", Thread.CurrentThread.Name, aux);
            return aux;
        }
    }
}
