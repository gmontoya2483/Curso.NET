﻿using System;
using System.Threading;

namespace prioridad
{
    public class VerificadorDePrioridades
    {
        bool banderaDelCiclo;

        public VerificadorDePrioridades()
        {
            banderaDelCiclo = true;
        }

        public bool BanderaDelCiclo
        {
            set { banderaDelCiclo = value; }
        }

        public void EjecutarThread()
        {
            long contadorDelThread = 0;

            while (banderaDelCiclo)
            {
                contadorDelThread++;
            }
            Console.WriteLine();
            Console.WriteLine("El {0} con la prioridad {1,11}" +
                " tiene una cuenta de = {2,13}", Thread.CurrentThread.Name,
                Thread.CurrentThread.Priority.ToString(),
                contadorDelThread.ToString("N0"));
        }
    }
}
