﻿using System;
using System.Threading;

namespace prioridad
{
    class Program
    {
        static void Main(string[] args)
        {
            VerificadorDePrioridades verificador = new VerificadorDePrioridades();
            ThreadStart delegadoDelComienzo =
                new ThreadStart(verificador.EjecutarThread);

            Thread threadUno = new Thread(delegadoDelComienzo);
            threadUno.Name = "Thread Uno";
            Thread threadDos = new Thread(delegadoDelComienzo);
            threadDos.Name = "Thread Dos";
            Console.WriteLine("Espere alrededor de 10 segundos por favor.");

            threadDos.Priority = ThreadPriority.BelowNormal;
            threadUno.Start();
            threadDos.Start();

            // Permitir contar por alrededor de 10 segundos.
            Thread.Sleep(10000);
            verificador.BanderaDelCiclo = false;
            Console.ReadKey();
        }
    }
}
