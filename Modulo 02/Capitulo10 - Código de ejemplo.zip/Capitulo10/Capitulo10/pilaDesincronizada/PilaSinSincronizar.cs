﻿using System;
using System.Threading;

namespace pilaDesincronizada
{
    class PilaSinSincronizar
    {
        private int indice = 0;
        private char[] datos = new char[20];

        public void Poner(char d)
        {
            datos[indice] = d;
            indice++;
            Console.WriteLine("Poner\t{0}\t Índice: {1}", Thread.CurrentThread.Name, indice);
        }

        public char Sacar()
        {
            indice--;
            Console.WriteLine("Sacar\t{0}\tValor: {1}\tÍndice: {2}", Thread.CurrentThread.Name, datos[indice], indice);
            return datos[indice];
        }
    }
}
