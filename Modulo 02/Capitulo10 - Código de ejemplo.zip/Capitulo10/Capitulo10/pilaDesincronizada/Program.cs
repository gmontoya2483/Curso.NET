﻿using System;
using System.Threading;

namespace pilaDesincronizada
{
    class Program
    {
        private static PilaSinSincronizar pss = new PilaSinSincronizar();

        static void Main(string[] args)
        {
            Thread[] threadsDesincronizadosPoner = new Thread[6];
            for (int i = 0; i < threadsDesincronizadosPoner.Length; i++)
            {
                threadsDesincronizadosPoner[i] = new Thread(new ThreadStart(PonerDatosDesincronizados));
                threadsDesincronizadosPoner[i].Name = "Thread " + i;
                threadsDesincronizadosPoner[i].Start();
 //               threadsDesincronizadosPoner[i].Join();
            }

            Thread[] threadsDesincronizadosSacar = new Thread[6];
            for (int i = 0; i < threadsDesincronizadosSacar.Length; i++)
            {
                threadsDesincronizadosSacar[i] = new Thread(new ThreadStart(SacarDatosDesincronizados));
                threadsDesincronizadosSacar[i].Name = "Thread " + i;
                threadsDesincronizadosSacar[i].Start();
 //               threadsDesincronizadosSacar[i].Join();
            }

            Console.ReadKey();
        }

        public static void PonerDatosDesincronizados()
        {
            char c;
            Random r = new Random();

            for (int i = 0; i < 3; i++)
            {
                c = (char)(r.Next(0, 26) + 'a');
                Console.WriteLine("El {0} intenta poner el valor {1}", Thread.CurrentThread.Name, c);
                pss.Poner(c);
            }
        }

        public static void SacarDatosDesincronizados()
        {
            Thread.Sleep(500);
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("El {0} saca el valor {1}", Thread.CurrentThread.Name, pss.Sacar());
            }
        }

    }
}
