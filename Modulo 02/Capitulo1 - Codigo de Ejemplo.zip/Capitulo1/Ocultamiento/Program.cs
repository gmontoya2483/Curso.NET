﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ocultamiento
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona p = new Persona();
        }
    }
}
