﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ocultamiento
{
    public class Persona
    {
        private String primerNombre;
        private String segundoNombre;
        private String apellido;
        private String documento;

        public Persona()
        {
        }

        public String getApellido()
        {
            return apellido;
        }

        public String getDocumento()
        {
            return documento;
        }

        public String getPrimerNombre()
        {
            return primerNombre;
        }

        public String getSegundoNombre()
        {
            return segundoNombre;
        }

        public void setApellido(String str)
        {
            apellido = str;
        }

        public void setDocumento(String str)
        {
            documento = str;
        }

        public void setPrimerNombre(String str)
        {
            primerNombre = str;
        }

        public void setSegundoNombre(String str)
        {
            segundoNombre = str;
        }
    }
}
