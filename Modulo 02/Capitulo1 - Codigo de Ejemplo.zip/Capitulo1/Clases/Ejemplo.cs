﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Clases
{
    public class Ejemplo
    {
        private int var1;
        private int var2;

        public int Var1
        {
            get { return var1; }
            set { var1 = value; }
        }

        public int Metodo()
        {
            return 20;
        }
    }
}
