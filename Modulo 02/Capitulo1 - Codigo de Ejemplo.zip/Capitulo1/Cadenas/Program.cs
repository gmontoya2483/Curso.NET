﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Cadenas
{
    class Program
    {
        static void Main(string[] args)
        {
            string string1 = "Esta es una cadena creada por asignación.";
            Console.WriteLine(string1);
            string string2a = "Este es un path C:\\Documentos\\Reporte1.doc";
            Console.WriteLine(string2a);
            string string2b = @"Este es el mismo path C:\\Documentos\\Reporte1.doc";
            Console.WriteLine(string2b);
            Console.ReadKey();
        }
    }
}
