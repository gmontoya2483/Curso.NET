﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsignacionReferencias
{
    public class AsignacionDeReferencias
    {
        public void Metodo(Horario h){
			int x = 7;
			int y = x;
			Horario h1 = new Horario(2, 8, 45, 12, 45, 3);
			Horario h2 = h;
			h2 = new Horario(2, 8, 45, 12, 45, 3);		
		}

        static void Main(string[] args)
        {
            AsignacionDeReferencias a = new AsignacionDeReferencias();
			int x = 7;
			int y = x;
			Horario h1 = new Horario(2, 8, 45, 12, 45, 3);
			Horario h2 = h1;
			h2 = new Horario(2, 8, 45, 12, 45, 3);
			a.Metodo(h2);
        }
    }
}
