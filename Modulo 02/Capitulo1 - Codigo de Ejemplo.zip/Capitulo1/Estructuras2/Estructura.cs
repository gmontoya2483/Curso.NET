﻿using System;
namespace Estructuras2
{
    struct Empleado
    {
        string nombre;

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        string designacion;

        public string Designacion
        {
            get { return designacion; }
            set { designacion = value; }
        }
        string ciudad;

        public string Ciudad
        {
            get { return ciudad; }
            set { ciudad = value; }
        }
        double salario;

        public double Salario
        {
            get { return salario; }
            set { salario = value; }
        }
        int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        public Empleado(string nombre, string designacion, string ciudad, double salario, int id)
        {
            this.nombre = nombre;
            this.designacion = designacion;
            this.ciudad = ciudad;
            this.salario = salario;
            this.id = id;
        }

        public void Mostrar()
        {
            System.Console.WriteLine("Valores Almacenados: {0}, {1}, {2}, {3}, {4}", nombre, designacion, ciudad, salario, id);
        }
    }
}