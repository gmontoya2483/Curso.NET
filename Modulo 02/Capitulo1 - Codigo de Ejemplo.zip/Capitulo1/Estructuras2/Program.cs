﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Estructuras2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Se puede declarar a pesar de no tener 
            // un constructor explícito por defecto
            Empleado e = new Empleado();
            e.Mostrar();
            // Uso del constructor declarado
            Empleado e2 = new Empleado("Sandra", "Desarroladora de Software", "Rosario", 60000, 2707);
            e2.Mostrar();
            System.Console.ReadKey();
        }
    }
}
