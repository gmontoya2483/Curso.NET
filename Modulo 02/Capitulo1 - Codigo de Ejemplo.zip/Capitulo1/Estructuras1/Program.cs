﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Estructuras1
{
    public struct Coordenadas
    {
        private int _x, _y;
        public Coordenadas(int x, int y) {
            _x = x;
            _y = y;
        }
        public int X { get { return _x; } set { _x = value; } }
        public int Y { get { return _y; } set { _y = value; } }
        public void MoverA(int x, int y)
        {
            _x = x;
            _y = y;
        }
        public override string ToString() {
            String res = ("x = " + _x + ", y = " + _y);
            return res;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Coordenadas c = new Coordenadas();
            c.X = 0;
            c.Y = 1;

            Console.WriteLine("X={0} , Y={1}", c.X, c.Y);
            Console.WriteLine(c);
            Console.ReadLine();
        }
    }
}
