﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Constructor
{
    public class Ejemplo
    {
        public Ejemplo(int v) { var1 = v; }
        private int var1;
        private int var2;
        public int getVar1() { return var1; }
    }
}
