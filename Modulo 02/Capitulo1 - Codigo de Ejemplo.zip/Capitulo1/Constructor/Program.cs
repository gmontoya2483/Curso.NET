﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Constructor
{
    class Program
    {
        static void Main(string[] args)
        {
            Ejemplo obj = new Ejemplo(8);
            int aux;
            aux = obj.getVar1();
        }
    }
}
