﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Metodos
{
    public class Fecha
    {
        private int dia;
        private int mes;
        private int anio;

        public string RetornaFecha(string dia, string mes, string anio) {
            string fecha = dia + "-" + mes + "-" + anio;
		return fecha;
        }
    }
}
