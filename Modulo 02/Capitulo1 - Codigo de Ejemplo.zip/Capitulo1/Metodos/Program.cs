﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Metodos
{
    class Program
    {
        static void Main(string[] args)
        {
            Fecha f = new Fecha();
            Console.WriteLine(f.RetornaFecha("21", "11", "2012"));
            Console.ReadKey();
        }
    }
}
