﻿using EspaciosDeNombres.Anidado;

namespace EspaciosDeNombres
{
    class Program
    {
        static void Main(string[] args)
        {
            Espacios2 e2 = new Espacios2();
        }
    }
}
