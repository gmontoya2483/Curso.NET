﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EspaciosDeNombres
{
    class Espacios { }
    interface EjemploInterfaz { }
    struct EjemploEstructura { }
    enum EjemploEnumeracion { a, b }
    delegate void EjemploDelegado(int i);

    namespace Anidado
    {
        class Espacios2 { }
    }
}
