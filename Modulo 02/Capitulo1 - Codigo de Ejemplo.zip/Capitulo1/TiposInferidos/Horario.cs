﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TiposInferidos
{
    public class Horario: IDisposable
    {
        private int dia = 1;
        private int horaComienzo = 9;
        private int minutosComienzo = 30;
        private int horaFin = 18;
        private int minutosFin = 30;
        private int turnosPorHora = 4;

        public Horario(int d, int hc, int mc, int hf, int mf, int tph)
        {
            dia = d;
            horaComienzo = hc;
            minutosComienzo = mc;
            horaFin = hf;
            minutosFin = mf;
            turnosPorHora = tph;
        }

        public Horario(Horario f)
        {
            dia = f.dia;
            horaComienzo = f.horaComienzo;
            minutosComienzo = f.minutosComienzo;
            horaFin = f.horaFin;
            minutosFin = f.minutosFin;
            turnosPorHora = f.turnosPorHora;
        }

        public Horario agregarDias(int masDias)
        {
            Horario nuevaFecha = new Horario(this);
            nuevaFecha.dia = nuevaFecha.dia + masDias;
            return nuevaFecha;
        }

        public void imprimir()
        {
            Console.WriteLine("Horario: ");
            Console.WriteLine("Día: " + dia);
            Console.WriteLine("Hora de comienzo: " + horaComienzo);
            Console.WriteLine("Minutos de comienzo: " + minutosComienzo);
            Console.WriteLine("Hora de fin: " + horaFin);
            Console.WriteLine("Minutos de fin: " + minutosFin);
            Console.WriteLine("Turnos por hora:" + turnosPorHora);
        }

        public int Dia
        {
            get { return dia; }
        }

        public int HoraComienzo
        {
            get { return horaComienzo; }
        }

        public int MinutosComienzo
        {
            get { return minutosComienzo; }
        }

        public int HoraFin
        {
            get { return horaFin; }
        }

        public int MinutosFin
        {
            get { return minutosFin; }
        }

        public int TurnosPorHora
        {
            get { return turnosPorHora; }
        }

        public void Dispose()
        {
            Console.WriteLine("Liberando recursos ...");
        }
    }
}

