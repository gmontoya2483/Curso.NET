﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TiposInferidos
{
    class Program
    {
        static void Main(string[] args)
        {
            // i se compila como un int 
            var i = 5;

            // s se compila como un string 
            var s = "Hola";

            // v se compila como un int[] 
            var v = new[] { 0, 1, 2};

            // Esta línea es un error de compilación
            // var v = new[] { 0, 1, 2, "Hola" };

            // obj se compila como un objeto del tipo Horario
            var obj = new Horario(1, 7, 30, 11, 00, 4);

            Console.WriteLine(i);
            Console.WriteLine(s);
            Console.WriteLine(v[1]);
            Console.WriteLine(obj.HoraComienzo);
            Console.ReadKey();
        }
    }
}
