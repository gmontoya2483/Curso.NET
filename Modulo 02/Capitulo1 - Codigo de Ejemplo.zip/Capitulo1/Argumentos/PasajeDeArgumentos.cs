﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Argumentos
{
    class PasajeDeArgumentos
    {
        public void CambiarEntero(int valor)
        {
            valor = 55;
        }

        public void CambiarRefObjeto(Horario referencia)
        {
            referencia = new Horario(1, 7, 30, 11, 00, 4);
        }

        public void CambiarAtributoObjeto(Horario referencia)
        {
            referencia.agregarDias(4);
        }
        static void Main(string[] args)
        {
            PasajeDeArgumentos p = new PasajeDeArgumentos();
            Horario h;
            int val;
            // Asignarle un valor al entero
            val = 11;
            // Intento de cambiarlo
            p.CambiarEntero(val);
            // ¿Cuál es el valor actual?
            Console.WriteLine("El valor del entero es: " + val);
            Console.WriteLine("-------------------");

            // Asignar un objeto del tipo Horario
            h = new Horario(2, 8, 45, 12, 45, 3);
            // Intento por cambiarlo
            p.CambiarRefObjeto(h);
            // ¿Cuál es el valor actual?
            h.Imprimir();
            Console.WriteLine("-------------------");

            // Cambiando el atributo día
            // a través de la referencia al objeto
            p.CambiarAtributoObjeto(h);
            // ¿Cuál es el valor actual?
            h.Imprimir();
            Console.ReadKey();
        }
    }
}
