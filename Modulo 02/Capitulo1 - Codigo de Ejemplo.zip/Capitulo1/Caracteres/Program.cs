﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Caracteres
{
    class Program
    {
        static void Main(string[] args)
        {
            char n = '\n';
            char t = '\t';
            char r = '\r';
            string cadena1 = "Hola Mundo\n" + n + "!!!!!!";
            string cadena2 = t + "\tHola Mundo";
            string cadena3 = "Hola Mundo\r" + r + "!!!!!!";

            Console.WriteLine(cadena1);
            Console.WriteLine(cadena2);
            Console.WriteLine(cadena3);
            Console.ReadKey();
        }
    }
}
