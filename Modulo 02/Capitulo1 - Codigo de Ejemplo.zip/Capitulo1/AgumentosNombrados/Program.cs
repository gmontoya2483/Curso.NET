﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AgumentosNombrados
{
    class Program
    {
        static void Main(string[] args)
        {
            // El método puede ser llamado en la forma normal, 
            // mediante el uso de la posición de los argumentos  
            Console.WriteLine(CalcularIMC(123, 64));

            // Los argumentos nombrados pueden ser suministrados
            // para los parámetros en cualquier orden.
            Console.WriteLine(CalcularIMC(peso: 123, altura: 64));
            Console.WriteLine(CalcularIMC(altura: 64, peso: 123));

            // Los argumentos posicionales no pueden seguir los argumentos con nombre.  
            // La siguiente sentencia provoca un error del compilador.  
            // Console.WriteLine(CalcularIMC(peso: 123, 64)); 

            // Los argumentos nombrados pueden seguir los argumentos posicionales.
            Console.WriteLine(CalcularIMC(123, altura: 64));
            Console.ReadKey();
        }

        static int CalcularIMC(int peso, int altura)
        {
            return (peso * 703) / (altura * altura);
        }
    }
}


