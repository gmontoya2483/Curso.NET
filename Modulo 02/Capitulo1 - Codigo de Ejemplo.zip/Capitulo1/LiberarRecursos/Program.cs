﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiberarRecursos
{
    class Program
    {
        static void Main(string[] args)
        {
            using (Horario h = new Horario(1, 7, 30, 11, 00, 4))
            {
                Console.WriteLine(h.Dia);
                Console.ReadKey();
            }
        }
    }
}
