﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArgumentosVariables
{
    class CantidadVariablesDeArgumentos
    {
        public void ParametrosVariables(params int[] vec)
        {
            for (int i = 0; i < vec.Length; i++)
            {
                Console.WriteLine(vec[i]);
            }
            Console.WriteLine();
        }

        public void ParametrosVariables2(params object[] vec)
        {
            for (int i = 0; i < vec.Length; i++)
            {
                Console.WriteLine(vec[i]);
            }
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            CantidadVariablesDeArgumentos v = new CantidadVariablesDeArgumentos();
            v.ParametrosVariables(1, 2, 3);
            v.ParametrosVariables2(1, 'a', "test");

            // También se pueden pasar un conjunto de objetos , 
            // siempre y cuando el tipo del vector coincida con 
            // el del método que se llama.
            int[] vector = new int[3] { 10, 11, 12 };
            v.ParametrosVariables(vector);
            Console.ReadKey();
        }
    }
}
