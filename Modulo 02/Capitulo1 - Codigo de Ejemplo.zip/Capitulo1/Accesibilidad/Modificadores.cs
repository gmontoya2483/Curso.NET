﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Accesibilidad
{
    class Modificadores
    {
        private int var1;
        public int var2;
        internal char var3 = 'c';
        protected double var4 = 4.5;
        protected internal string var5 = "Hola";
        int var6 = 6;

        public Modificadores() 
        {
            var1 = 1;
            var2 = 10;
            var3 = 'r';
            var4 = 8.3;
            var5 = "Saludar";
            var6 = 7;
        }
    }
}
