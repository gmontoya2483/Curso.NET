﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Accesibilidad
{
    class ModificadoresHerencia : Modificadores
    {
        public ModificadoresHerencia()
        {
            var2 = 10;
            var3 = 'b';
            var4 = 10;
            var5 = "Hola Mundo";
        }
    }
}
