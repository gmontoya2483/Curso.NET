﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Accesibilidad
{
    class Program
    {
        static void Main(string[] args)
        {
            Modificadores m = new Modificadores();
            Console.WriteLine(m.var2);
            Console.WriteLine(m.var3);
            Console.WriteLine(m.var5);
           
            ModificadoresHerencia mh = new ModificadoresHerencia();
            Console.WriteLine(mh.var2);
            Console.WriteLine(mh.var3);
            Console.WriteLine(mh.var5);

            Console.ReadKey();
        }
    }
}
