﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArgumentosPorReferencia
{
    public class Referencias
    {
        private void PruebaRef(ref int uno, int dos)
        {
            // Esta asignación afectará al parámetro
            uno = uno + dos;
            // Esta no afectará al valor usado como segundo argumento
            dos = 999;
        }

        public  void ProbandoRef()
        {
            int uno = 5;
            int dos = 2;
            Console.WriteLine("uno= {0}, dos = {1}", uno, dos);
            PruebaRef(ref uno, dos);
            Console.WriteLine("uno= {0}, dos = {1}", uno, dos);
        }
    }
}
