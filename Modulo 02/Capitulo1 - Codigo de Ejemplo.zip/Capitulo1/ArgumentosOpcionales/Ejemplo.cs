﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArgumentosOpcionales
{
    public class Ejemplo
    {
        private string _nombre;

        // Dado que el parámetro para el constructor, 
        // nombre, tiene un valor predeterminado  
        // asignado al mismo, por eso es opcional.  
        public Ejemplo(string nombre = "Nombre por defecto")
        {
            _nombre = nombre;
        }

        // El primer parámetro, requerido, es obligatorio ponerlo. 
        // Por eso no tiene ningún valor predeterminado asignado  
        // al mismo. Por lo tanto, no es opcional. Tanto cadenaOpcional 
        // como enteroOpcional tienen valores por defecto asignados a ellos, 
        // por lo cual son opcionales.  

        public void MetodoDeEjemplo(int requerido, 
            string cadenaOpcional = "cadena por defecto",
            int enteroOpcional = 10)
        {
            Console.WriteLine("{0}: {1}, {2}, and {3}.", _nombre, requerido, cadenaOpcional,
                enteroOpcional);
        }
    }
}

