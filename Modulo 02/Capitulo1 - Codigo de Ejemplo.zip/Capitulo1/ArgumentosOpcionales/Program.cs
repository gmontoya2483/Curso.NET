﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ArgumentosOpcionales
{
    class Program
    {
        static void Main(string[] args)
        {
            // La instancia e1 no envía un argumento al constructor 
            // con parámetro opcional
            Ejemplo e1 = new Ejemplo();
            e1.MetodoDeEjemplo(1, "Uno", 1);
            e1.MetodoDeEjemplo(2, "Dos");
            e1.MetodoDeEjemplo(3);

            // La instancia e2 envía un argumento al constructor
            // con parámetro opcional
            Ejemplo e2 = new Ejemplo("Nombre enviado");
            e2.MetodoDeEjemplo(1, "Uno", 1);
            e2.MetodoDeEjemplo(2, "Dos");
            e2.MetodoDeEjemplo(3);

            // Las siguientes declaraciones producen errores de compilación.  

            // Un argumento debe ser suministrado para el primer parámetro,   
            // y debe ser un entero.
            //e1.MetodoDeEjemplo("Uno", 1);
            //e1.MetodoDeEjemplo(); 

            // No se puede dejar un vacío en los argumentos proporcionados.
            //e1.MetodoDeEjemplo(3, ,4); 
            //e1.MetodoDeEjemplo(3, 4); 

            // Se puede utilizar un parámetro nombrado para hacer
            // funcionar la sentencia anterior
            e1.MetodoDeEjemplo(3, enteroOpcional: 4);
            Console.ReadKey();
        }
    }
}
