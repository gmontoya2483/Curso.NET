﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Enumeracion
{
    public enum PuntoCardinal
    {
        Norte,
        Sur,
        Este,
        Oeste
    }

    class Program
    {
        static void Main(string[] args)
        {
            PuntoCardinal d = new PuntoCardinal();
            d = PuntoCardinal.Norte;

            // En C# d se comporta como una variable para Console.WriteLine
            Console.WriteLine(d);
            Console.WriteLine("{0}", d);
            int x = (int)PuntoCardinal.Norte;
            Console.WriteLine("{0}", x);
            Console.ReadLine();
        }
    }
}
