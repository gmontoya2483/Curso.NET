﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AsignacionesDeVariables
{
    class Program
    {
        static void Main(string[] args)
        {
            // declaración de variables enteras
		int x, y;

		// declaración y asignación de variables de punto flotante
		float z = 3.414f;
        Console.WriteLine(z);

		// declaración y asignación de double
		double w = 3.1415;
        Console.WriteLine(w);

		// declaración y asignación de boolean
		bool verdadero = true;
        Console.WriteLine(verdadero);

		// declaración de variable de caracter
		char c;

		// declaración de variable String
		String str;

		// declaración y asignación de String
		String str1 = "chau";
        Console.WriteLine(str1);

		// asignación de valores a un char
		c = 'A';
        Console.WriteLine(c);

		// asignación de valores a un String
		str = "Hola!";
        Console.WriteLine(str);

		// asignación de valores a int
		x = 6003334;
		y = 1000;
        Console.WriteLine(x);
        Console.WriteLine(y);
        Console.ReadKey();
        }
    }
}
