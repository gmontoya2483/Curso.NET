﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace referenciados
{
    class Desarrollador : Empleado
    {
        public Desarrollador(string n, DateTime f, decimal s): base(n, f, s)
        {
        }

        public override void Promover()
        {
            Console.WriteLine("El empleado Desarrollador {0} ha sido promovido", Nombre);
        }
    }
}
