﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace referenciados
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime d = new DateTime(2012, 8, 21);
            Empleado e1 = new Administrativo("Juan Perez", d, 5000);
            Empleado e2 = new Desarrollador("Pedro Sanchez", d, 5000);

            e1.Promover();
            e2.Promover();
            Console.ReadLine();
        }
    }
}
