﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace referenciados
{
    class Administrativo: Empleado
    {
        public Administrativo(string n, DateTime f, decimal s): base(n, f, s)
        {
        }

        public override void Promover()
        {
            Console.WriteLine("El empleado Administrativo {0} ha sido promovido", Nombre);
        }
    }
}
