﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace referenciados
{
    public abstract class Empleado
    {
        // Estado.
        private string _nombre;
        private DateTime _fechaDeIngreso;
        private decimal _salario;
        // Constructores.
        public Empleado() { }
        public Empleado(string n, DateTime f, decimal s) { 
         _nombre = n;
        _fechaDeIngreso = f;
        _salario = s;
       
        }
        // Propiedades.
        public string Nombre
        {
            get
            {
                return _nombre;
            }
            set
            {
                _nombre = value;
            }
        }
        public DateTime FechaDeIngreso
        {
            get
            {
                return _fechaDeIngreso;
            }
            set
            {
                _fechaDeIngreso = value;
            }
        }
        public decimal Salario
        {
            get
            {
                return _salario;
            }
            set
            {
                _salario = value;
            }
        }
        // Métodos.
        public abstract void Promover();
        public virtual decimal CalcularBono() { return 0.0M; }
    }
}
