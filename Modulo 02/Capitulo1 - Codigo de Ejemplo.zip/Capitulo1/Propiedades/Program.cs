﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Propiedades
{
    class Program
    {
        static void Main(string[] args)
        {
            Entero ejemplo = new Entero();
            // Asignar a la propiedad.
            ejemplo.Numero = 5;
            // Obtener de la propiedad.
            int unNumero = ejemplo.Numero;
        }
    }
}
