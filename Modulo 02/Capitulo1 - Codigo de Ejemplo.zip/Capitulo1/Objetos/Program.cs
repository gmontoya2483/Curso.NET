﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Objetos
{
    class Program
    {
        static void Main(string[] args)
        {
            Horario h = new Horario(2, 8, 45, 12, 45, 3);
            h.imprimir();
            Console.WriteLine("--------------");
            Horario nuevoHorario = h.agregar(3);
            nuevoHorario.imprimir();
            Console.ReadKey();
        }
    }
}
