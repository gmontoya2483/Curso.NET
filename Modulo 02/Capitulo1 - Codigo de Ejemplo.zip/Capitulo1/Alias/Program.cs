﻿// Utilizado como directiva.
using System;
// Utilizado como alias para una clase.
using AliasAClase1EnEspacio1 = espacio1.Clase1;
using AliasAClase1EnEspacio2 = espacio2.Clase1;   

namespace Alias
{
    // Utilizado como directiva:
    using espacio1;
    // Utilizado como directiva:
    using espacio2;

    class MainClass
    {
        static void Main()
        {
            AliasAClase1EnEspacio1 obj = new AliasAClase1EnEspacio1();
            AliasAClase1EnEspacio2 obj2 = new AliasAClase1EnEspacio2();
            Console.WriteLine(obj.RetornaString());
            Console.WriteLine(obj2.RetornaString());
            Console.ReadKey();
        }
    }
}
