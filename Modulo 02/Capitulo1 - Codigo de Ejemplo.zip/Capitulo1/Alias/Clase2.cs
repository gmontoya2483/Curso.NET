﻿namespace espacio2
{
    class Clase1
    {
        public string RetornaString()
        {
            return "Lamado a espacio2.Clase1";
        }
    }
}
