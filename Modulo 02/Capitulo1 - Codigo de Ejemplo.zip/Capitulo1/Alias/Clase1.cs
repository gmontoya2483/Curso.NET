﻿namespace espacio1
{
    class Clase1
    {
        public string RetornaString()
        {
            return "Lamado a espacio1.Clase1";
        }
    }
}
