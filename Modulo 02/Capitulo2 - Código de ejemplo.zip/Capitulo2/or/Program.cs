﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace or
{
    class or
    {
        static void Main(string[] args)
        {
            or obj = new or();
            int a = 10, b = 8, c = 6;
            bool verificacion;

            verificacion = a > b && b > c;  // True. La segunda expresión no se evalúa nunca
            verificacion = b > a && b > c;  // False. La segunda expresión se evalúa.
            verificacion = a > b && c > b;  // False. 

            if (obj.MiFuncion(5) == true || obj.MiOtraFuncion(4) == true)
            {
                // Si MiFuncion(5) es True, MiOtraFuncion(4) no se llama.
                // Código que se va a ejecutar.
                System.Console.WriteLine("Ejecuta");
                System.Console.ReadKey();
            }
        }

        public bool MiFuncion(int var)
        {
            int var2 = 3;
            System.Console.WriteLine("Estoy en MiFuncion");

            if (var > var2) return true;
            return false;
        }

        public bool MiOtraFuncion(int var)
        {
            int var2 = 3;
            System.Console.WriteLine("Estoy en MiOtraFuncion");

            if (var > var2) return true;
            return false;
        }
    }
}
