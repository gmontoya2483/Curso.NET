﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class OperadoresBinarios
    {
        public void Resultados()
        {
		int a = 4, b = 5, c = 6, d = 0;
		d = a + b * c;
		Console.WriteLine("Valor de d: " + d);
		Console.WriteLine("-----------");
		d += a;
		Console.WriteLine("Valor de d: " + d);
		Console.WriteLine("-----------");
		d -= b * c;
		Console.WriteLine("Valor de d: " + d);
		Console.WriteLine("-----------");
		d = c;
		Console.WriteLine("Valor de d: " + d);
		Console.WriteLine("-----------");
		d <<= c;
		Console.WriteLine("Valor de d: " + d);
		Console.WriteLine("Valor de c: " + c);
		Console.WriteLine("-----------");
		d >>= c++;	
		Console.WriteLine("Valor de d: " + d);
		Console.WriteLine("Valor de c: " + c);
        }
    }
}
