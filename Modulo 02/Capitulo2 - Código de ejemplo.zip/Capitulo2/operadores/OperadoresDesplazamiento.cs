﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class OperadoresDesplazamiento
    {
        public void Resultados()
        {
            int d = 2423;
            int resultado = d;

            Console.WriteLine("Decimal:" + resultado + "\t\tResultado: " + Convert.ToString(resultado, 2));
            resultado = -d;
            Console.WriteLine("Decimal:" + resultado + "\t\tResultado: " + Convert.ToString(resultado, 2));
            resultado = d >> 6;
            Console.WriteLine("Decimal:" + resultado + "\t\tResultado: " + Convert.ToString(resultado, 2));
            resultado = -d >> 6;
            Console.WriteLine("Decimal:" + resultado + "\t\tResultado: " + Convert.ToString(resultado, 2));
            resultado = d << 6;
            Console.WriteLine("Decimal:" + resultado + "\t\tResultado: " + Convert.ToString(resultado, 2));
            resultado = -d << 6;
            Console.WriteLine("Decimal:" + resultado + "\t\tResultado: " + Convert.ToString(resultado, 2));
        }
    }
}
