﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class OperadorBitY
    {
        public void Resultados()
        {
            int a = 12, b = 13, c = 0;

            c = b & a;
            Console.WriteLine("a:" + Convert.ToString(a, 2));
            Console.WriteLine("b:" + Convert.ToString(b, 2));
            Console.WriteLine("c = " + Convert.ToString(c, 2));
            Console.WriteLine("c = " + c);
        }
    }
}
