﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class OperadoresUnarios
    {
        public void Resultados()
        {
		int a = 4, b = 5, c = 6, d = 0;
		d = ++a - b-- - c; // d = 5 - 5 - 6
		Console.WriteLine("Valor de d: " + d);
        Console.WriteLine("Valor de a: " + a);
        Console.WriteLine("Valor de b: " + b);
        Console.WriteLine("-----------");
        a = 4; b = 5; c = 6; d = 0;
		d = a++ - b-- - c; // d = 4 - 5 - 6
        Console.WriteLine("Valor de d: " + d);
        Console.WriteLine("Valor de a: " + a);
        Console.WriteLine("Valor de b: " + b);
        }
    }
}
