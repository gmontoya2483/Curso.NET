﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class OperadorTernario
    {
        public void Resultados()
        {
            		int a = 4, b = 5, c = 6, d = 0;
		d = a > b ? c : b;
		Console.WriteLine("Valor de d: " + d);
		d = a < b ? c : b;
		Console.WriteLine("Valor de d: " + d);
		d = a < b ? c : ++b;
		Console.WriteLine("Valor de b: " + b);
		Console.WriteLine("Valor de d: " + d);
		d = a < b ? c : b--;
		Console.WriteLine("Valor de d: " + d);
		Console.WriteLine("Valor de b: " + b);

        }
    }
}
