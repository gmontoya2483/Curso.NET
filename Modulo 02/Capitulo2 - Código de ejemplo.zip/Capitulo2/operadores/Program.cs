﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operadores
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("----- Operadores Unarios -----");
            OperadoresUnarios ou = new OperadoresUnarios();
            ou.Resultados();

            Console.WriteLine("----- Operadores Binarios -----");
            OperadoresBinarios ob = new OperadoresBinarios();
            ob.Resultados();

            Console.WriteLine("----- Operadores Binarios -----");
            OperadoresDesplazamiento od = new OperadoresDesplazamiento();
            od.Resultados();

            Console.WriteLine("----- Operador Ternario -----");
            OperadorTernario ot = new OperadorTernario();
            ot.Resultados();

            Console.WriteLine("----- Operador Binario AND -----");
            OperadorBitY oby = new OperadorBitY();
            oby.Resultados();

            Console.ReadKey();
        }
    }
}
