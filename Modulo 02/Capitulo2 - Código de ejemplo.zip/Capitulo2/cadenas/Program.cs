﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace cadenas
{
    class Program
    {
        static void Main(string[] args)
        {
            String titulo = "Dr.";
            String nombre = "Pedro" + " " + "Ramirez";
            String saludo = titulo + " " + nombre;

            Console.WriteLine(titulo);
            Console.WriteLine(nombre);
            Console.WriteLine(saludo);
            Console.ReadKey();
        }
    }
}
