﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            object o = i; // boxing
            int j = (int) o; // unboxing
            System.Console.WriteLine("El valor de i: {0}", i);
            System.Console.WriteLine("El valor de o: {0}", o);
            System.Console.WriteLine(3.ToString());
            System.Console.WriteLine(3);
            System.Console.ReadKey();
        }
    }
}
