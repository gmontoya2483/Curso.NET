﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace conversionesDeCadenas
{
    class Program
    {
        static void Main(string[] args)
        {
            byte b = Byte.Parse("30");
            short s = Int16.Parse("30000");
            int i = Int32.Parse("3000000");
            long l = Int64.Parse("300000000000000000");
            float f = Single.Parse("3.1416");
            double d = Double.Parse("3.14159265358979323846264338327950288");
            bool bl = Boolean.Parse("true");
            decimal dec = Decimal.Parse("3.14159265358979323846");
            char c = Char.Parse("a");

            Console.WriteLine(b);
            Console.WriteLine(s);
            Console.WriteLine(i);
            Console.WriteLine(l);
            Console.WriteLine(f);
            Console.WriteLine(d);
            Console.WriteLine(bl);
            Console.WriteLine(dec);
            Console.WriteLine(c);
            Console.ReadKey();
        }
    }
}
