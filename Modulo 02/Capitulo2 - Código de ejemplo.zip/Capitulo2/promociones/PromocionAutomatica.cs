﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace promociones
{
    class PromocionAutomatica
    {
        static void Main(string[] args)
        {
            long valorGrande = 6; // 6 es un tipo entero, esta bien
            //int valorPequeño = 99L; // 99L es un long, esta mal
            double z = 12.414F; // 12.414F es float, esta bien
            //float z1 = 12.414; // 12.414 es double, esta mal 
            float resultado = 4 + valorGrande + (float)z;

            Console.WriteLine("Resultado: " + resultado);
            Console.ReadKey();
        }
    }
}
