﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace visibilidades
{
    class Visibilidad
    {
        private int i = 1;

        public void primerMetodo()
        {
            int i = 4, j = 5;
            this.i = i + j;
            segundoMetodo(7);
        }

        public void segundoMetodo(int i)
        {
            int j = 8;
            this.i = i + j;
        }

        static void Main(string[] args)
        {
            Visibilidad visibilidad1 = new Visibilidad();
            Visibilidad visibilidad2 = new Visibilidad();
            visibilidad1.primerMetodo();
            visibilidad2.primerMetodo();
        }
    }
}
