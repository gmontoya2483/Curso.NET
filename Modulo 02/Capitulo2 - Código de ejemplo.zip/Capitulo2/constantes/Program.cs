﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constantes
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Avoga.AVOGADRO);

            // La siguiente línea genera un error
            // Avoga.AVOGADRO = 5;
            Console.ReadKey();
        }
    }
}
