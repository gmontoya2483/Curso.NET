﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace constantes
{
    class Avoga
    {
        public const double AVOGADRO = 6.023e23;
    }
}
