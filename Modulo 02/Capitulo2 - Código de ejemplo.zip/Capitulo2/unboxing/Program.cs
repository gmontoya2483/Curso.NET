﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear una colección.
            ArrayList fechas = new ArrayList();
            // Crear un objeto y agregarlo a la colección. 
            // En tiempo de ejecución se encajona (boxing) al objeto.
            DateTime fec = new DateTime(2008, 1, 1);
            fechas.Add(fec);
            // Recuperar un objeto de la colección y convertirlo a DateTime.
            // El CLR realiza el unboxing del objeto para obtener una copia del heap.
            DateTime copia1 = (DateTime)fechas[0];
            // Modificar copia1 y mostrarlo por pantalla. El resultado es 02/01/2008.
            copia1 = copia1.AddDays(1);
            Console.WriteLine("Fecha en copia1: {0}", copia1.ToShortDateString());
            // Recuperar un objeto nuevamente de la colección.
            // El CLR realiza el unboxing del objeto para obtener otra copia del heap.
            DateTime copia2 = (DateTime)fechas[0];
            // Modificar copia2 y mostrarlo por pantalla. El resultado es 01/01/2008.
            copia2 = copia2.AddMonths(1);
            Console.WriteLine("Fecha en copia2: {0}", copia2.ToShortDateString());
            Console.ReadKey();
        }
    }
}
