﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ambiguedad
{
    public class Ejemplo
    {
        private int atrib1;
        private char atrib2;
        
        public Ejemplo(int a) { atrib1 = a; }
        public Ejemplo(char b) { atrib2 = b; }
        public Ejemplo(char atrib2, int atrib1)
        {
            this.atrib1 = atrib1;
            this.atrib2 = atrib2;
        }

         public void metodo()
        {
            //[sentencias;]
            atrib2 = 'a';
        }
         public int Atrib1
         {
             get
             {
                 return atrib1;
             }
             set
             {
                 atrib1 = value;
             }
         }
         public char Atrib2
         {
             get
             {
                 return atrib2;
             }
             set
             {
                 atrib2 = value;
             }
         }
    }
}
