﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ambiguedad
{
    class Program
    {
        static void Main(string[] args)
        {
            Ejemplo e1 = new Ejemplo(20);
            Ejemplo e2 = new Ejemplo('z');
            Ejemplo e3 = new Ejemplo('x', 50);
        }
    }
}
