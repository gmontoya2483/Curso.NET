﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace and
{
    class OperadorAnd
    {
        static void Main(string[] args)
        {
            OperadorAnd op = new OperadorAnd();
            int a = 10, b = 8, c = 6;
            bool verificacion;
            double[] vecPesos = { 3.3999999999999999, 4.5, 8.8000000000000007, 9.9000000000000004, 1.1000000000000001, 1.2, 1.6000000000000001, 0.80000000000000004, 0.98999999999999999, 5.5, 6.7000000000000002 };
            int pos;

            verificacion = a > b && b > c;  // True.
            verificacion = b > a && b > c;  // False. La segunda expresión no se evalúa nunca.
            verificacion = a > b && c > b;  // False. La segunda expresión se evalúa.

            pos = op.EncontrarValor(vecPesos, 9.9000000000000004);
            Console.WriteLine(pos.ToString());
            Console.ReadKey();
        }

        public int EncontrarValor(double[] vector, double valorBuscado)
        {
            int i = 0;
            while (i <= vector.Length && vector[i] != valorBuscado)
            {
                i += 1;
            }
            return i;
        }
    }
}
