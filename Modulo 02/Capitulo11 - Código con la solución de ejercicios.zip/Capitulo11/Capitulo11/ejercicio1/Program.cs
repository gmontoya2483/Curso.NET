﻿using System;
using System.IO;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"C:\MiArchivo.txt";

            FileInfo fi = new FileInfo(path);
            if (fi.Exists == true)
            {
                fi.Delete();
            }

            string str1;
            int i = 0;
            using (StreamWriter sw = fi.CreateText())
            {
                str1 = Console.ReadLine();
                while (str1.Length > 0)
                {
                    try
                    {
                        sw.WriteLine(i++ + ": " + str1);
                        str1 = Console.ReadLine();
                    }
                    catch (IOException e)
                    {
                        Console.WriteLine("{0}", e.Message);
                    }
                }
            }

            using (StreamReader sr = fi.OpenText())
            {
                string s = "";
                while ((s = sr.ReadLine()) != null)
                {
                    Console.WriteLine(s);
                }
            }

            Console.ReadKey();
        }
    }
}
