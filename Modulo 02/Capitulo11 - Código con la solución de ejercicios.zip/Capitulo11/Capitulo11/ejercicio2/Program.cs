﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escribiendo ...");
            EscribirFamilias();
            Console.WriteLine("Leyendo ...");
            LeerFamilias();
            Console.ReadKey();
        }

        public static void EscribirFamilias()
        {
            Familia familia1 = new Familia();
            Familia familia2 = new Familia();
            Familia familia3 = new Familia();
            Persona ines_xxx = new Persona(null, "Ines", "Xxx");
            Persona pedroPolino = new Persona(null, "Pedro", "Folino");
            Persona juanPolino = new Persona(familia1, "Juan", "Folino");
            Persona susanaPolino = new Persona(familia1, "Susana", "Folino");
            Persona patriciaPolino = new Persona(familia1, "Patricia", "Folino");
            Persona claraPolino = new Persona(familia1, "Clara", "Folino");
            Persona vanesaFolino = new Persona(familia1, "Vanesa", "Folino");
            Persona elisaBrown = new Persona(null, "Elisa", "Brown");
            Persona ulisesDiaz = new Persona(null, "Ulises", "Diaz");
            Persona darioDiaz = new Persona(familia2, "Darío", "Diaz");
            Persona sandraDiaz = new Persona(familia3, "Sandra", "Diaz");
            Persona carlaDiaz = new Persona(familia3, "Carla", "Diaz");
            Persona carlosDiaz = new Persona(familia3, "Carlos", "Diaz");

            // inicializar relaciones
            familia1.Madre = ines_xxx;
            familia1.Padre = pedroPolino;
            familia2.Madre = elisaBrown;
            familia2.Padre = ulisesDiaz;
            familia3.Madre = patriciaPolino;
            familia3.Padre = darioDiaz;

            // consultas
            Console.WriteLine("Patricia Polino tiene " + patriciaPolino.NumeroDeHermanos + " hermanos.");
            Console.WriteLine("Carlos Diaz tiene " + carlosDiaz.NumeroDeHermanos + " hermanos.");


            /***
            **** Paso 5: declarar e inicializar la corriente de salida de objetos
            ***/
            using (FileStream fs = new FileStream(@"C:\familias.ser",
                        FileMode.OpenOrCreate, FileAccess.Write))
            {
                // Manejar las excepciones
                try
                {
                    /***
                   **** Paso 6: escribir las tres familias a la corriente de objetos.
                     *       efectuar un Flush en la corriente de salida para escribir
                     *       en ese momento los datos en disco.
                   ***/
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    binaryFormatter.Serialize(fs, familia1);
                    binaryFormatter.Serialize(fs, familia2);
                    binaryFormatter.Serialize(fs, familia3);
                    fs.Flush();                   
                }
                catch (IOException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        public static void LeerFamilias()
        {
            Familia familia1;
            Familia familia2;
            Familia familia3;
            Persona patriciaPolino;
            Persona carlosDiaz;

            /***
            **** Paso 7: declarar e inicializar la corriente de entrada de objetos
            ***/
            using (FileStream fs = new FileStream(@"C:\familias.ser",
            FileMode.Open, FileAccess.Read))
            {
                /***
                 **** Paso 8: leer las tres familias de la corriente de objetos
                 **** No olvidarse de cerrar las corrientes de alto nivel al terminar
                 ***/
                try
                {
                    BinaryFormatter binaryFormatter = new BinaryFormatter();
                    familia1 = binaryFormatter.Deserialize(fs) as Familia;
                    patriciaPolino = familia1.EncontrarHijo("Patricia");
                    familia2 = binaryFormatter.Deserialize(fs) as Familia;
                    familia3 = binaryFormatter.Deserialize(fs) as Familia;
                    carlosDiaz = familia3.EncontrarHijo("Carlos");
                    // consultas
                    Console.WriteLine("Patricia Polino tiene " + patriciaPolino.NumeroDeHermanos + " hermanos.");
                    Console.WriteLine("Carlos Diaz tiene " + carlosDiaz.NumeroDeHermanos + " hermanos.");
                }
                catch (IOException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}