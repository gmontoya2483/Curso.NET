﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace limitaciones
{
    class Z<T> where T : A
    {
        private T t;

        public void Agregar(T t)
        {
            this.t = t;
        }

        public T Obtener()
        {
            return t;
        }

        public void Inspeccionar<U>(U u) where U : A
        {
            Console.WriteLine("T: " + t.GetType().Name);
            Console.WriteLine("U: " + u.GetType().Name);
        }
    }
}
