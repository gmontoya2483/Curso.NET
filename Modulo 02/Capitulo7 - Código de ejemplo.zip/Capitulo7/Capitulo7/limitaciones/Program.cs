﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace limitaciones
{
    class Program
    {
        static void Main(string[] args)
        {
		Z<A> z1 = new Z<A>();
		Z<B> z2 = new Z<B>();
		Z<C> z3 = new Z<C>();
		Z<D> z4 = new Z<D>();
        //Z<Double> z5 = new Z<Double>(); // Error
		
		z1.Agregar(new A());
		z1.Inspeccionar(new A());
		z1.Inspeccionar(new B());
		z1.Inspeccionar(new C());
		z1.Inspeccionar(new D());
		
		// La siguiente línea da Error porque el parámetro
		// del tipo para z2 es B
		// z2.Agregar(new A());
		z2.Agregar(new B());
		z2.Inspeccionar(new A());
		z2.Inspeccionar(new B());
		z2.Inspeccionar(new C());
		z2.Inspeccionar(new D());

		z3.Agregar(new C());
		z3.Inspeccionar(new A());
		z3.Inspeccionar(new B());
		z3.Inspeccionar(new C());
		z3.Inspeccionar(new D());
		
		z4.Agregar(new D());
		z4.Inspeccionar(new A());
		z4.Inspeccionar(new B());
		z4.Inspeccionar(new C());
		z4.Inspeccionar(new D());

        Console.ReadKey();
        }
    }
}
