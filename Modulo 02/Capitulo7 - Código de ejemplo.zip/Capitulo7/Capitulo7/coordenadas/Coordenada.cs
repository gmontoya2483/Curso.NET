﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace coordenadas
{
    public class Coordenada<T>
    {
        private T x;
        private T y;
        private T z;

        public Coordenada(T x, T y, T z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public T X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }

        public T Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        public T Z
        {
            get
            {
                return z;
            }
            set
            {
                z = value;
            }
        }  
    }
}
