﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodos
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 1;
            int b = 2;

            Console.WriteLine(a + " " + b);
            Intercambiar<int>(ref a, ref b);
            Console.WriteLine(a + " " + b);
            Console.ReadKey();
        }
        public static void Intercambiar<T>(ref T a, ref T b)
        {
            T aux;
            aux = a;
            a = b;
            b = aux;
        }
    }
}
