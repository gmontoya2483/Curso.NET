﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace defecto
{
    // T es el tipo de datos almacenado en una 
    // instancia particular de ListaGenerica.
    public class ListaGenerica<T>
    {
        private class Nodo
        {
            // Cada nodo tiene una referencia 
            // al próximo nodo en la lista.
            public Nodo proximo;
            // Cada nodo almacena un valor tde tipo T
            public T dato;
        }

        // La lista se encuentra inicialmente vacía.
        private Nodo cabecera = null;

        // Agregar un nodo al comienzo de la lista
        // usando a t como el valor del dato
        public void AgregarNodo(T t)
        {
            Nodo nuevoNodo = new Nodo();
            nuevoNodo.proximo = cabecera;
            nuevoNodo.dato = t;
            cabecera = nuevoNodo;
        }

        // El siguiente método retorna el valor del dato
        // almacenado en el último nodo de la lista. Si la
        // lista esta vacía, se retorna el valor por defecto
        // para el tipo T especificado
        public T ObtenerUltimo()
        {
            // El valor de temp se retorna como el del método.
            // La siguiente declaración inicializa temp con el
            // valor por defecto apropiado para el tipo T. Si la
            // lista está vacía se retorna el valor por defecto.
            T temp = default(T);

            Nodo actual = cabecera;
            while (actual != null)
            {
                temp = actual.dato;
                actual = actual.proximo;
            }
            return temp;
        }
    }
}
