﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace defecto
{
    class Program
    {
        static void Main(string[] args)
        {
            // Verificar con una lista NO vacía de enteros
            ListaGenerica<int> lista1 = new ListaGenerica<int>();
            lista1.AgregarNodo(5);
            lista1.AgregarNodo(4);
            lista1.AgregarNodo(3);
            int valorEntero = lista1.ObtenerUltimo();
            // La siguiente línea de código imprime 5
            System.Console.WriteLine(valorEntero);

            //  Verificar con una lista vacía de enteros
            ListaGenerica<int> lista2 = new ListaGenerica<int>();
            valorEntero = lista2.ObtenerUltimo();
            // La siguiente línea imprime 0.
            System.Console.WriteLine(valorEntero);

            // Verificar con una lista NO vacía de strings.
            ListaGenerica<string> lista3 = new ListaGenerica<string>();
            lista3.AgregarNodo("cinco");
            lista3.AgregarNodo("cuatro");
            string valorCadena = lista3.ObtenerUltimo();
            // La siguiente línea de código imprime cinco.
            System.Console.WriteLine(valorCadena);

            // Verificar con una lista vacía de strings.
            ListaGenerica<string> lisat4 = new ListaGenerica<string>();
            valorCadena = lisat4.ObtenerUltimo();
            // La siguiente línea de código imprime una línea en blanco
            System.Console.WriteLine(valorCadena);
            Console.ReadKey();
        }
    }
}
