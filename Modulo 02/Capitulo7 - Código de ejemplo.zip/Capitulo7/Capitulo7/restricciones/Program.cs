﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace restricciones
{
    public class Program
    {
        static void Main(string[] args)
        {
            ListaDeEmpleados<Empleado> lista = new ListaDeEmpleados<Empleado>();
            Empleado e = new Empleado("Juan", "Perez");
            lista.AgregaEmpleado(e);
            e = new Empleado("Pedro", "García");
            lista.AgregaEmpleado(e);
            e = new Empleado("Marcelo", "Añez");
            lista.AgregaEmpleado(e);
            e = new Empleado("Alejo", "García");
            lista.AgregaEmpleado(e);
            e = new Empleado("Pedro", "García");
            lista.AgregaEmpleado(e);

            lista.Ordenar();

            for (int j = 0; j < 5; j++)
            {
                Console.WriteLine(lista.ObtieneEmpleado(j));
            }
            Console.ReadKey();
        }
    }
}
