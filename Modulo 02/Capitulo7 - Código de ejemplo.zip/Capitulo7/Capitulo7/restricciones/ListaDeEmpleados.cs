﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace restricciones
{
    class ListaDeEmpleados<T>
        where T : Empleado, IDisposable, IComparable, new()
    {
        private T[] vec = new T[5];
        private int indice = 0;

        public ListaDeEmpleados()
        {
        }

        public void AgregaEmpleado(T e)
        {
            if (indice < 5){
                vec[indice] = e;
                indice++;
            }
        }

        public T ObtieneEmpleado(int indice)
        {
            return vec[indice];
        }

        public void Ordenar()
        {
            Array.Sort<T>(vec);
        }
    }
}
