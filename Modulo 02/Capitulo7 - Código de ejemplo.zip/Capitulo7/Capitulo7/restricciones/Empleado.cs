﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace restricciones
{
    public class Empleado : IDisposable, IComparable
    {
        private string nombre;
        private string apellido;

        public Empleado()
        {
            this.nombre = "";
            this.apellido = "";
        }

        public Empleado(string nombre, string apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }

        public string Apellido
        {
            get
            {
                return apellido;
            }
            set
            {
                apellido = value;
            }
        }
        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }
        #region IDisposable Members

        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposedValue)
            {
                if (disposing)
                {
                    apellido = null;
                    nombre = null;
                }
            }
            this.disposedValue = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
        #region IComparable Members

        public int CompareTo(object obj)
        {
            Empleado e = null;
            if (obj == null) return 1;
            if (obj.GetType() == typeof(Empleado)) e = (Empleado)obj;
            int res1 = this.apellido.CompareTo(e.apellido);
            int res2 = this.nombre.CompareTo(e.nombre);
            if (res1 != 0) return res1;
            else if (res2 != 0) return res2;
            return 0;
        }

        #endregion
        public override string ToString()
        {
            return "[" + apellido + ", " + nombre + "]";
        }
    }
}
