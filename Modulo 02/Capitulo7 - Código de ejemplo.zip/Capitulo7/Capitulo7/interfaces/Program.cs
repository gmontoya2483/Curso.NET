﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            Z<F<B>> z1 = new Z<F<B>>();

            z1.Agregar(new F<B>(new B()));
            z1.Inspeccionar(new F<D<A>>(new D<A>()));

            Console.ReadKey();
        }
    }
}
