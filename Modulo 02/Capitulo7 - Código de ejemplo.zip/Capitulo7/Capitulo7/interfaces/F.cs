﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interfaces
{
    class F<H> : A, I
    {
        private H h;


        public F(H h)
        {
            this.h = h;
        }

        public void Met()
        {
            Console.WriteLine("H: " + h.GetType().Name +
                    ". Invocado polimórficamente");
        }
    }
}
