﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interfaces
{
    class D<H> : B, I
    {
        private H h = default(H);

        public void Met() {
		Console.WriteLine("H: " + h.GetType().Name +
				". Invocado polimórficamente");
	}
    }
}
