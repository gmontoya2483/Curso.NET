﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace comparaciones
{
    public class Dinero : IComparable<Dinero>
    {
        private int _pesos, _centavos;

        public Dinero(int pesos, int centavos)
        {
            _pesos = pesos;
            _centavos = centavos;
        }

        public int CompareTo(Dinero otroObj)
        {
            int esteValor = (this._pesos * 100) + this._centavos;
            int otroValor = (otroObj._pesos * 100) + otroObj._centavos;
            return esteValor.CompareTo(otroValor);
        }

        public override String ToString()
        {
            String res = "[pesos = " + _pesos + ", centavos = " + _centavos + "]";
            return res;
        }
    }
}
