﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace comparaciones
{
    class Program
    {
        static void Main(string[] args)
        {
            Dinero[] salarios = { new Dinero(100, 0),
                    new Dinero(57, 23),
                    new Dinero(250, 21) };
            Array.Sort(salarios);
            foreach (Dinero d in salarios)
                System.Console.WriteLine(d.ToString());
            System.Console.WriteLine("Comparando");
            Dinero aux = salarios[0];
            foreach (Dinero d in salarios)
            {
                if (aux.CompareTo(d) < 0) aux = d;
            }
            System.Console.WriteLine("El mayor es: " + aux.ToString());
            System.Console.ReadKey();
        }
    }
}
