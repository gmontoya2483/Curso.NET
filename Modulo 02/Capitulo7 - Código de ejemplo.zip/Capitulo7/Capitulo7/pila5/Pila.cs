﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pila5
{
    public class Pila
    {
        private Object[] vec = new Object[10];
        private int indice = 0;

        public void Agregar(Object valor)
        {
            if (indice == 9)
                throw new ExcepcionPila("Pila llena");
            vec[indice] = valor;
            indice++;
        }

        public Object Sacar()
        {
            if (indice == 0)
                throw new ExcepcionPila("Pila vacía");
            indice--;
            return vec[indice];
        }
    }
}
