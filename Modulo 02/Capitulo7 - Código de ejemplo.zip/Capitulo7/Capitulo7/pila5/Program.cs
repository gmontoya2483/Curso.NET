﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pila5
{
    class Program
    {
        static void Main(string[] args)
        {
            Pila p = new Pila();

            try
            {
                // p.agregar("Hola");
                p.Agregar(8); // Autoboxing
                p.Agregar(8.8); // Autoboxing
                p.Agregar(9);	// Autoboxing		

                double total = //(Double)p.sacar() +
                 Double.Parse(p.Sacar().ToString()) +
                 Double.Parse(p.Sacar().ToString()) +
                 Double.Parse(p.Sacar().ToString());
                Console.WriteLine(total);
                Console.ReadKey();
            }
            catch (ExcepcionPila e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.ReadKey();
            }
        }
    }
}
