﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pila
{
    class Program
    {
        static void Main(string[] args)
        {
            Pila p = new Pila();

            try
            {
                //p.agregar("Hola"); // Error, no es un int
                p.Agregar(8);
                //p.agregar(8.8); // Error, no es un int
                p.Agregar(9);
                p.Agregar(19);
                p.Agregar(29);

                double total = (double)p.Sacar() +
                        (double)p.Sacar() +
                        (double)p.Sacar() +
                        (double)p.Sacar();
                Console.WriteLine(total);
                Console.ReadKey();
            }
            catch (ExcepcionPila e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.ReadKey();
            }
        }
    }
}
