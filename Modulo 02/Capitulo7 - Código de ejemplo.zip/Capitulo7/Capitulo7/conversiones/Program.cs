﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace conversiones
{
    class Program
    {
        static void Main(string[] args)
        {
            Dinero dinero1 = new Dinero(10, 50);

            try
            {
                double d = Convert.ToDouble(dinero1); // Convierte el dinero a double.
                string s = Convert.ToString(dinero1); // Convierte el dinero a String.
                sbyte sb1 = Convert.ToSByte(dinero1); // Convierte el dinero a sbyte.
                float f = Convert.ToSingle(dinero1); // Convierte el dinero a float.
                int i = Convert.ToInt32(dinero1); // Convierte el dinero a int.

                System.Console.WriteLine("Dinero: {0}", d);
                System.Console.WriteLine("Dinero: {0}", s);
                System.Console.WriteLine("Dinero: {0}", sb1);
                System.Console.WriteLine("Dinero: {0}", f);
                System.Console.WriteLine("Dinero: {0}", i);

                DateTime dt = Convert.ToDateTime(dinero1); // Causa una excepción.
            }
            catch (InvalidCastException e)
            {
                System.Console.WriteLine("Error: {0} \nPresione una tecla ...", e.Message);
                System.Console.ReadKey();
                System.Console.WriteLine("");
            }
            finally
            {
                try
                {
                    Dinero dinero2 = new Dinero(127, 50);
                    sbyte sb2 = Convert.ToSByte(dinero2); // Convierte el dinero a sbyte.
                    System.Console.WriteLine("Dinero: {0}", sb2);
                    System.Console.ReadKey();
                }
                catch (InvalidCastException e)
                {
                    System.Console.WriteLine("Programa Terminado. Error: {0} \nPresione una tecla ...", e.Message);
                    System.Console.ReadKey();
                }
            }
        }
    }
}
