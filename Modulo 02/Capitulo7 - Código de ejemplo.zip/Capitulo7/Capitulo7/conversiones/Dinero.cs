﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace conversiones
{
    public class Dinero : IConvertible
    {
        private int _pesos, _centavos;

        public Dinero(int pesos, int centavos)
        {
            _pesos = pesos;
            _centavos = centavos;
        }

        public override String ToString()
        {
            String res = "[pesos = " + _pesos + ", centavos = " + _centavos + "]";
            return res;
        }

        // Indica que el TypeCode (tipo de un objeto) para Dinero es TypeCode.Object.
        public TypeCode GetTypeCode()
        {
            return TypeCode.Object;
        }
        // Propiedad de ayuda utilizada por los métodos de conversión.
        private double Valor
        {
            get { return _pesos + (_centavos / 100.0); }
        }
        // Propiedad de ayuda utilizada por los métodos de conversión.
        private double Redondeo
        {
            get {
                int p = _pesos;
                if (_centavos >= 50) p++;
                return p; 
            }
        }

        public bool ToBoolean(IFormatProvider proveedorFormato)
        {
            if (_pesos != 0 || _centavos != 0)
                return true;
            else
                return false;
        }

        // La mayoría de los métodos de conversión son variaciones de este.
        public byte ToByte(IFormatProvider proveedorFormato)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToByte(Valor);
        }

        // No tiene significado esta conversión, entonces lanza la excepción.
        public DateTime ToDateTime(IFormatProvider proveedorFormato)
        {
            throw new InvalidCastException("Conversión inválida. No se puede tranformar en DateTime");
        }
        // Retorna una cadena especifica de la localidad formateada como moneda en curso.
        public string ToString(IFormatProvider proveedorFormato)
        {
            return String.Format(proveedorFormato, "{0:c}", Valor);
        }
        // Convierte un objeto del tipo Dinero a un tipo específico.
        public object ToType(Type tipoDeConversion, IFormatProvider proveedorFormato)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ChangeType(Valor, tipoDeConversion);
        }

        public sbyte ToSByte(IFormatProvider proveedorFormato)
        {
            if (!(Valor <= 127.0))
            {
                throw new InvalidCastException("Conversión inválida. Valor muy grande");
            }

            return Convert.ToSByte(Redondeo);
        }

        public char ToChar(IFormatProvider proveedorFormato)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToChar(Redondeo);
        }

        public decimal ToDecimal(IFormatProvider proveedorFormato)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToDecimal(Valor);
        }
        public float ToSingle(IFormatProvider proveedorFormato)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToSingle(Valor);
        }

        public double ToDouble(IFormatProvider proveedorFormato)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToDouble(Valor);
        }

        public short ToInt16(IFormatProvider proveedor)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToInt16(Redondeo);
        }

        public ushort ToUInt16(IFormatProvider proveedor)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToUInt16(Redondeo);
        }

        public int ToInt32(IFormatProvider proveedor)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToInt32(Redondeo);
        }

        public uint ToUInt32(IFormatProvider proveedor)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToUInt32(Redondeo);
        }

        public long ToInt64(IFormatProvider proveedor)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToInt64(Redondeo);
        }

        public ulong ToUInt64(IFormatProvider proveedor)
        {
            // Convert convierte un tipo de datos base a otro
            return Convert.ToUInt64(Redondeo);
        }
    }
}
