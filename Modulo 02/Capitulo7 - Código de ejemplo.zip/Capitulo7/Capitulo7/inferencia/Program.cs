﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace inferencia
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear un vector de strings (cadenas).
            string[] amigos = { "Juan", "Sebastián", "Adrián" };
            int[] vec = { 1, 2, 3, 4 };
            // Invocar al método genérico y especificar implícitamente 
            // el tipo del parámetro (inferencia)
            MetodoGenerico.MostrarVector(amigos);
            MetodoGenerico.MostrarVector(vec);
            // Invocar al método genérico y especificar explícitamente 
            // el tipo del parámetro
            MetodoGenerico.MostrarVector<string>(amigos);
            MetodoGenerico.MostrarVector<int>(vec);
            System.Console.ReadKey();
        }
    }
}
