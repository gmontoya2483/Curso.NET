﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace inferencia
{
    class MetodoGenerico
    {
        public static void MostrarVector<T>(T[] vector)
        {
            foreach (T item in vector)
            {
                Console.WriteLine("{0}", item);
            }
        }
    }
}
