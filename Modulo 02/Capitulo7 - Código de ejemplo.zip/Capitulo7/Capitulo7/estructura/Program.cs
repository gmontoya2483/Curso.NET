﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace estructura
{
    public struct Coordenada<T>
    {
        private T x;
        private T y;
        private T z;

        public Coordenada(T x, T y, T z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }
        public T X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }
        public T Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }
        public T Z
        {
            get
            {
                return z;
            }
            set
            {
                z = value;
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Coordenada<Int32> c = new Coordenada<Int32>(2, 3, 4);
            Coordenada<long> c2 = new Coordenada<long>(2, 3, 4);
            Console.WriteLine("X: " + c.X + ", y: "
                    + c.Y + ", Z: " + c.Z);
            int suma1 = c.X + c.Y + c.Z;
            long suma2 = c2.X + c2.Y + c2.Z;
            Console.WriteLine("La suma 1 de las coordenadas es: " + suma1);
            Console.WriteLine("La suma 2 de las coordenadas es: " + suma2);
            Console.ReadKey();
        }
    }
}
