﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace igualdades
{
    public class Producto : IEquatable<Producto>
    {
        private int _id;
        private string _nombre;
        private double _precio;

        public Producto(int id, string nombre, double precio)
        {
            _id = id;
            _nombre = nombre;
            _precio = precio;
        }

        public bool Equals(Producto otroObj)
        {
            return (this._id == otroObj._id) &&
            (this._nombre == otroObj._nombre) &&
            (this._precio == otroObj._precio);
        }
    }
}
