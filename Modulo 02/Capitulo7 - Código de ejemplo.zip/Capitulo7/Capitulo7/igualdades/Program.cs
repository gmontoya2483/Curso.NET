﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace igualdades
{
    class Program
    {
        static void Main(string[] args)
        {
            Producto p1 = new Producto(1, "Chai", 18.00);
            Producto p2 = new Producto(1, "Chai", 18.00);
            if (p1.Equals(p2))
                Console.WriteLine("Los objetos son iguales.");
            else
                Console.WriteLine("Los objetos son diferentes.");
            System.Console.ReadKey();
        }
    }
}
