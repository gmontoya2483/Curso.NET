﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace invariancia
{
    class Z<T>
    {
        private T t;

        public void Agregar(T t)
        {
            this.t = t;
        }

        public T Obtener()
        {
            return t;
        }

        public void Inspeccionar<U>(U u) 
        {
            Console.WriteLine("T: " + t.GetType().Name);
            Console.WriteLine("U: " + u.GetType().Name);
        }
    }
}
