﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace invariancia
{
    class Program
    {
        static void Main(string[] args)
        {
            Z<A> z1 = new Z<A>();
            Z<B> z2 = new Z<B>();
            Z<C> z3 = new Z<C>();

            //z1 = z2; // ERROR
            //z2 = z3; // ERROR
            Console.WriteLine("Todas las declaraciones son correctas");
            Console.ReadKey();
        }
    }
}
