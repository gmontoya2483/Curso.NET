﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace delegados
{
    delegate void ElDelegado<T>(T s);

    class Program
    {
        public static void Hola<U>(U s)
        {
            Console.WriteLine("  Hola, {0}!", s);
        }

        public static void Adios<U>(U s)
        {
            Console.WriteLine("  Adiós, {0}!", s);
        }

        public static void Main()
        {
            ElDelegado<string> a, b, c, d;

            // Crear el objeto a del tipo delegate que referencia 
            // al método Hola:
            a = new ElDelegado<string>(Hola<string>);
            // Crear el objeto b del tipo delegate que referencia  
            // al método Adios:
            b = new ElDelegado<string>(Adios<string>);
            // Los dos delegates, a y b, se componen para formar c, 
            // el cual llama a ambos métodos en orden:
            c = a + b;
            // Remover a del delegate compuesto, dejando sólo b
            // en d, el cual llama al método Adios
            d = c - a;

            Console.WriteLine("Invocando al delegado a:");
            a("A");
            Console.WriteLine("Invocando al delegado b:");
            b("B");
            Console.WriteLine("Invocando al delegado c:");
            c("C");
            Console.WriteLine("Invocando al delegado d:");
            d("D");

            System.Console.ReadKey();
        }
    }
}
