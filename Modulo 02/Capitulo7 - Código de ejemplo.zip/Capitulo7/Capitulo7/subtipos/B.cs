﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subtipos
{
    public class B<T> : A<T>
    {
    }
}
