﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subtipos
{
    public class A<T>
    {
        private T t;

        public void Agregar(T t)
        {
            this.t = t;
        }

        public T Obtener()
        {
            return t;
        }

        public void UnMetodo(A<Object> a)
        {
            // Hace algo
        }
    }
}
