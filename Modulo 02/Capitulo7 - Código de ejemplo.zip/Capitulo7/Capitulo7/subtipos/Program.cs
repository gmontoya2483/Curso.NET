﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace subtipos
{
    class Program
    {
        static void Main(string[] args)
        {
            Object objeto = new Object();
            Int32 entero = new Int32();
            objeto = entero; // Bien
            
            A<Object> a = new A<Object>();
            a.Agregar(new Int32()); // Bien
            a.Agregar(new Double()); // Bien

            A<Double> a2 = new A<Double>();
            // a.unMetodo(a2); //Error
            B<Double> b1 = new B<Double>();
            // a2.unMetodo(b1); //Error
            B<Object> b2 = new B<Object>();
            a2.UnMetodo(b2); //Correcto      
        }

        public static void UnMetodo(Object n)
        {
            // se omite el cuerpo
        }

        public static void OtroMetodo(Object n)
        {
            UnMetodo(new Int32()); // Bien
            UnMetodo(new Double()); // Bien
        }
    }
}
