﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace clonacion
{
    class DetallesPersonales : ICloneable
    {
        private string _nombre;
        private List<string> _numerosContactos;
        public DetallesPersonales(string n)
        {
            _nombre = n;
            _numerosContactos = new List<string>();
        }
        public void AgregarNumeroContacto(string numero)
        {
            _numerosContactos.Add(numero);
        }
        public object Clone()
        {
            DetallesPersonales objectoClonado = new DetallesPersonales(_nombre);
            foreach (string num in _numerosContactos)
            {
                objectoClonado._numerosContactos.Add(num);
            }
            return objectoClonado;
        }
        public List<string> NumerosContactos
        {
            get
            {
                return _numerosContactos;
            }
        }
    }
}
