﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace clonacion
{
    class Program
    {
        static void Main(string[] args)
        {
            DetallesPersonales detallesOriginales = new DetallesPersonales("Ruby");
            detallesOriginales.AgregarNumeroContacto("Número1");
            detallesOriginales.AgregarNumeroContacto("Número2");
            DetallesPersonales detallesClonados =
                (DetallesPersonales)detallesOriginales.Clone();
            // Agregar un contacto al objeto original.
            detallesOriginales.AgregarNumeroContacto("Número3");
            // Agregar un contacto al objeto clonado.
            detallesClonados.AgregarNumeroContacto("Número4");
            List<string> lista1 = detallesOriginales.NumerosContactos;
            List<string> lista2 = detallesClonados.NumerosContactos;

            Console.WriteLine("Imprimiendo lista original");
            foreach (string s in lista1)
            {
                Console.WriteLine(s);
            }

            Console.WriteLine("Imprimiendo lista clonada");
            foreach (string s in lista2)
            {
                Console.WriteLine(s);
            }

            Console.ReadKey();
        }
    }
}
