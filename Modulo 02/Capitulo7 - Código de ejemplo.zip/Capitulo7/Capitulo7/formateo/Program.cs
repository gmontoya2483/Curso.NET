﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace formateo
{
    public struct Punto : IFormattable
    {
        private int _x, _y;

        public Punto(int x, int y)
        {
            _x = x;
            _y = y;
        }

        // Sobrescribe el método ToString de la clase System.Object.
        public override string ToString()
        {
            return ToString(null, null);
        }
        // Implementa el método ToString de la interfaz IFormattable.
        public String ToString(string formato, IFormatProvider fp)
        {
            try
            {
                if (formato == null)
                    return String.Format("({0}, {1})", _x, _y);
                else if (formato == "x")
                    return _x.ToString();
                else if (formato == "y")
                    return _y.ToString();
                else
                    throw new FormatException(
                    String.Format("Formato inválido de string: '{0}'.", formato));

            }
            catch (FormatException fe)
            {
                Console.WriteLine("Error: " + fe.Message);
            }
            return "Error en " + formato + " para " + fp.ToString();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Punto p = new Punto(10, 20);
            Console.WriteLine("Esto imprime la coordenada X: {0:x}", p);
            Console.WriteLine("Esto imprime la coordenada Y: {0:y}", p);
            Console.WriteLine("Esto imprime las coordenadas del punto: {0}", p);
            Console.WriteLine("Esto causa una FormatException: {0:z}", p);

            Console.ReadKey();
        }
    }
}
