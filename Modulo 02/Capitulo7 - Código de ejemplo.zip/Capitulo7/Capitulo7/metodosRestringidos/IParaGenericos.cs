﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodosRestringidos
{
    public interface IParaGenericos<T>
    {
        T MiMetodo();
    }
}
