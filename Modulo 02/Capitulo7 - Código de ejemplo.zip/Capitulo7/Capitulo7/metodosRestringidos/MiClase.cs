﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodosRestringidos
{
    class MiClase<T>: IParaGenericos<T> where T: new()
    {
        private T t = default(T);
        private static int contador = 0;

        public MiClase()
        {
            contador++;
            Console.WriteLine("Creando la clase MiClase número " + contador);
            t = new T();
        }

        public T MiMetodo()
        {
            Console.WriteLine("T: " + t.GetType().Name);
            return t;
        }
    }
}
