﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace metodosRestringidos
{
    class Program
    {
        static void Main(string[] args)
        {
            MiClase<MiOtraClase<int>> mc = new MiClase<MiOtraClase<int>>();
            MetodoPolimorfico<MiOtraClase<int>>(mc);
            MiOtraClase<MiClase<int>> moc = new MiOtraClase<MiClase<int>>();
            MetodoPolimorfico<MiClase<int>>(moc);

            IParaGenericos<MiOtraClase<int>> ig = mc;
            mc.MiMetodo();
            Console.ReadKey();
        }

        public static void MetodoPolimorfico<T>(IParaGenericos<T> obj) where T: new()
        {
            T o = new T();
            obj.MiMetodo();
        }
    }
}
