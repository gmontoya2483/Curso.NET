﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace disponer
{
    public class ContenedorDelRecurso : IDisposable
    {
        private bool _dispuesto = false;
        public void Dispose()
        {
            // El parámetro True indica que
            // el objeto es eliminado a causa de una llamada explícita 
            // al método público Dispose en lugar que el CLR
            // invoque código de finalización en el objeto.
            Dispose(true);

            // quitar el objeto de la cola de finalización de CLR. 
            // Este método frena al recolector de basura para
            // que no llame al destructor de este objeto, 
            // porque el mismo ha sido finalizado.
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disponiendo)
        {
            if (!_dispuesto)
            {
                // Si se llamó desde este objeto (disponiendo=true), 
                // disponer los recursos manejados y los No manejados. 
                // Sino sólo los últimos porque lo llamó el GC por   
                // medio del método Finalize y ya eliminó los primeros.
                if (disponiendo)
                {
                    // Disponer los recursos manejados acá.
                }
                // Disponer los recursos No manejados acá (Por ejemplo,
                // si se intanció un objeto COM o ActiveX no codificado 
                // con .Net). Fijar el valor de la bandera _dispuesto 
                // en true para evitar futuras disposiciones
                _dispuesto = true;
            }
        }
        // Código de finalización.
        ~ContenedorDelRecurso()
        {
            Dispose(false);
        }
    }
}
