﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace disponer
{
    class Program
    {
        static void Main(string[] args)
        {
            ContenedorDelRecurso c = new ContenedorDelRecurso();
            // Disponer AHORA de este objeto
            c.Dispose();
            // Más código del programa
        }
    }
}
