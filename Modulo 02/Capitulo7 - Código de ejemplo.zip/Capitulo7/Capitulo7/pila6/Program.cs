﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pila6
{
    class Program
    {
        static void Main(string[] args)
        {
            Pila<double> p = new Pila<double>();

            try
            {
                p.Agregar(8); 
                p.Agregar(8.8); 
                p.Agregar(9);		

                double total = p.Sacar() + p.Sacar() + p.Sacar();
                Console.WriteLine(total);
                Console.ReadKey();
            }
            catch (ExcepcionPila e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.ReadKey();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
                Console.ReadKey();
            }
        }
    }
}
