﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pila6
{
    public class Pila<T>
    {
        private T[] vec = new T[10];
        private int indice = 0;

        public void Agregar(T valor)
        {
            if (indice == 9)
                throw new ExcepcionPila("Pila llena");
            vec[indice] = valor;
            indice++;
        }

        public T Sacar()
        {
            if (indice == 0)
                throw new ExcepcionPila("Pila vacía");
            indice--;
            return vec[indice];
        }
    }
}
