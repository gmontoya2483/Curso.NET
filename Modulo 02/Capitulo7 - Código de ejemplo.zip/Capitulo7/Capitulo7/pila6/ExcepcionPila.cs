﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pila6
{
    class ExcepcionPila: Exception
    {
        public ExcepcionPila(String arg0)
            : base(arg0)
        {
        }
    }
}
