﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace enumerables
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona[] vectorPersonas = new Persona[3]{
                        new Persona("Juan", "Perez"),
                        new Persona("Roxana", "Gonzalez"),
                        new Persona("Adriana", "Piaggi")
                    };

            Publico listaDelPublico = new Publico(vectorPersonas);
            foreach (Persona p in listaDelPublico)
                Console.WriteLine(p.Nombre + " " + p.Apellido);
            Console.ReadKey();
        }
    }
}
