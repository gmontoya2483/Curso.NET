﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace enumerables
{
    class Publico : IEnumerable
    {
        private static Persona[] personas;

        public Publico(Persona[] _personas)
        {
            personas = new Persona[_personas.Length];
            for (int i = 0; i < _personas.Length; i++)
            {
                personas[i] = _personas[i];
            }
        }

        public IEnumerator GetEnumerator()
        {
           return new EnumeradorPersonas();
        }

        private class EnumeradorPersonas : IEnumerator
        {
            private int indice = -1;

            public object Current
            {
                get
                {
                    try
                    {
                        if (personas[indice] == null) throw new InvalidOperationException("No hay elementos");
                        return personas[indice];
                    }
                    catch (IndexOutOfRangeException)
                    {
                        throw new InvalidOperationException("No hay más elementos almacenados");
                    }
                }
            }

            public bool MoveNext()
            {
                indice++;
                return (indice < personas.Length);
            }

            public void Reset()
            {
                indice = -1;
            }
        }
    }
}
