﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace estudiantes
{
    public class Alumno : IComparable
    {
        private string apellido;
        private string nombre;
        private string segundoNombre;
        private int edad;
        private int legajo;

        public Alumno(string nombre, string segundoNombre, string apellido, int edad, int legajo)
        {
            this.apellido = apellido;
            this.nombre = nombre;
            this.segundoNombre = segundoNombre;
            this.edad = edad;
            this.legajo = legajo;
        }

        public int CompareTo(object obj)
        {
            if (obj == null) return 1;
            Alumno elOtro = obj as Alumno;
            if (elOtro != null)
            {
                int aux = apellido.CompareTo(elOtro.apellido);
                if (aux != 0) return aux;
                aux = nombre.CompareTo(elOtro.nombre);
                if (aux != 0) return aux;
                aux = segundoNombre.CompareTo(elOtro.segundoNombre);
                if (aux != 0) return aux;
                return 0;
            }
            else
                throw new ArgumentException("El objeto no es un alumno");
        }

        // Rescribir GestHasCode de Object para las
        // colecciones que ordenan por este método
        public override int GetHashCode()
        {
            const int primo = 31;
            int resultado = 1;
            resultado = primo * resultado
                    + ((apellido == null) ? 0 : apellido.GetHashCode());
            resultado = primo * resultado + ((nombre == null) ? 0 : nombre.GetHashCode());
            resultado = primo * resultado + ((segundoNombre == null) ? 0 : segundoNombre.GetHashCode());

            return resultado;
        }

        // Rescribir el método Equals de Object
        // y cumplir con las relaciones de equivalencia
        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (GetType() != obj.GetType())
                return false;
            Alumno otro = (Alumno)obj;
            if (apellido == null)
            {
                if (otro.apellido != null)
                    return false;
            }
            else if (!apellido.Equals(otro.apellido))
                return false;
            if (nombre == null)
            {
                if (otro.nombre != null)
                    return false;
            }
            else if (!nombre.Equals(otro.nombre))
                return false;
            if (segundoNombre == null)
            {
                if (otro.segundoNombre != null)
                    return false;
            }
            else if (!segundoNombre.Equals(otro.nombre))
                return false;

            return true;
        }

        public override string ToString()
        {
            return "[" + apellido + ", " + nombre + " " + segundoNombre + "]";
        }

        public string Apellido
        {
            get
            {
                return apellido;
            }
            set
            {
                apellido = value;
            }
        }
        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                nombre = value;
            }
        }
        public string SegundoNombre
        {
            get
            {
                return segundoNombre;
            }
            set
            {
                segundoNombre = value;
            }
        }
        public int Edad
        {
            get
            {
                return edad;
            }
            set
            {
                edad = value;
            }
        }
        public int Legajo
        {
            get
            {
                return legajo;
            }
            set
            {
                legajo = value;
            }
        }
    }
}
