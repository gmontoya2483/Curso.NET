﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace covarianza
{
    class Enumerador : IEnumerable<A>, IEnumerator<A>
    {
        private A[] vec;
        private int indice = -1;

        public Enumerador(A[] _vec)
        {
            vec = new A[_vec.Length];
            for (int i = 0; i < _vec.Length; i++)
            {
                vec[i] = _vec[i];
            }
        }

        public IEnumerator<A> GetEnumerator()
        {
            return (IEnumerator<A>)this;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            throw new NotImplementedException();
        }


        public A Current
        {
            get
            {
                try
                {
                    if (vec[indice] == null) throw new InvalidOperationException("No hay elementos");
                    return vec[indice];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new InvalidOperationException("No hay más elementos almacenados");
                }
            }
        }

        public void Dispose()
        {

        }

        object System.Collections.IEnumerator.Current
        {
            get { throw new NotImplementedException(); }
        }

        public bool MoveNext()
        {
            indice++;
            return (indice < vec.Length);
        }

        public void Reset()
        {
            indice = -1;
        }
    }
}

