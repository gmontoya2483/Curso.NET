﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace covarianza
{
    class A
    {
        private int var1 = 10;

        public A(int var)
        {
            var1 = var;
        }

        public virtual void MiMetodo()
        {
            Console.WriteLine("Estoy en A.MiMetodo()");
        }
        public int Var1
        {
            get
            {
                return var1;
            }
            set
            {
                var1 = value;
            }
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (GetType() != obj.GetType())
                return false;
            A otro = (A)obj;
            if (var1 != otro.var1) return false;
            return true;
        }

        public override int GetHashCode()
        {
            return var1;
        }
    }
}
