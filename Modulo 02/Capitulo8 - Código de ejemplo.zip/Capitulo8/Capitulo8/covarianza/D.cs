﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace covarianza
{
    class D : B
    {
        public D(int v) : base(v) { }

        public override void MiMetodo()
        {
            Console.WriteLine("Estoy en D.MiMetodo()");
        }
    }
}
