﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace covarianza
{
    class Program
    {
        static void Main(string[] args)
        {
            A[] vecA = { new A(1), new A(2), new A(3) };
            B[] vecB = { new B(4), new B(5), new B(6) };
            C[] vecC = { new C(7), new C(8), new C(9) };
            D[] vecD = { new D(10), new D(11), new D(12) };

            // Todas estas instacias son correctas
            // porque IEnumerable e IEnumerator son
            // covariantes respecto de su parámetro
            Enumerador listaDeA = new Enumerador(vecA);
            Enumerador listaDeB = new Enumerador(vecB);
            Enumerador listaDeC = new Enumerador(vecC);
            Enumerador listaDeD = new Enumerador(vecD);

            // Usar los enumeradores definidos por covarianza
            foreach (A _a in listaDeA)
            {
                Console.Write("Estoy en ");
                _a.MiMetodo();
                Console.WriteLine("El valor de Var1 es:  " + _a.Var1);
            }
            foreach (B _b in listaDeB)
            {
                Console.Write("Estoy en ");
                _b.MiMetodo();
                Console.WriteLine("El valor de Var1 es:  " + _b.Var1);
            }
            foreach (C _c in listaDeC)
            {
                Console.Write("Estoy en ");
                _c.MiMetodo();
                Console.WriteLine("El valor de Var1 es:  " + _c.Var1);
            }
            foreach (D _d in listaDeD)
            {
                Console.Write("Estoy en ");
                _d.MiMetodo();
                Console.WriteLine("El valor de Var1 es:  " + _d.Var1);
            }

            Console.ReadKey();
        }
    }
}
