﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace bits
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear una BitArray vacío con una longitud especifica.
            // A continuación, establecer el valor de los bits.
            BitArray ba1 = new BitArray(3);
            ba1[0] = true;
            ba1[1] = false;
            ba1[2] = true;
            // Crear un BitArray e inicializar los bits de inmediato.
            BitArray ba2 = new BitArray(new bool[] { true, true, false });
            // Realizar operaciones bit a bit.
            ba1.And(ba2); // Genera ba1: true, false, false.
            Console.WriteLine("AND");
            // Iterar sobre los bits de un BitArray.
            foreach (bool bit in ba1)
            {
                Console.Write("{0} ", bit);
            }
            ba1.Or(ba2); // Genera ba1: true, true, false.
            Console.WriteLine();
            Console.WriteLine("OR");
            // Iterar sobre los bits de un BitArray.
            foreach (bool bit in ba1)
            {
                Console.Write("{0} ", bit);
            }
            ba1.Xor(ba2); // Genera ba1: false, false, false.
            Console.WriteLine();
            Console.WriteLine("XOR");
            // Iterar sobre los bits de un BitArray.
            foreach (bool bit in ba1)
            {
                Console.Write("{0} ", bit);
            }
            // Especificar bits.
            ba1[2] = true; // Genera ba1: false, false, true.
            ba2.SetAll(true); // Genera ba2: true, true, true.
            Console.WriteLine();
            Console.WriteLine("Cambiar el tercer bit");
            // Iterar sobre los bits de un BitArray.
            foreach (bool bit in ba1)
            {
                Console.Write("{0} ", bit);
            }
            Console.Read();
        }
    }
}
