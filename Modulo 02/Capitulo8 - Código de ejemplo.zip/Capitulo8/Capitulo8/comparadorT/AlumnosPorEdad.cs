﻿using System.Collections.Generic;
using estudiantesT;

namespace comparadorT
{
    class AlumnosPorEdad: Comparer<Alumno>
    {
        public override int Compare(Alumno obj1, Alumno obj2)
        {
            return obj1.Edad - obj2.Edad;
        }
    }
}
