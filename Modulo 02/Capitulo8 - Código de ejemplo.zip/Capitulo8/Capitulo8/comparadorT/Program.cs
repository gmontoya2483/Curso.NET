﻿using System;
using System.Collections.Generic;
using estudiantesT;

namespace comparadorT
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Alumno> alumnos = new List<Alumno>();

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);

            alumnos.Add(a1);
            alumnos.Add(a2);
            alumnos.Add(a3);
            alumnos.Add(a4);
            alumnos.Add(a5);

            Console.WriteLine("Usando el comparador por edad: ");
            // Ordenar usando el comparador
            alumnos.Sort(new AlumnosPorEdad());

            foreach (Alumno alumno in alumnos)
            {
                Console.Write(alumno);
                Console.WriteLine("\tEdad: " + alumno.Edad);
            }

            Comparer<Alumno> comparadorPorDefecto = Comparer<Alumno>.Default;

            Console.WriteLine("\nUsando la comparación por defecto: ");
            // Ordenar usando el comparador por defecto
            alumnos.Sort(comparadorPorDefecto);

            foreach (Alumno alumno in alumnos)
            {
                Console.Write(alumno);
                Console.WriteLine("\tEdad: " + alumno.Edad);
            }

            Console.ReadKey();
        }
    }
}
