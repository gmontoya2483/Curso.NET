﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using estudiantesT;

namespace listaEnlazadaT
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);

            // Crear una nueva lista enlazada. 
            Alumno[] alumnos = { a1, a2, a3, a4, a3, a1 };
            LinkedList<Alumno> clase = new LinkedList<Alumno>(alumnos);
            Imprimir(clase, "Valores de la lista enlazada:");
            ImprimeNodo("a3", a3);
            Console.WriteLine("clase.Contains(\"a3\") = {0}",
                clase.Contains(a3));

            // Agregar a5 al comienzo de la lista.
            clase.AddFirst(a5);
            ImprimeNodo("a5", a5);
            Imprimir(clase, "Verificación 1: Agregar 'a5' al principio de la lista:");

            // Mover el primer nodo para que sea el último.
            LinkedListNode<Alumno> nodo = clase.First;
            clase.RemoveFirst();
            clase.AddLast(nodo);
            Imprimir(clase, "Verificación 2: Mover el primer nodo para que sea el último:");

            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);
            // Cambiar el último nodo para que sea a6.
            clase.RemoveLast();
            clase.AddLast(a6);
            ImprimeNodo("a6", a6);
            Imprimir(clase, "Verificación 3: Cambiar el último nodo por 'a6':");

            // Mover el último nodo para que sea el primero.
            nodo = clase.Last;
            clase.RemoveLast();
            clase.AddFirst(nodo);
            Imprimir(clase, "Verificación 4: Mover el último nodo para que sea el primero:");


            // Usando los paréntesis buscar la última ocurrencia de a3.
            clase.RemoveFirst();
            LinkedListNode<Alumno> actual = clase.FindLast(a3);
            ImprimeNodo("a3", a3);
            ApuntarANodo(actual, "Verificación 5: Buscar la última ocurrencia de 'a3':");

            // Agregar a7 y a8 después de a3 (el nodo actual)
            Alumno a7 = new Alumno("Alejandro", "César", "Corso", 21, 21212);
            Alumno a8 = new Alumno("Pablo", "Ésteban", "Pegas", 27, 27272);
            clase.AddAfter(actual, a7);
            clase.AddAfter(actual, a8);
            ImprimeNodo("a3", a3);
            ImprimeNodo("a7", a7);
            ImprimeNodo("a8", a8);
            ApuntarANodo(actual, "Verificación 6: Se agregó a7 y a8 después de a3:");

            // Posicionarse en el nodo a4.
            actual = clase.Find(a4);
            ApuntarANodo(actual, "Verificación 7: Indicar el nodo a4:");
            ImprimeNodo("a4", a4);

            // Agregar a9 y a10 antes de a4
            Alumno a9 = new Alumno("Inés", "Amelia", "García", 29, 29292);
            Alumno a10 = new Alumno("Sandra", "Mónica", "Piedras", 23, 23232);
            clase.AddBefore(actual, a9);
            clase.AddBefore(actual, a10);
            ImprimeNodo("a9", a9);
            ImprimeNodo("a10", a10);
            ImprimeNodo("a4", a4);
            ApuntarANodo(actual, "Verificación 8: Agregar 'a9' y 'a10' antes de 'a4':");

            // Mantener una referencia al nodo actual a4
            // y al nodo anterior en la lista a10. Buscar el nodo a2
            nodo = actual;
            LinkedListNode<Alumno> nodo2 = actual.Previous;
            actual = clase.Find(a2);
            ImprimeNodo("a2", a2);
            ApuntarANodo(actual, "Verificación 9: Apuntar al nodo a2:");

            // El método AddBefore lanza una InvalidOperationException
            // si se trata de agregar un nodo que ya está en la lista
            Console.WriteLine("Verificación 10: Lanzar una excepción al agregar el nodo (a4) que está en la lista:");
            ImprimeNodo("a4", a4);
            try
            {
                clase.AddBefore(actual, nodo);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine("Mensaje de la excepción: {0}", ex.Message);
            }
            Console.WriteLine();

            // Sacar el nodo al que apunta 'nodo' y luego
            // agregarlo antes del nodo actual.
            // Indicar el nodo como el actual
            clase.Remove(nodo);
            clase.AddBefore(actual, nodo);
            ImprimeNodo("actual", actual.Value);
            ImprimeNodo("referenciado", nodo.Value);
            ApuntarANodo(actual, "Verificación 11: Mover el nodo referenciado (a4) antes del nodo actual (a2):");

            // Remover el nodo actual.
            clase.Remove(actual);
            ImprimeNodo("actual", actual.Value);
            ApuntarANodo(actual, "Verificación 12: Remover en nodo actual (a2) y tratar de indicarlo:");

            // Agregar un nodo después del referenciado por nodo
            clase.AddAfter(nodo, actual);
            ImprimeNodo("actual", actual.Value); // a2
            ImprimeNodo("nodo", nodo.Value);  // a4
            ApuntarANodo(actual, "Verificación 13: Agregar el nodo borrado en la verificación 11 luego del referenciado:");

            // El método Remove busca y borra el primer
            // nodo que tenga el valor especificado
            clase.Remove(a3);
            ImprimeNodo("a3", a3); 
            Imprimir(clase, "Verificación 14: Remover el primer nodo a3 encontrado:");

            // Cuando el tipo de una lista enlazada se convierte
            // a un tipo ICollection<Alumno>, el método Add agrega
            // el nodo al final de la lista.
            clase.RemoveLast();
            ICollection<Alumno> icoll = clase;
            Alumno a11 = new Alumno("Claudia", "Silvina", "Peralta", 30, 30303);
            icoll.Add(a11);
            ImprimeNodo("a11", a11);
            Imprimir(clase, "Verificación 15: Quitar el último nodo, convertir a ICollection, y agregar 'a11':");

            Console.WriteLine("Verificación 16: Copiar la lista a un vector:");
            // Crear un vector con el mismo número
            // de elementos que hay en la lista
            Alumno[] vecAlumnos = new Alumno[clase.Count];
            clase.CopyTo(vecAlumnos, 0);

            foreach (Alumno a in vecAlumnos)
            {
                Console.WriteLine(a);
            }

            // Liberar todos los nodos.
            clase.Clear();

            Console.WriteLine();
            Console.WriteLine("Verificación 17: Limpiar la lista enlazada. Ver si está 'a1' = {0}",
                clase.Contains(a1));

            Console.ReadLine();
        }

        private static void Imprimir(LinkedList<Alumno> alumnos, string mensaje)
        {
            Console.WriteLine(mensaje);
            foreach (Alumno alumno in alumnos)
            {
                Console.Write(alumno + " ");
            }
            Console.WriteLine();
            Console.WriteLine();
        }

        private static void ApuntarANodo(LinkedListNode<Alumno> nodo, string mensaje)
        {
            Console.WriteLine(mensaje);
            if (nodo.List == null)
            {
                Console.WriteLine("El nodo '{0}' no esta en la lista.\n",
                    nodo.Value);
                return;
            }

            StringBuilder resultado = new StringBuilder("(" + nodo.Value + ")");
            LinkedListNode<Alumno> nodeP = nodo.Previous;

            while (nodeP != null)
            {
                resultado.Insert(0, nodeP.Value + " ");
                nodeP = nodeP.Previous;
            }

            nodo = nodo.Next;
            while (nodo != null)
            {
                resultado.Append(" " + nodo.Value);
                nodo = nodo.Next;
            }

            Console.WriteLine(resultado);
            Console.WriteLine();
        }

        public static void ImprimeNodo(string s, Alumno a)
        {
            Console.WriteLine("Nodo {0}: {1}", s, a);
        }
    }
}