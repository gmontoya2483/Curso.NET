﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace listas
{
    class Program
    {
        static void Main(string[] args)
        {
            IList lista = new ArrayList();
            lista.Add("uno");
            lista.Add("segundo");
            lista.Add("3ro");
            lista.Add(4);
            lista.Add(5.0F);
            lista.Add("segundo"); // duplicado, se agrega
            lista.Add(4); // duplicado, se agrega
            foreach(Object o in lista)
            Console.WriteLine(o);

            Console.WriteLine("----------------------");
            Console.WriteLine("Usando el indexador");
            Console.WriteLine("----------------------");

            for(int i = 0; i < lista.Count; i++)
                 Console.WriteLine(lista[i]);
            Console.ReadKey();
        }
    }
}
