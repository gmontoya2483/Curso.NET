﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using estudiantesT;

namespace hashsetT
{
    class Program
    {
        static void Main(string[] args)
        {
            HashSet<Alumno> conjuntoOrdenado = new HashSet<Alumno>();

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);
            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);

            conjuntoOrdenado.Add(a1);
            conjuntoOrdenado.Add(a2);
            conjuntoOrdenado.Add(a3);
            conjuntoOrdenado.Add(a4);
            conjuntoOrdenado.Add(a5);
            conjuntoOrdenado.Add(a6);
            conjuntoOrdenado.Add(a2); // Duplicado. No se agrega
            conjuntoOrdenado.Add(a3); // Duplicado. No se agrega
            conjuntoOrdenado.Add(a1); // Duplicado. No se agrega
            conjuntoOrdenado.Add(a2); // Duplicado. No se agrega


            Console.WriteLine("Ejemplo de conjunto que no admite duplicados y esta desordenado");
            MostrarLista(conjuntoOrdenado);

            Console.WriteLine("Cantidad de elementos en el conjunto: " + conjuntoOrdenado.Count);
            Console.ReadKey();
        }

        public static void MostrarLista(ISet<Alumno> conjunto)
        {
            foreach (Alumno elemento in conjunto)
            {
                Console.WriteLine(elemento);
            }
        }
    }
}
