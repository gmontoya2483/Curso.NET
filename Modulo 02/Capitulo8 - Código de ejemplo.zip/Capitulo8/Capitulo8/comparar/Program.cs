﻿using System;
using System.Collections.Generic;
using estudiantesT;

namespace comparableT
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);

            Alumno a6 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);

            if (a1.CompareTo(a6) == 0) Console.WriteLine("El alumno a1 es el mismo que el a6");
            if (a1.CompareTo(a2) != 0) Console.WriteLine("El alumno a1 no es el mismo que el a2");
            if (a1.CompareTo(a2) > 0) Console.WriteLine("El alumno a1 es mayor que el a2");
            if (a1.CompareTo(a2) < 0) Console.WriteLine("El alumno a1 es menor que el a2");
            Console.ReadKey();
        }
    }
}
