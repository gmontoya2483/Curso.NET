﻿using System;
using System.Collections.Generic;
using estudiantesT;

namespace listasT
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Alumno> alumnos = new List<Alumno>();

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);


            Console.WriteLine("\nCapacity: {0}", alumnos.Capacity);

            alumnos.Add(a1);
            alumnos.Add(a2);
            alumnos.Add(a3);
            alumnos.Add(a4);
            alumnos.Add(a5);

            Console.WriteLine();
            foreach (Alumno alumno in alumnos)
            {
                Console.WriteLine(alumno);
            }

            Console.WriteLine("\nCapacity: {0}", alumnos.Capacity);
            Console.WriteLine("Count: {0}", alumnos.Count);

            Console.WriteLine("\nContains(\"{1}\"): {0}",
                alumnos.Contains(a1), a1);

            Console.WriteLine("Insertando un objeto igual al primero de la lista en el tercer lugar");
            Alumno a6 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Console.WriteLine("\nInsert(2, \"{0}\")", a6);
            alumnos.Insert(2, a6);

            Console.WriteLine();
            foreach (Alumno alumno in alumnos)
            {
                Console.WriteLine(alumno);
            }

            Console.WriteLine("\nalumnos[3]: {0}", alumnos[3]);

            Console.WriteLine("\nRemove(\"{0}\")", a6);
            alumnos.Remove(a6);

            Console.WriteLine();
            foreach (Alumno alumno in alumnos)
            {
                Console.WriteLine(alumno);
            }

            alumnos.TrimExcess();
            Console.WriteLine("\nTrimExcess()");
            Console.WriteLine("Capacity: {0}", alumnos.Capacity);
            Console.WriteLine("Count: {0}", alumnos.Count);

            alumnos.Sort();
            Console.WriteLine();
            Console.WriteLine("Escribiendo la lista ordenada");

            foreach (Alumno alumno in alumnos)
            {
                Console.WriteLine(alumno);
            }

            alumnos.Clear();
            Console.WriteLine("\nClear()");
            Console.WriteLine("Capacity: {0}", alumnos.Capacity);
            Console.WriteLine("Count: {0}", alumnos.Count);

            Console.ReadKey();
        }
    }
}
