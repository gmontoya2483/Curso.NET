﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using estudiantes;

namespace idiccionario
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear un diccionario con un máximo de 4 entradas
            IDictionary d1 = new Diccionario(4);
            IDictionary d2 = new Diccionario(4);

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);
            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);

            Horario h1 = new Horario(2, 1, 0, 2, 20);
            Horario h2 = new Horario(2, 2, 20, 3, 40);
            Horario h3 = new Horario(2, 3, 40, 5, 0);
            Horario h4 = new Horario(3, 2, 20, 3, 40);
            Horario h5 = new Horario(4, 3, 40, 5, 0);

            // Poblar el primer diccionario
            AgregaEntrada(d1, h1, a1);
            AgregaEntrada(d1, h2, a2);
            AgregaEntrada(d1, h3, a3);
            AgregaEntrada(d1, h1, a4);
            AgregaEntrada(d1, h4, a4);

            // Poblar el segundo diccionario
            AgregaEntrada(d2, h1, a2);
            AgregaEntrada(d2, h2, a3);
            AgregaEntrada(d2, h3, a4);
            AgregaEntrada(d2, h2, a5);
            AgregaEntrada(d2, h5, a6);

            Console.WriteLine("Número de elementos en el diccionario 1 = {0}", d1.Count);

            Console.WriteLine("¿Se encuentra en el diccionario 1 {0} ? {1}",h2, d1.Contains(h2));
            Console.WriteLine("El horario se asignó a " + d1[h2]);

            Console.WriteLine("\nMostrando el contenido del diccionario 1");
            ImprimirDiccionario(d1);

            Console.WriteLine("\nEliminando la entrada de " + h2);
            d1.Remove(h2);

            Console.WriteLine("\nMostrando el contenido del diccionario 1");
            ImprimirDiccionario(d1);

            Console.WriteLine("\nMostrando las claves del diccionario 1");
            MostrarClaves(d1);
            Console.WriteLine("\nMostrando los valores del diccionario 1");
            MostrarValores(d1);

            Console.WriteLine("----------------------------------------------");

            Console.WriteLine("\nNúmero de elementos en el diccionario 2 = {0}", d2.Count);

            Console.WriteLine("¿Se encuentra en el diccionario 2 {0} ? {1}", h2, d2.Contains(h2));
            Console.WriteLine("El horario se asignó a " + d2[h2]);

            Console.WriteLine("\nMostrando el contenido del diccionario 2");
            ImprimirDiccionario(d2);

            Console.WriteLine("\nEliminando la entrada de " + h2);
            d2.Remove(h2);

            Console.WriteLine("\nMostrando el contenido del diccionario 2");
            ImprimirDiccionario(d2);

            Console.WriteLine("\nMostrando las claves del diccionario 2");
            MostrarClaves(d2);
            Console.WriteLine("\nMostrando los valores del diccionario 2");
            MostrarValores(d2);

            Console.ReadKey();
        }

        public static void AgregaEntrada(IDictionary d, Object clave, Object valor)
        {
            try
            {
                d.Add(clave, valor);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine("Error. No se agregó entrada: " + e.Message);
            }
        }

        public static void ImprimirDiccionario(IDictionary d)
        {
            foreach (DictionaryEntry de in d)
            {
                Console.WriteLine("Clave: {0}. Valor:  {1}.", de.Key, de.Value);
            }
        }

        public static void MostrarClaves(IDictionary d)
        {
            Console.WriteLine("Claves del diccionario:");
            foreach (Object o in d.Keys)
                Console.WriteLine(o);
        }

        public static void MostrarValores(IDictionary d)
        {
            Console.WriteLine("Valores del diccionario:");
            foreach (Object o in d.Values)
                Console.WriteLine(o);
        }
    }
}

