﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace idiccionario
{
    class Diccionario : IDictionary
    {
        // El vector de elementos
        private DictionaryEntry[] elementos;
        private Int32 elementosEnUso = 0;

        // Construir el Diccionario con el número deseado de elementos.
        // El número de elementos no se puede cambiar durante 
        // la vida útil de este Diccionario.
        public Diccionario(Int32 cantidad)
        {
            elementos = new DictionaryEntry[cantidad];
        }


        #region IDictionary Members
        public bool IsReadOnly { get { return false; } }
        public bool Contains(object key)
        {
            Int32 indice;
            return TratarDeObtenerElIndiceDeLaClave(key, out indice);
        }
        public bool IsFixedSize { get { return false; } }
        public void Remove(object clave)
        {
            if (clave == null) throw new ArgumentNullException("La clave no puede ser nula");
            // Tratar de encontrar la clave en el vector de DictionaryEntry 
            Int32 indice;
            if (TratarDeObtenerElIndiceDeLaClave(clave, out indice))
            {
                // Si se encuentra la clave, correr todos los elementos.
                Array.Copy(elementos, indice + 1, elementos, indice, elementosEnUso - indice - 1);
                elementosEnUso--;
            }
            else
            {
                // Si la clave no se encuentra, retornar sin hacer nada. 
            }
        }
        public void Clear() { elementosEnUso = 0; }
        public void Add(object clave, object valor)
        {
            if (elementosEnUso == elementos.Length)
                throw new InvalidOperationException("El diccionario no puede almacenar más valores.");
            if (elementosEnUso > 0)
            {
                foreach (DictionaryEntry elemento in elementos)
                {
                    if (elemento.Key != null && elemento.Key.Equals(clave))
                        throw new ArgumentException("La clave existe: " + elemento.Key.ToString());
                }
            }
            elementos[elementosEnUso++] = new DictionaryEntry(clave, valor);
        }
        public ICollection Keys
        {
            get
            {
                // Retornar un  vector donde cada elemento es una clave
                Object[] claves = new Object[elementosEnUso];
                for (Int32 n = 0; n < elementosEnUso; n++)
                    claves[n] = elementos[n].Key;

                return claves;
            }
        }
        public ICollection Values
        {
            get
            {
                // Retornar un  vector donde cada elemento es un valor
                Object[] valores = new Object[elementosEnUso];
                for (Int32 n = 0; n < elementosEnUso; n++)
                    valores[n] = elementos[n].Value;
                return valores;
            }
        }
        public object this[object clave]
        {
            get
            {
                // Si la clave está en el diccionario, retornar el valor asociado
                Int32 indice;
                if (TratarDeObtenerElIndiceDeLaClave(clave, out indice))
                {
                    // Se encontró la clave. Retornar el valor. 
                    return elementos[indice].Value;
                }
                else
                {
                    // No se encontró la clave. Retornar null. 
                    return null;
                }
            }

            set
            {
                // Si la clave está en el diccionario, cambiar el valor asociado 
                Int32 indice;
                if (TratarDeObtenerElIndiceDeLaClave(clave, out indice))
                {
                    // Se encontró la clave. Cambiar el valor.
                    elementos[indice].Value = value;
                }
                else
                {
                    // No se encontró la clave. Agregar este par clave / valor.
                    Add(clave, value);
                }
            }
        }

        public IDictionaryEnumerator GetEnumerator()
        {
            // Construir y retornar el enumerador. 
            return new EnumeradorDiccionario(this);
        }
        #endregion
        private class EnumeradorDiccionario : IDictionaryEnumerator
        {
            // Una copia de los pares clave / valor del objeto del tipo Diccionario
            DictionaryEntry[] elementos;
            Int32 indice = -1;

            public EnumeradorDiccionario(Diccionario d)
            {
                // Realizar una copia de las entradas actuales del diccionario
                elementos = new DictionaryEntry[d.Count];
                Array.Copy(d.elementos, 0, elementos, 0, d.Count);
            }

            // Retornar el elemento actual. 
            public Object Current { get { ValidarIndice(); return elementos[indice]; } }

            // Retornar la entrada actual del diccionario. 
            public DictionaryEntry Entry
            {
                get { return (DictionaryEntry)Current; }
            }

            // Retornar la clave del elemento actual. 
            public Object Key { get { ValidarIndice(); return elementos[indice].Key; } }

            //  Retornar el valor del elemento actual. 
            public Object Value { get { ValidarIndice(); return elementos[indice].Value; } }

            // Avanzar al próximo elemento. 
            public Boolean MoveNext()
            {
                if (indice < elementos.Length - 1) { indice++; return true; }
                return false;
            }

            // Validar el índice de la enumeración y lanzar una excepción 
            // si el índice está fuera de rango
            private void ValidarIndice()
            {
                if (indice < 0 || indice >= elementos.Length)
                    throw new InvalidOperationException("El enumerador está antes o después de la colección.");
            }

            // Restablecer el índice para reiniciar la enumeración. 
            public void Reset()
            {
                indice = -1;
            }
        }
        private Boolean TratarDeObtenerElIndiceDeLaClave(Object clave, out Int32 indice)
        {
            for (indice = 0; indice < elementosEnUso; indice++)
            {
                // Si la clave se encuentra, devuelve true. 
                // También retorna el índice por referencia 
                if (elementos[indice].Key.Equals(clave)) return true;
            }

            // Clave no encontrada, devuelve false. Ignorar el índice
            return false;
        }

        #region ICollection Members
        public bool IsSynchronized { get { return false; } }
        public object SyncRoot { get { throw new NotImplementedException(); } }
        public int Count { get { return elementosEnUso; } }
        public void CopyTo(Array array, int index) { throw new NotImplementedException(); }
        #endregion

        #region IEnumerable Members
        IEnumerator IEnumerable.GetEnumerator()
        {
            // Construir y retornar el enumerador. 
            return ((IDictionary)this).GetEnumerator();
        }
        #endregion
    }
}
