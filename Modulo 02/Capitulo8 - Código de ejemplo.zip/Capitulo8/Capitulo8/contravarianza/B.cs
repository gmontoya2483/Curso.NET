﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace contravarianza
{
    class B : A
    {
        public B(int v) : base(v) { }

        public override void MiMetodo()
        {
            Console.WriteLine("Estoy en B.MiMetodo().");
        }
    }
}
