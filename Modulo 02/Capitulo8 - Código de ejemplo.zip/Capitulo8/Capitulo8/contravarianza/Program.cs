﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace contravarianza
{
    class Program
    {
        static void Main(string[] args)
        {
            // Las siguientes declaraciones son erróneas
            // porque los parámetros no tienen como
            // supertipo a B
            //IEqualityComparer<A> compA = new ComparadorIgualdad(1);
            //IEqualityComparer<C> compC = new ComparadorIgualdad(3); 

            // Declaraciones correctas
            IEqualityComparer<B> compB = new ComparadorIgualdad(2); 
            IEqualityComparer<D> compD = new ComparadorIgualdad(4);

            ImprimeHashCode(compB, compD);
            Console.WriteLine("------------------------------");
            // Asignaciones válidas por contravarianza
            IEqualityComparer<B> compB2 = compB;
            IEqualityComparer<D> compD2 = compB;

            ImprimeHashCode(compB2, compD2);

            Console.ReadKey();
        }

        public static void ImprimeHashCode(IEqualityComparer<D> obj, IEqualityComparer<D> obj2)
        {
            // Obtiene el código hash del objeto del 
            // tipo ComparadorIgualdad
            D d1 = new D(5);
            D d2 = new D(5);
            Console.WriteLine("HashCode de d1 para obj: " + obj.GetHashCode(d1));
            Console.WriteLine("HashCode de d2 para obj2: " + obj2.GetHashCode(d2));
            if (obj.Equals(d1,d2))
                Console.WriteLine("Son Iguales");
            else
            {
                Console.WriteLine("Son diferentes");
            }
        }
    }

}