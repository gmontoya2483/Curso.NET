﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace contravarianza
{
    class ComparadorIgualdad : IEqualityComparer<B>
    {
        private int var;

        public ComparadorIgualdad(int var)
        {
            this.var = var;
        }

        public bool Equals(B x, B y)
        {
            return x.Equals(y);
        }

        public int GetHashCode(B obj)
        {
            return obj.GetHashCode();
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (GetType() != obj.GetType())
                return false;
            ComparadorIgualdad otro = (ComparadorIgualdad)obj;
            if (var != otro.var) return false;
            return true;
        }

        public override int GetHashCode()
        {
            return var;
        }
    }
}
