﻿using System;

namespace estudiantesT
{
    public class Horario: IComparable<Horario>
    {
        private int dia = 0;
        private int horaComienzo = 0;
        private int minutosComienzo = 0;
        private int horaFin = 0;
        private int minutosFin = 0;

        public Horario(int dia, int horaComienzo, int minutosComienzo, int horaFin,
                int minutosFin)
        {
            this.dia = dia;
            this.horaComienzo = horaComienzo;
            this.minutosComienzo = minutosComienzo;
            this.horaFin = horaFin;
            this.minutosFin = minutosFin;
        }

        public Horario(Horario f)
        {
            this.dia = f.dia;
            this.horaComienzo = f.horaComienzo;
            this.minutosComienzo = f.minutosComienzo;
            this.horaFin = f.horaFin;
            this.minutosFin = f.minutosFin;
        }

        public Horario Agregar(int masDias)
        {
            Horario nuevaFecha = new Horario(this);
            nuevaFecha.dia += masDias;
            return nuevaFecha;
        }

        public int CompareTo(Horario elOtro)
        {
            if (elOtro == null) return 1;
            int aux = dia - elOtro.dia;
            if (aux != 0) return aux;
            aux = horaComienzo - elOtro.horaComienzo;
            if (aux != 0) return aux;
            aux = horaFin - elOtro.horaFin;
            if (aux != 0) return aux;
            aux = minutosComienzo - elOtro.minutosComienzo;
            if (aux != 0) return aux;
            aux = minutosFin - elOtro.minutosFin;
            if (aux != 0) return aux;
            return 0;
        }

        public void Imprimir()
        {
            Console.WriteLine("Horario--> ");
            Console.WriteLine("Día: " + dia);
            Console.WriteLine("Hora de comienzo: " + horaComienzo);
            Console.WriteLine("Minutos de comienzo: " + minutosComienzo);
            Console.WriteLine("Hora de fin: " + horaFin);
            Console.WriteLine("Minutos de fin: " + minutosFin);
        }

        // Rescribir GestHasCode de Object para las
        // colecciones que ordenan por este método
        public override int GetHashCode()
        {
           return dia ^ horaComienzo ^ minutosComienzo ^ horaFin ^ minutosFin;
        }

        // Rescribir el método Equals de Object
        // y cumplir con las relaciones de equivalencia
        public override bool Equals(Object obj)
        {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (GetType() != obj.GetType())
                return false;
            Horario otro = (Horario)obj;
            if (dia != otro.dia) return false;
            if (horaComienzo != otro.horaComienzo) return false;
            if (minutosComienzo != otro.minutosComienzo) return false;
            if (horaFin != otro.horaFin) return false;
            if (minutosFin != otro.minutosFin) return false;
            return true;
        }

        public override string ToString()
        {
            return "[" + dia + " " + horaComienzo + ":" + minutosComienzo + 
                "] a [" + dia + " " + horaFin + ":" + minutosFin + "]";
        }

        public int Dia
        {
            get
            {
                return dia;
            }
        }
        public int HoraComienzo
        {
            get
            {
                return horaComienzo;
            }
        }
        public int MinutosComienzo
        {
            get
            {
                return minutosComienzo;
            }
        }
        public int HoraFin
        {
            get
            {
                return horaFin;
            }
        }
        public int MinutosFin
        {
            get
            {
                return minutosFin;
            }
        }
    }
}
