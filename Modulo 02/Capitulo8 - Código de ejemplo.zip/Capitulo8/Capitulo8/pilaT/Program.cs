﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using estudiantesT;

namespace pilaT
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<Alumno> alumnos = new Stack<Alumno>();

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);
            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);

            alumnos.Push(a1);
            alumnos.Push(a2);
            alumnos.Push(a3);
            alumnos.Push(a4);
            alumnos.Push(a5);
            alumnos.Push(a6);
            alumnos.Push(a1);
            alumnos.Push(a2);
            alumnos.Push(a3);
            alumnos.Push(a4);

            // Una pila se puede enumerar sin perturbar su contenido. 
            foreach (Alumno alumno in alumnos)
            {
                Console.WriteLine(alumno);
            }

            Console.WriteLine("\nSacando de la pila '{0}'", alumnos.Pop());
            Console.WriteLine("Mirar el elemento que quedó para sacar: {0}",
                alumnos.Peek());
            Console.WriteLine("Sacando el elemento que se inspeccionó '{0}'", alumnos.Pop());

            // Crear una copia de la pila, utilizando el método ToArray y 
            // el constructor que acepta un IEnumerable.
            Stack<Alumno> otraPila = new Stack<Alumno>(alumnos.ToArray());

            Console.WriteLine("\nContenido de la primera copia:");
            foreach (Alumno alumno in otraPila)
            {
                Console.WriteLine(alumno);
            }

            // Crear un vector de dos veces el tamaño de la pila y copiar 
            // los elementos de la pila, a partir de la mitad del mismo
            Alumno[] vector = new Alumno[alumnos.Count * 2];
            alumnos.CopyTo(vector, alumnos.Count);

            // Se crea una segunda pila, utilizando el constructor que acepta un
            // IEnumerable<T> .
            Stack<Alumno> terceraPila = new Stack<Alumno>(vector);

            Console.WriteLine("\nContenido de la segunda copia con duplicados y nulos:");
            foreach (Alumno alumno in terceraPila)
            {
                Console.WriteLine(alumno);
            }

            Console.WriteLine("\notraPila.Contains(\"a2\") = {0}",
                otraPila.Contains(a2));

            Console.WriteLine("\notraPila.Clear()");
            otraPila.Clear();
            Console.WriteLine("\notraPila.Count = {0}", otraPila.Count);
            Console.ReadKey();
        }
    }
}
