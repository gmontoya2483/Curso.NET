﻿using System.Collections.Generic;
using estudiantesT;

namespace comparadorIgualdadT
{
    class HorarioIgualHora : EqualityComparer<Horario>
    {
        public override bool Equals(Horario x, Horario y)
        {
            if (x.HoraComienzo == y.HoraComienzo && x.HoraFin == y.HoraFin &&
                x.MinutosComienzo == y.MinutosComienzo && x.MinutosFin == y.MinutosFin)
                return true;
            return false;
        }

        public override int GetHashCode(Horario obj)
        {
            return obj.HoraComienzo ^ obj.MinutosComienzo ^ obj.HoraFin ^ obj.MinutosFin;
        }
    }
}
