﻿using System;
using System.Collections.Generic;
using estudiantesT;

namespace comparadorIgualdadT
{
    class Program
    {
        static Dictionary<Horario, Alumno> horarios;

        static void Main(string[] args)
        {
            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);
            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);

            // Construir un diccionario donde el criterio para 
            // comparar claves sea por la igualdad de los días
            HorarioIgualDia horariosDelMismoDia = new HorarioIgualDia();
            horarios = new Dictionary<Horario, Alumno>(horariosDelMismoDia);

            Console.WriteLine("Horarios en el mismo día");
            Horario h1 = new Horario(2, 1, 0, 2, 20);
            Horario h2 = new Horario(2, 2, 20, 3, 40);
            Horario h3 = new Horario(2, 3, 40, 5, 0);
            Horario h4 = new Horario(3, 2, 20, 3, 40);
            Horario h5 = new Horario(4, 3, 40, 5, 0);

            AgregarHorario(h1, a1);
            AgregarHorario(h2, a2);
            AgregarHorario(h3, a3);
            AgregarHorario(h4, a4);
            AgregarHorario(h5, a5);

            Console.WriteLine("Cantidad de objetos en el diccionario: " + horarios.Count);

            Console.WriteLine();

            // Construir un diccionario donde el criterio para 
            // comparar claves sea por la igualdad de hora y minutos
            HorarioIgualHora horariosConLaMismaHora = new HorarioIgualHora();
            horarios = new Dictionary<Horario, Alumno>(horariosConLaMismaHora);

            Console.WriteLine("Horarios con la misma hora");
            Horario h6 = new Horario(15, 2, 20, 3, 30);
            Horario h7 = new Horario(18, 2, 20, 3, 30);
            Horario h8 = new Horario(22, 2, 20, 3, 30);
            Horario h9 = new Horario(18, 4, 20, 5, 30);

            AgregarHorario(h6, a1);
            AgregarHorario(h7, a2);
            AgregarHorario(h8, a3);
            AgregarHorario(h9, a4);

            Console.WriteLine("Cantidad de objetos en el diccionario: " + horarios.Count);

            Console.ReadKey();
        }

        public static void AgregarHorario(Horario horario, Alumno alumno)
        {
            try
            {
                horarios.Add(horario, alumno);
                // El HashCode del objeto que es clave no es el que se utiliza
                // para realizar la comparación de la clave, sino el de EqualityComparer
                Console.WriteLine("Agregado {0}, Horario {1} Cantidad = {2}, HashCode = {3}",
                    alumno, horario, horarios.Count.ToString(), horario.GetHashCode());
            }
            catch (ArgumentException)
            {
                Console.WriteLine("Un horario igual a {0} ya se encuentra en la colección", horario);
                Console.WriteLine("No se agrega el horario para el alumno {0} .", alumno);
            }
        }
    }
}
