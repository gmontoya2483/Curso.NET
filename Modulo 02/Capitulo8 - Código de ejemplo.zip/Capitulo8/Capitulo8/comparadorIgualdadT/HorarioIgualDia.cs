﻿using System;
using System.Collections.Generic;
using estudiantesT;

namespace comparadorIgualdadT
{
    class HorarioIgualDia : EqualityComparer<Horario>
    {

        public override bool Equals(Horario x, Horario y)
        {
            if (x.Dia == y.Dia) return true;
            return false;
        }

        public override int GetHashCode(Horario obj)
        {
            return obj.Dia;
        }
    }
}
