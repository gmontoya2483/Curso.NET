﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using estudiantesT;

namespace colasT
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<string> alumnos = new Queue<string>();

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);
            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);
            
            alumnos.Enqueue(a1.ToString());
            alumnos.Enqueue(a2.ToString());
            alumnos.Enqueue(a3.ToString());
            alumnos.Enqueue(a4.ToString());
            alumnos.Enqueue(a5.ToString());
            alumnos.Enqueue(a6.ToString());

            Console.WriteLine("Contenido inicial de la cola:");
            
            // Una cola puede ser enumerada sin alterar su contenido
            foreach (string alumno in alumnos)
            {
                Console.WriteLine(alumno);
            }

            Console.WriteLine("\nSacando de la cola a '{0}'", alumnos.Dequeue());
            Console.WriteLine("Mirar el próximo elemento antes de sacarlo: {0}",
                alumnos.Peek());
            Console.WriteLine("Dequeuing '{0}'", alumnos.Dequeue());

            // Crear una copia de la cola usando el método ToArray junto al
            // constructor que acepta un objeto del tipo IEnumerable<T>
            Queue<string> copiaCola = new Queue<string>(alumnos.ToArray());

            Console.WriteLine("\nContenido de la primera copia:");
            foreach (string alumno in copiaCola)
            {
                Console.WriteLine(alumno);
            }

            // Crear un vector del doble del tamaño de la cola y copiar
            // los elementos que ésta almacena, comenzando por la mitad
            // del vector
            string[] vector2 = new string[alumnos.Count * 2];
            alumnos.CopyTo(vector2, alumnos.Count);

            // Crear una segunda cola, usando el método ToArray junto al
            // constructor que acepta un objeto del tipo IEnumerable<T>
            Queue<string> copiaCola2 = new Queue<string>(vector2);

            Console.WriteLine("\nContenido de la segunda copia, con duplicados y valores nulos:");
            foreach (string alumno in copiaCola2)
            {
                Console.WriteLine(alumno);
            }

            Console.WriteLine("\ncopiaCola2.Contains(\"{0}\") = {1}",
                copiaCola2.Contains(a3.ToString()), a3);

            Console.WriteLine("\ncopiaCola2.Clear()");
            copiaCola2.Clear();
            Console.WriteLine("\ncopiaCola2.Count = {0}", copiaCola2.Count);
            Console.ReadKey();
        }
    }
}