﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using estudiantes;

namespace comparable
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList lista = new ArrayList();

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);
            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);

            lista.Add(a1);
            lista.Add(a2);
            lista.Add(a3);
            lista.Add(a4);
            lista.Add(a5);
            lista.Add(a6);

            Console.WriteLine("Lista desordenada");
            MostrarLista(lista);

            lista.Sort();

            Console.WriteLine("\nLista ordenada");
            MostrarLista(lista);

            Console.ReadKey();
        }

        public static void MostrarLista(IList lista)
        {
            foreach (Object elemento in lista)
            {
                Console.WriteLine(elemento);
            }
        }
    }
}
