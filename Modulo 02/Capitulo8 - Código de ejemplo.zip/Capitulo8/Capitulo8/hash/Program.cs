﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace hash
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable tabla = new Hashtable();
            try
            {
                tabla.Add("uno", "1ro");
                tabla.Add("segundo", 2);
                tabla.Add("tercero", "3º");
                // Intentando usar la misma clave
                tabla.Add("tercero", "III");
            }
            catch (ArgumentException e)
            {
                Console.WriteLine("La clave está en uso: " + e.Message);
            }
            // Devuelve el conjunto de objetos que son las claves
            ICollection claves = tabla.Keys;
            Console.WriteLine("-- Imprimiendo claves --");
            foreach (Object c in claves) 
            {
                Console.WriteLine("Clave: " + c.ToString());
            }


            // Devuelve el conjunto de objetos que son los valores
            ICollection coleccion = tabla.Values;
            Console.WriteLine("-- Imprimiendo valores --");
            foreach (Object c in coleccion)
            {
                Console.WriteLine("Valor: " + c.ToString());
            }

            Console.WriteLine("-- Imprimiendo pares clave / valor --");
            foreach (DictionaryEntry de in tabla)
            {
                Console.WriteLine("Clave: " + de.Key + "\t Valor: " + de.Value);
            }
            Console.ReadKey();
        }
    }
}