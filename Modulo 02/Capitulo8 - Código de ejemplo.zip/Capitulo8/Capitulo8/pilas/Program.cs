﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace pilas
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack stack = new Stack();
            stack.Push(2);
            stack.Push(4);
            stack.Push(6);
            while (stack.Count != 0)
            {
                Console.WriteLine(stack.Pop());
            }
            Console.ReadKey();
        }
    }
}
