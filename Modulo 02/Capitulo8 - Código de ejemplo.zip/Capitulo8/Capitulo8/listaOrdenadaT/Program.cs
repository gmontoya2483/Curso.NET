﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using estudiantesT;

namespace listaOrdenadaT
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crea e inicializa un nuevo SortedList.
            SortedList<Horario, Alumno> listaOrdenada = new SortedList<Horario, Alumno>();

            Alumno a1 = new Alumno("Juan", "Adrián", "Lozano", 22, 12345);
            Alumno a2 = new Alumno("Fabio", "Miguel", "Sivori", 21, 11111);
            Alumno a3 = new Alumno("Eduardo", "Dario", "Masche", 20, 22222);
            Alumno a4 = new Alumno("Román", "Federico", "Giuta", 24, 66666);
            Alumno a5 = new Alumno("Ignacio", "Fabián", "Insaurralde", 25, 55555);
            Alumno a6 = new Alumno("Pedro", "Alejo", "Farfán", 20, 23232);

            Horario h1 = new Horario(2, 1, 0, 2, 20);
            Horario h2 = new Horario(2, 2, 20, 3, 40);
            Horario h3 = new Horario(2, 3, 40, 5, 0);
            Horario h4 = new Horario(3, 2, 20, 3, 40);
            Horario h5 = new Horario(4, 3, 40, 5, 0);

            listaOrdenada.Add(h1, a1);
            listaOrdenada.Add(h2, a2);
            listaOrdenada.Add(h3, a3);
            listaOrdenada.Add(h4, a4);
            listaOrdenada.Add(h5, a5);
            try
            {
                Console.WriteLine("Intentando agregar una clave que existe: " + h5);
                listaOrdenada.Add(h5, a6);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            // Mostrar propiedades y valores del SortedList.
            Console.WriteLine("Lista ordenada");
            Console.WriteLine("  Count:    {0}", listaOrdenada.Count);
            Console.WriteLine("  Capacity: {0}", listaOrdenada.Capacity);
            Console.WriteLine("  Claves y Valores:");
            ImprimirClavesYValores(listaOrdenada);

            Console.ReadKey();
        }

        public static void ImprimirClavesYValores(SortedList<Horario, Alumno> lista)
        {
            Console.WriteLine("\t-Clave-\t\t\t-Valor-");

            foreach (KeyValuePair<Horario, Alumno> kvp in lista)
            {
                Console.WriteLine("\t{0}:\t{1}", kvp.Key, kvp.Value);
            }
            Console.WriteLine();
        }
    }
}