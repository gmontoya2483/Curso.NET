﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operacionesBancarias
{
    class Cliente
    {
        private Cuenta cuenta;
        private String primerNombre;
        private String apellido;

        public Cliente(String ape, String nom)
        {
            primerNombre = ape;
            apellido = nom;
        }
        public Cuenta Cuenta
        {
            get
            {
                return cuenta;
            }
            set
            {
                cuenta = value;
            }
        }
        public String PrimerNombre
        {
            get
            {
                return primerNombre;
            }
        }
        public String Apellido
        {
            get
            {
                return apellido;
            }
        }
    }
}
