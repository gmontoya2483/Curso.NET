﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            int[] vector1 = { 2, 3, 5, 7, 11, 17, 19 };
            int[] vector2;
            p.ImprimeVector(vector1);

            vector2 = vector1;

            for (int i = 0; i < 7; i++)
            {
                vector2[i] = i;
            }
            p.ImprimeVector(vector1);
            Console.ReadKey();
        }

        public void ImprimeVector(int[] vector)
        {
            Console.Write('<');
            for (int i = 0; i < vector.Length; i++)
            {
                // Imprimir un elemento
                Console.Write(vector[i]);
                // Imprimir una coma para delimitar si no es el último elemento
                if ((i + 1) < vector.Length)
                {
                    Console.Write(", ");
                }
            }
            Console.Write('>');
            Console.WriteLine();
        }

    }
}
