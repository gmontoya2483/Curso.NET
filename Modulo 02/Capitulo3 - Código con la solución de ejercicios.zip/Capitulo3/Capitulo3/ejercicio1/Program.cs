﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int numero = 1; numero < 51; numero++)
            {
                Console.Write(numero);
                if (numero % 3 == 0)
                {
                    Console.Write(" mTres");
                }

                if (numero % 5 == 0)
                {
                    Console.Write(" mCinco");
                }

                if (numero % 7 == 0)
                {
                    Console.Write(" mSiete");
                }
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
