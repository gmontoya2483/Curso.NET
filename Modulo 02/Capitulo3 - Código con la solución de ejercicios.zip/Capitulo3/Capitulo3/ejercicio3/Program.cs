﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            int[][] matriz = new int[5][];

            matriz[0] = new int[0];
            matriz[1] = new int[1];
            matriz[2] = new int[2];
            matriz[3] = new int[3];
            matriz[4] = new int[4];

            for (int i = 0; i < matriz.Length; i++)
			{
                for (int j = 0; j < matriz[i].Length; j++)
                {
                    matriz[i][j] = j * i;
                }
			}
            for (int i = 0; i < matriz.Length; i++)
            {
                Console.Write("matriz[0] es ");
                p.ImprimeVector(matriz[i]);
            }

            Console.ReadKey();
        }

        public void ImprimeVector(int[] vector)
        {
            Console.Write('<');
            for (int i = 0; i < vector.Length; i++)
            {
                // Imprimir un elemento
                Console.Write(vector[i]);
                // Imprimir una coma para delimitar si no es el último elemento
                if ((i + 1) < vector.Length)
                {
                    Console.Write(", ");
                }
            }
            Console.Write('>');
            Console.WriteLine();
        }
    }
}
