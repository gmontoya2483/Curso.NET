﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3
{
    /**
     * Esta clase define la implementación una cola FIFO circular de tamaño fijo
     */
    public class ColaCircular : ICola
    {

        private object[] cola;
        private int indiceFrente;
        private int indiceFinal;

        /*
         * Este es el constructor por defecto de una cola estándar y vacía FIFO
         */
        public ColaCircular(int capacidad)
        {
            cola = new Object[capacidad];
            indiceFrente = 0;
            indiceFinal = 0;
        }

        /**
         * Este procedimiento agrega un objeto al final de la cola
         *
         * Parámetro -  object:  el objeto a agregar
         *
         * Excepción - ExcepcionDeColaLlena:  esta excepción nunca se lanzará
         */
        public void AgregarAlFinal(Object objeto)
        {
            if ((indiceFinal + 1) % cola.Length == indiceFrente)
            {
                throw new ExcepcionDeColaLlena(this);
            }
            cola[indiceFinal] = objeto;
            indiceFinal = (indiceFinal + 1) % cola.Length;
        }


        /*
         * Esta función recupera y remueve el objeto 
         * al frente de la cola
         *
         * Retorna - object:  el ítem al frente de la cola
         *
         * Excepción - ExcepcionDeColaVacia  cuando la cola esta vacía
         */
        public Object RemoverAlFrente()
        {
            if (indiceFrente == indiceFinal)
            {
                throw new ExcepcionDeColaVacia(this);
            }
            object objeto = cola[indiceFrente];
            cola[indiceFrente] = null;
            indiceFrente = (indiceFrente + 1) % cola.Length;
            return objeto;
        }

        /*
         * Esta función recupera (pero no remueve) el objeto 
         * al frente de la cola
         *
         * Retorna - object:  el ítem al frente de la cola
         *
         * Excepción - ExcepcionDeColaVacia  cuando la cola esta vacía
         */
        public Object GetAlFrente()
        {
            if (indiceFrente == indiceFinal)
            {
                throw new ExcepcionDeColaVacia(this);
            }
            return cola[indiceFrente];
        }
        /**
         * Esta función determina si la cola está vacía.
         *
         * Retorna - bool:  true si la cola está vacía
         */
        public bool EstaVacio()
        {
            return (Largo == 0);
        }

        /**
         * Esta función retorna el largo actual de la cola
         *
         * Retorna - int:  el largo actual de la cola
         */
        public int Largo
        {
            get
            {
                return indiceFinal - indiceFrente;
            }
        }

        /**
         * Este método retorna el tamaño máximo de la cola. Puede retornar
         * -1 si la capacidad de la cola no es fija.
         *
         * Retorna - int:  el tamaño máximo de la cola
         */
        public int Capacidad
        {
            get
            {
                return cola.Length;
            }
        }
    }
}
