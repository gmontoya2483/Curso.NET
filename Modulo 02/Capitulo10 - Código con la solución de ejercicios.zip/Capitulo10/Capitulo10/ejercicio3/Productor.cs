﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ejercicio3
{
    public class Productor
    {
        private int longitudDeTrabajos;
        private int numeroDeTrabajos;
        private int retrasoEntreTrabajos;
        private String nombreProductor;

        public Productor(String nombre, int numero, int longitud, int retraso)
        {
            nombreProductor = nombre;
            numeroDeTrabajos = numero;
            longitudDeTrabajos = longitud;
            retrasoEntreTrabajos = retraso;
        }

        public void EjecutarThread()
        {
            Impresora imp = Impresora.GetImpresora();
            TrabajoDeImpresion trabajo = null;
            bool trabajoEntregado = false;

            for (int i = 1; i <= numeroDeTrabajos; i++)
            {
                // generar un nuevo trabajo de impresión
                trabajo = new TrabajoDeImpresion(nombreProductor + "#" + i, longitudDeTrabajos);

                do
                {
                    try
                    {
                        Console.WriteLine("P: Agregando trabajo '" + trabajo.NombreDeTrabajo + "' a la cola");
                        imp.AgregarTrabajo(trabajo);
                        trabajoEntregado = true;
                    }
                    catch (ExcepcionDeColaLlena e)
                    {
                        Console.WriteLine("P: la cola de impresión esta llena, inténtelo nuevamente...");
                        Console.WriteLine("Error: " + e.Message);
                    }
                } while (!trabajoEntregado);

                // Hacer un sleep entre trabajos
                try
                {
                    Thread.Sleep(retrasoEntreTrabajos);
                }
                catch (ThreadInterruptedException e)
                {
                    Console.WriteLine("P." + nombreProductor + " ha sido interrumpido/a.");
                    Console.WriteLine("Error: " + e.Message);
                }
            }
        }
    }
}
