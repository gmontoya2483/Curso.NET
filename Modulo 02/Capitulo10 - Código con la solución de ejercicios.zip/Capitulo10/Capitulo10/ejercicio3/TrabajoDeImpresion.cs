﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ejercicio3
{
    public class TrabajoDeImpresion
    {
        private int paginas;
        private String nombreDeTrabajo;

        public TrabajoDeImpresion(String nombre, int paginas)
        {
            this.nombreDeTrabajo = nombre;
            this.paginas = paginas;
        }

        public String NombreDeTrabajo
        {
            get
            {
                return nombreDeTrabajo;
            }
        }
        public int NumeroDePaginas
        {
            get
            {
                return paginas;
            }
        }
    }
}
