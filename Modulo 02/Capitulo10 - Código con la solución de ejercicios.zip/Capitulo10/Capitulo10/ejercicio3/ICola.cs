﻿using System;
namespace ejercicio3
{
    public interface ICola
    {
        /*
        * Este procedimiento agrega un objeto al final de la cola
        *
        * Parámetro - object:  el Object a agregar
        *
        * Excepción - ExcepcionDeColaLlena:  esta excepción se lanzará cuando la cola este llena
        */
        void AgregarAlFinal(object objeto);
        /*
        * Esta función recupera (pero no remueve) el objeto 
        * al frente de la cola
        *
        * Retorna - object:  el ítem al frente de la cola
        *
        * Excepción - ExcepcionDeColaVacia:  cuando la cola esta vacía
        */
        Object GetAlFrente();

        /*
        * Esta función recupera y remueve el objeto 
        * al frente de la cola
        *
        * Retorna - object:  el ítem al frente de la cola
        *
        * Excepción - ExcepcionDeColaVacia:  cuando la cola esta vacía
        */
        object RemoverAlFrente();

        /*
        * Esta función determina si la cola está vacía.
        *
        * Retorna -  bool = true si la cola está vacía
        */
        bool EstaVacio();

        /*
        * Esta función retorna el largo actual de la cola
        *
        * Retorna -  int:  el largo actual de la cola
        */
        int Largo { get; }

        /*
         * Este método retorna el tamaño máximo de la cola. Puede retornar
         * -1 si la capacidad de la cola no es fija.
         *
         * Retorna - int  el tamaño máximo de la cola
         */
        int Capacidad { get; }
    }
}
