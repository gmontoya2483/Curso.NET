﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ejercicio2
{
    class ImprimirMiNombre
    {
        public void EjecutarThread()
        {
            for (int x = 0; x < 10; x++)
            {
                Console.WriteLine(Thread.CurrentThread.Name + " Nro: " + x);
                Thread.Sleep(new Random(10).Next(1,10));
            }
        }
    }
}
