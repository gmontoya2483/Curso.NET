﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace ejercicio1
{
    class Program
    {
        static void Main(string[] args)
        {
            ImprimirMiNombre imp = new ImprimirMiNombre();
            
            Thread t1 = new Thread(imp.EjecutarThread);
            Thread t2 = new Thread(imp.EjecutarThread);
            Thread t3 = new Thread(imp.EjecutarThread);


            t1.Name = "T1 - Primero";
            t2.Name = "T2 - Segundo";
            t3.Name = "T3 - Tercero";

            t1.Start();
            t2.Start();
            t3.Start();

            Console.ReadKey();
        }
    }
}
