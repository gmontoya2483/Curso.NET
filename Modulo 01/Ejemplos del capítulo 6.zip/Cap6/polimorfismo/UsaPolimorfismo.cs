﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class UsaPolimorfismo
    {
        static void Main(string[] args)
        {
		UsaPolimorfismo up = new UsaPolimorfismo();
		Persona refPolimorfica;
		
		Direccion d = new Direccion(true, "Juan De Garay", 870, true, 1, "A");
	
		d = null;
		d = new Direccion(false, "Amenabar", 1570, true, 7, "H");
		Empleado e = new Empleado("Sergio", "Omar", "Perotti","20.200.555",d, 
						"Administración","EA01","GAD50",1500.0F);
		d = null;
		d = new Direccion(true, "Allen", 1070, true, 5, "J");
		Secretaria s = new Secretaria("Laura", "Verónica", "Diaz","20.555.555",d, 
						"Directorio","SV01","GV50",1800.0F);
		d = null;
		d = new Direccion(false, "Juramento", 4561, false, 0, " ");
		Gerente g = new Gerente("Juan", "Pedro", "Goyena","17.767.076",d, 
						"Ventas","0","GV50",5500.0F,20);
		d = null;
		d = new Direccion(true, "Belgrano", 4560, true, 3, "C");
		AgenteDeSeguridad a = new AgenteDeSeguridad("Hernán", "Adrián",
						"Perez","20.888.999",d, "207272");
		
		refPolimorfica = e;
		Console.WriteLine(refPolimorfica.GetDetalles());
        Console.WriteLine();
		refPolimorfica = s;
		Console.WriteLine(refPolimorfica.GetDetalles());
        Console.WriteLine();
        refPolimorfica = g;
		Console.WriteLine(refPolimorfica.GetDetalles());
        Console.WriteLine();
        refPolimorfica = a;
        Console.WriteLine(refPolimorfica.GetDetalles());
		
		up.MuestraDetalles(e);
		up.MuestraDetalles(s);
		up.MuestraDetalles(g);
		up.MuestraDetalles(a);
	}

        public void MuestraDetalles(Persona refPolimorfica){
        Console.WriteLine();
		Console.WriteLine("-----------------");
		Console.WriteLine(refPolimorfica.GetDetalles());
        Console.WriteLine("-----------------");
        Console.ReadKey();
	}
    }
}
