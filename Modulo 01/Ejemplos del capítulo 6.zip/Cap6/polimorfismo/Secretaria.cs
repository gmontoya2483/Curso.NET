﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class Secretaria : Empleado
    {
        public Secretaria(
            String p,
            String s,
            String a,
            String doc,
            Direccion objDir,
            String dep,
            String i,
            String ij,
            float sdo):base(p, s, a, doc, objDir, dep, i, ij, sdo)
        {
        }

        public override string GetDetalles()
        {
            ArmaDetalles();
            return _detalles;
        }

        private void ArmaDetalles()
        {
            _detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + ObjDireccion.NombreCalle + " " + ObjDireccion.Nro +
            " " + ObjDireccion.Piso + "°" + ObjDireccion.Dpto +
            " Departamento: " + Departamento + " ID:" + Id +
            " ID del Jefe:" + IdJefe + " Sueldo:" + Sueldo;
        }
    }
}
