﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class AgenteDeSeguridad : Persona
    {
        private String _nroLicencia;

        public String NroLicencia
        {
            get { return _nroLicencia; }
            set { _nroLicencia = value; }
        }

        public AgenteDeSeguridad(String p,
            String s,
            String a,
            String d,
            Direccion objDir,
            String nl)
            : base(p, s, a, d, objDir)
        {
            _nroLicencia = nl;
        }


        public override string GetDetalles()
        {
            ArmaDetalles();
            return _detalles;
        }

        private void ArmaDetalles()
        {
            _detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + base.ObjDireccion.NombreCalle + " " + base.ObjDireccion.Nro +
            " " + base.ObjDireccion.Piso + "°" + base.ObjDireccion.Dpto;
        }

    }
}
