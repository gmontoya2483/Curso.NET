﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace polimorfismo
{
    class Direccion
    {
        private String _nombreCalle;	// nombre completo de la calle

        public String NombreCalle
        {
            get { return _nombreCalle; }
            set { _nombreCalle = value; }
        }
        private int _nro;			// nro de la casa o departamento

        public int Nro
        {
            get { return _nro; }
            set { _nro = value; }
        }

        private bool _esAvenida; 	// calle común o avenida

        public bool EsAvenida
        {
            get { return _esAvenida; }
            set { _esAvenida = value; }
        }
        private bool _esDepartamento;// es departamento o no

        public bool EsDepartamento
        {
            get { return _esDepartamento; }
            set { _esDepartamento = value; }
        }
        private int _piso;			// número del piso

        public int Piso
        {
            get { return _piso; }
            set { _piso = value; }
        }
        private String _dpto;		// departamento del piso

        public String Dpto
        {
            get { return _dpto; }
            set { _dpto = value; }
        }

        public Direccion(
            bool esA,		// calle común o avenida
            String nomCalle,	// nombre completo de la calle
            int n,				// nro de la casa o departamento
            bool esDep,		// es departamento o no
            int p,				// número del piso
            String d)
        {			// departamento del piso
            _esAvenida = esA;
            _nombreCalle = nomCalle;
            _nro = n;
            _esDepartamento = esDep;
            _piso = p;
            _dpto = d;
        }
    }
}
