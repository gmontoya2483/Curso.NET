﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interfaz2
{
    public abstract class EstadoArchivo: IOperacionesEmail 
    {
        public abstract void Mensaje();

        #region IOperacionesEmail Members

        public abstract void EnviarEmail(Archivo a);
        

        #endregion
    }
}
