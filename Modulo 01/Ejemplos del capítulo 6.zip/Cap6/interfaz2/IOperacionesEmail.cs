﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interfaz2
{
    public interface IOperacionesEmail
    {
        void EnviarEmail(Archivo a);
    }
}
