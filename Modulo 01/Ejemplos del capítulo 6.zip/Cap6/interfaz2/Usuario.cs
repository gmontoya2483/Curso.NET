﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interfaz2
{
    class Usuario
    {
        private string _rol;

        public string Rol
        {
            get { return _rol; }
            set { _rol = value; }
        }
        private string _dirEmail;

        public string DirEmail
        {
            get { return _dirEmail; }
            set { _dirEmail = value; }
        }

        public Usuario(string rol, string dirEmail)
        {
            this._rol = rol;
            this._dirEmail = dirEmail;
        }
    }
}
