﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace interfaz2
{
    class ArchivoNoAutorizado : EstadoArchivo
    {
        private string _estadoArchivo = "El Archivo NO tiene autorización";

        public override void Mensaje()
        {
            System.Console.WriteLine(_estadoArchivo);
        }


        #region IOperacionesEmail Members

        public override void EnviarEmail(Archivo a)
        {
            MensajeEmail m = new MensajeEmail();
            m.Asunto = "Acción en archivo: " + a.Nombre + "\n" + _estadoArchivo;
            m.Destinatario = a.Usuario.DirEmail;
            m.Mensaje = _estadoArchivo;
            m.Bc = "N/A";
            m.Cc = "N/A";
            m.EnviarCorreo();
        }

        #endregion
    }
}
