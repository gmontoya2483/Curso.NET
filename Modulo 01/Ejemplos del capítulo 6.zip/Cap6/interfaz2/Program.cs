﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interfaz2
{
    class Program
    {
        static void Main(string[] args)
        {
            AdministradorDeEspacio admin = new AdministradorDeEspacio();

            Archivo a = new Archivo();
            a.Estado = new ArchivoAutorizado();
            a.Usuario = new Usuario("Administrador", "pablo@servidor.com");
            a.Nombre = "Foto1.jpg";
            a.Tipo = "imagen";
            a.Tamanio = 200;

            admin.GrabarArchivo(a);

            a.Estado = null;
            a = null;


            a = new Archivo();

            a.Estado = new ArchivoNoAutorizado();
            a.Usuario = new Usuario("Invitado", "pedro@servidor.com");
            a.Nombre = "Foto2.jpg";
            a.Tipo = "imagen";
            a.Tamanio = 900;

            admin.GrabarArchivo(a);

            a.Estado = null;
            a = null;

            a = new Archivo();

            a.Estado = new ArchivoAutorizado();
            a.Usuario = new Usuario("Usuario", "fabian@servidor.com");
            a.Nombre = "MiCV.doc";
            a.Tipo = "archivo Woed";
            a.Tamanio = 100;

            admin.GrabarArchivo(a);

            System.Console.ReadKey();

        }
    }
}
