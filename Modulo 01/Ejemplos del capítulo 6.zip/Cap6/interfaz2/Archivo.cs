﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace interfaz2
{
    public class Archivo
    {
        private string _nombre;

        public string Nombre
        {
            get { return _nombre; }
            set { _nombre = value; }
        }
        private int _tamanio;

        public int Tamanio
        {
            get { return _tamanio; }
            set { _tamanio = value; }
        }
        private Usuario _usuario;

        internal Usuario Usuario
        {
            get { return _usuario; }
            set { _usuario = value; }
        }

        private string _tipo;

        public string Tipo
        {
            get { return _tipo; }
            set { _tipo = value; }
        }
        private EstadoArchivo _estado;

        public EstadoArchivo Estado
        {
            get { return _estado; }
            set { _estado = value; }
        }
    }
}
