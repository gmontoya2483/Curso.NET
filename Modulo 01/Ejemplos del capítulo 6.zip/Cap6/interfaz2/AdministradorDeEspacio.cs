﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interfaz2
{
    public class AdministradorDeEspacio 
    {
        private DriverDeDisco d = new DriverDeDisco();
        private Archivo _archivo;

        public void GrabarArchivo(Archivo a)
        {
            this._archivo = a;
            Console.WriteLine("Acción sobre el disco");
            EnviarCorreoConAccion(d);
            EnviarCorreoConAccion(a.Estado);
        }

        private void EnviarCorreoConAccion(IOperacionesEmail op)
        {
            op.EnviarEmail(_archivo);
        }

    }



}
