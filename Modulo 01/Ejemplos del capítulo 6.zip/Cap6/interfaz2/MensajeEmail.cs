﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interfaz2
{
    public class MensajeEmail 
    {
        private String _mensaje;

        public String Mensaje
        {
            get { return _mensaje; }
            set { _mensaje = value; }
        }
        private String _asunto;

        public String Asunto
        {
            get { return _asunto; }
            set { _asunto = value; }
        }
        private String _destinatario;

        public String Destinatario
        {
            get { return _destinatario; }
            set { _destinatario = value; }
        }
        private String _bc;

        public String Bc
        {
            get { return _bc; }
            set { _bc = value; }
        }
        private String _cc;

        public String Cc
        {
            get { return _cc; }
            set { _cc = value; }
        }

        private void escribirEncabezado()
        {
            Console.WriteLine("Escribiendo el encabezado");
        }

        private void escribirMensaje(String mensaje)
        {
            Console.WriteLine("Escribiendo el mensaje {0}", mensaje);
        }

        private void escribirDestinatario(String destinatario)
        {
            Console.WriteLine("Escribiendo el destinatario {0}", destinatario);
        }

        private void escribirAsunto(String asunto)
        {
            Console.WriteLine("Escribiendo el asunto {0}", asunto);
        }

        private void escribirCC(String cc)
        {
            Console.WriteLine("Escribiendo el CC {0}", cc);
        }

        private void escribirBC(String bc)
        {
            Console.WriteLine("Escribiendo el BC {0}", bc);
        }

 
        public void EnviarCorreo()
        {
            escribirEncabezado();
            escribirMensaje(Mensaje);
            escribirDestinatario(Destinatario);
            escribirAsunto(Asunto);
            escribirCC(Cc);
            escribirBC(Bc);
        }

    }
}
