﻿using System;
using System.Collections.Generic;
using System.Text;

namespace interfaz2
{
    public class DriverDeDisco: IOperacionesEmail
    {
        private string _estadoArchivo = "Intentando grabar en el Disco";


        #region IOperacionesEmail Members

        void IOperacionesEmail.EnviarEmail(Archivo a)
        {
            MensajeEmail m = new MensajeEmail();
            m.Asunto = "Acción en archivo: " + a.Nombre + "\n" + _estadoArchivo;
            m.Destinatario = a.Usuario.DirEmail;
            m.Mensaje = _estadoArchivo;
            m.Bc = "N/A";
            m.Cc = "N/A";
            m.EnviarCorreo();
        }

        #endregion
    }
}
