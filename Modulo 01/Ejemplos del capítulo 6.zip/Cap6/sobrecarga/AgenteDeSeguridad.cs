﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sobrecarga
{
    class AgenteDeSeguridad : Empleado
    {
        private String _nroLicencia;

        public String NroLicencia
        {
            get { return _nroLicencia; }
            set { _nroLicencia = value; }
        }

        public AgenteDeSeguridad(String p, String s, String a,
            String d, Direccion objDir)
            : base(p, s, a, d, objDir)
        {
        }

    }
}
