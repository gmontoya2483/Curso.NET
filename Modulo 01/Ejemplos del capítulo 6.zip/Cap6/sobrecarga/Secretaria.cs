﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sobrecarga
{
    class Secretaria : Empleado
    {
        public Secretaria(
            String p,
            String s,
            String a,
            String doc,
            Direccion objDir,
            String dep,
            String i,
            String ij,
            float sdo)
            : base(p, s, a, doc, objDir, dep, i, ij, sdo)
        {
        }

    }
}
