﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sobrecarga
{
    class Gerente : Empleado
    {
        private int _nroEmpleados = 10;

        public int NroEmpleados
        {
            get { return _nroEmpleados; }
            set { _nroEmpleados = value; }
        }


        public Gerente(
            String p,
            String s,
            String a,
            String doc,
            Direccion objDir,
            String dep,
            String i,
            String ij,
            float sdo,
            int ne)
            : base(p, s, a, doc, objDir, dep, i, ij, sdo)
        {
            _nroEmpleados = ne;
        }

    }
}
