﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia0
{
    class Persona
    {
        private String _primerNombre;

        public String PrimerNombre
        {
            get { return _primerNombre; }
            set { _primerNombre = value; }
        }
        private String _segundoNombre;

        public String SegundoNombre
        {
            get { return _segundoNombre; }
            set { _segundoNombre = value; }
        }
        private String _apellido;

        public String Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }
        private String _documento;

        public String Documento
        {
            get { return _documento; }
            set { _documento = value; }
        }

        public Persona(String primerNombre, String segundoNombre, String apellido,
        String documento)
        {
            this._primerNombre = primerNombre;
            this._segundoNombre = segundoNombre;
            this._apellido = apellido;
            this._documento = documento;
        }

    }
}
