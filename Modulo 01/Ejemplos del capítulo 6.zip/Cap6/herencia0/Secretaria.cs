﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia0
{
    class Secretaria
    {
        private String _primerNombre;

        public String PrimerNombre
        {
            get { return _primerNombre; }
            set { _primerNombre = value; }
        }
        private String _segundoNombre;

        public String SegundoNombre
        {
            get { return _segundoNombre; }
            set { _segundoNombre = value; }
        }
        private String _apellido;

        public String Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }
        private String _documento;

        public String Documento
        {
            get { return _documento; }
            set { _documento = value; }
        }
        private String _departamento;

        public String Departamento
        {
            get { return _departamento; }
            set { _departamento = value; }
        }
        private String _id;

        public String Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private float _sueldo;

        public float Sueldo
        {
            get { return _sueldo; }
            set { _sueldo = value; }
        }
        private String _idJefe;

        public String IdJefe
        {
            get { return _idJefe; }
            set { _idJefe = value; }
        }

        public Secretaria(String primerNombre, String segundoNombre,
        String apellido, String documento, String departamento, String id,
        float sueldo, String idJefe)
        {
            this._primerNombre = primerNombre;
            this._segundoNombre = segundoNombre;
            this._apellido = apellido;
            this._documento = documento;
            this._departamento = departamento;
            this._id = id;
            this._sueldo = sueldo;
            this._idJefe = idJefe;
        }

    }
}
