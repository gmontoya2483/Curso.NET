﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia0
{
    class UsaHerencia0
    {
        static void Main(string[] args)
        {
            Gerente g = new Gerente("Juan", "Pedro", "Goyena", "17.767.076", 
                                        "Ventas", "0", "GV50", 5500.0F, 20);
            Console.WriteLine("Apellido: " + g.Apellido);
            Console.WriteLine("Primer Nombre: " + g.PrimerNombre);
            Console.WriteLine("Segundo Nombre: " + g.SegundoNombre);
            Console.WriteLine("Departamento: " + g.Departamento);

            Console.ReadKey();

        }
    }
}
