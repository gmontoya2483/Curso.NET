﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstracta
{
    class Empleado:Persona
    {
        private String _departamento;

        public String Departamento
        {
            get { return _departamento; }
            set { _departamento = value; }
        }
        private String id;

        public String Id
        {
            get { return id; }
            set { id = value; }
        }
        private String _idJefe;

        public String IdJefe
        {
            get { return _idJefe; }
            set { _idJefe = value; }
        }
        private float _sueldo;

        public float Sueldo
        {
            get { return _sueldo; }
            set { _sueldo = value; }
        }
        private String _detalles;

        public override String Detalles
        {
            get { ArmaDetalles(); return _detalles; }
            set { _detalles = value; }
        }
        public Empleado(String p, String s, String a, String doc, Direccion objDir,
             String dep, String i, String ij, float sdo):base(p, s, a, doc, objDir)
        {
            _departamento = dep;
            id = i;
            _idJefe = ij;
            _sueldo = sdo;
        }

        private void ArmaDetalles()
        {
            _detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + ObjDireccion.NombreCalle + " " + ObjDireccion.Nro +
            " " + ObjDireccion.Piso + "°" + ObjDireccion.Dpto +
            " Departamento: " + Departamento + " ID:" + Id +
            " ID del Jefe:" + IdJefe + " Sueldo:" + Sueldo;
        }
    }
}
