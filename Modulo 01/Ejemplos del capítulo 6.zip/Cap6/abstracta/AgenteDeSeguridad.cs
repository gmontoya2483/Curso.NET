﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstracta
{
    class AgenteDeSeguridad:Persona
    {
        private String _nroLicencia;

        public String NroLicencia
        {
            get { return _nroLicencia; }
            set { _nroLicencia = value; }
        }
        private String _detalles;

        public override String Detalles
        {
            get { ArmaDetalles(); return _detalles; }
            set { _detalles = value; }
        }

        public AgenteDeSeguridad(String p,
            String s,
            String a,
            String d,
            Direccion objDir,
            String nl):base(p, s, a, d, objDir)
        {
            _nroLicencia = nl;
        }

        private void ArmaDetalles()
        {
            _detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + ObjDireccion.NombreCalle + " " + ObjDireccion.Nro +
            " " + ObjDireccion.Piso + "°" + ObjDireccion.Dpto;
        }
    }
}
