﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstracta
{
    abstract class Persona
    {
        private String _primerNombre;

        public String PrimerNombre
        {
            get { return _primerNombre; }
            set { _primerNombre = value; }
        }
        private String _segundoNombre;

        public String SegundoNombre
        {
            get { return _segundoNombre; }
            set { _segundoNombre = value; }
        }
        private String _apellido;

        public String Apellido
        {
            get { return _apellido; }
            set { _apellido = value; }
        }
        private String _documento;

        public String Documento
        {
            get { return _documento; }
            set { _documento = value; }
        }
        private Direccion _objDireccion;

        public Direccion ObjDireccion
        {
            get { return _objDireccion; }
            set { _objDireccion = value; }
        }


        public Persona(String p,
            String s,
            String a,
            String d, Direccion objD)
        {
            _primerNombre = p;
            _segundoNombre = s;
            _apellido = a;
            _documento = d;
            _objDireccion = objD;
        }

        public abstract String Detalles
        {
            get;
            set;
        }
    }
}
