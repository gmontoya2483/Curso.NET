﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstracta
{
    class Secretaria:Empleado
    {
        private String _detalles;

        public override String Detalles
        {
            get { ArmaDetalles(); return _detalles; }
            set { _detalles = value; }
        }
        public Secretaria(
            String p,
            String s,
            String a,
            String doc,
            Direccion objDir,
            String dep,
            String i,
            String ij,
            float sdo):base(p, s, a, doc, objDir, dep, i, ij, sdo)
        {

        }

        private void ArmaDetalles()
        {
            _detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + ObjDireccion.NombreCalle + " " + ObjDireccion.Nro +
            " " + ObjDireccion.Piso + "°" + ObjDireccion.Dpto +
            " Departamento: " + Departamento + " ID:" + Id +
            " ID del Jefe:" + IdJefe + " Sueldo:" + Sueldo;
        }
    }
}
