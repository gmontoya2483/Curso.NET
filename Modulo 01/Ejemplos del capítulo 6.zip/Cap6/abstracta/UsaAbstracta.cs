﻿using System;

namespace abstracta
{
    class UsaAbstracta
    {
        static void Main(string[] args)
        {
            Direccion d = new Direccion(true, "Juan De Garay", 870, true, 1, "A");
            Gerente g = new Gerente("Juan", "Pedro", "Goyena", "17.767.076", d,
                                "Ventas", "0", "GV50", 5500.0F, 20);
            Console.WriteLine("Apellido: " + g.Apellido);
            Console.WriteLine("Primer Nombre: " + g.PrimerNombre);
            Console.WriteLine("Segundo Nombre: " + g.SegundoNombre);
            Console.WriteLine("Departamento: " + g.Departamento);
            Console.WriteLine("Direccion: " + g.ObjDireccion.NombreCalle + " " +
                    g.ObjDireccion.Nro + " " + g.ObjDireccion.Piso + "° " +
                    g.ObjDireccion.Dpto);
            Console.WriteLine();
            Console.WriteLine("Todos los Detalles: " + g.Detalles);
            Console.ReadKey();
        }
    }
}
