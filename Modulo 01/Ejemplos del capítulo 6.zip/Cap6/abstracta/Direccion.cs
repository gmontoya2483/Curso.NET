﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstracta
{
    class Direccion
    {
        private bool _esAvenida;
        private String _nombreCalle;
        private int _nro;
        private bool _esDepartamento;
        private int _piso;
        private String _dpto;

        public String Dpto
        {
            get { return _dpto; }
            set { _dpto = value; }
        }		

        public int Piso
        {
            get { return _piso; }
            set { _piso = value; }
        }

        public bool EsDepartamento
        {
            get { return _esDepartamento; }
            set { _esDepartamento = value; }
        }

        public int Nro
        {
            get { return _nro; }
            set { _nro = value; }
        }

        public String NombreCalle
        {
            get { return _nombreCalle; }
            set { _nombreCalle = value; }
        }

        public bool EsAvenida
        {
            get { return _esAvenida; }
            set { _esAvenida = value; }
        }

        public Direccion(
            bool esA,		// calle común o avenida
            String nomCalle,	// nombre completo de la calle
            int n,				// nro de la casa o departamento
            bool esDep,		// es departamento o no
            int p,				// número del piso
            String d)
        {			// departamento del piso
            _esAvenida = esA;
            _nombreCalle = nomCalle;
            _nro = n;
            _esDepartamento = esDep;
            _piso = p;
            _dpto = d;
        }
 

    }
}
