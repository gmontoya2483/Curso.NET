﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace abstracta
{
    class Gerente : Empleado
    {
        private int _nroEmpleados = 10;

        protected int NroEmpleados
        {
            get { return _nroEmpleados; }
            set { _nroEmpleados = value; }
        }
        private String _detalles;

        public override String Detalles
        {
            get { ArmaDetalles(); return _detalles; }
            set { _detalles = value; }
        }

        public Gerente(
            String p,
            String s,
            String a,
            String doc,
            Direccion objDir,
            String dep,
            String i,
            String ij,
            float sdo,
            int ne)
            : base(p, s, a, doc, objDir, dep, i, ij, sdo)
        {
            _nroEmpleados = ne;
        }
        private void ArmaDetalles()
        {
            _detalles = base.Detalles +
            " Número de empleados: " + _nroEmpleados;
        }
    }
}
