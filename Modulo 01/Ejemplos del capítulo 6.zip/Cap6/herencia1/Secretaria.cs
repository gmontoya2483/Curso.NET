﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia1
{
    class Secretaria:Empleado
    {
        public Secretaria(
    String p,
    String s,
    String a,
    String doc,
    String dep,
    String i,
    String ij,
    float sdo):base(p, s, a, doc, dep, i, ij, sdo)
        {
        }
    }
}
