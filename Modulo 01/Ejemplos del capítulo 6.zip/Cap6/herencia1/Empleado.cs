﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia1
{
    class Empleado : Persona
    {
        private String _departamento;

        public String Departamento
        {
            get { return _departamento; }
            set { _departamento = value; }
        }
        private String _id;

        public String Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private String _idJefe;

        public String IdJefe
        {
            get { return _idJefe; }
            set { _idJefe = value; }
        }
        private float _sueldo;

        public float Sueldo
        {
            get { return _sueldo; }
            set { _sueldo = value; }
        }

        public Empleado(String p, String s, String a, String doc,
            String dep, String i, String ij, float sdo)
            : base(p, s, a, doc)
        {
            _departamento = dep;
            _id = i;
            _idJefe = ij;
            _sueldo = sdo;
        }

    }
}
