﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia1
{
    class AgenteDeSeguridad : Persona
    {
        private String _nroLicencia;

        public String NroLicencia
        {
            get { return _nroLicencia; }
            set { _nroLicencia = value; }
        }

        public AgenteDeSeguridad(String p, String s, String a, String d):base(p, s, a, d)
        {
        }

    }
}
