﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace herencia1
{
    class Gerente:Empleado
    {
        private int _nroEmpleados = 10;

        public int NroEmpleados
        {
            get { return _nroEmpleados; }
            set { _nroEmpleados = value; }
        }
        public Gerente(
            String p,
            String s,
            String a,
            String doc,
            String dep,
            String i,
            String ij,
            float sdo,
            int ne):base(p, s, a, doc, dep, i, ij, sdo)
        {
            _nroEmpleados = ne;
        }

    }
}
