﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace interfaz
{
    class Direccion
    {
        private String nombreCalle;	// nombre completo de la calle

        public String NombreCalle
        {
            get { return nombreCalle; }
            set { nombreCalle = value; }
        }
        private int nro;			// nro de la casa o departamento

        public int Nro
        {
            get { return nro; }
            set { nro = value; }
        }

        private bool esAvenida; 	// calle común o avenida

        public bool EsAvenida
        {
            get { return esAvenida; }
            set { esAvenida = value; }
        }
        private bool esDepartamento;// es departamento o no

        public bool EsDepartamento
        {
            get { return esDepartamento; }
            set { esDepartamento = value; }
        }
        private int piso;			// número del piso

        public int Piso
        {
            get { return piso; }
            set { piso = value; }
        }
        private String dpto;		// departamento del piso

        public String Dpto
        {
            get { return dpto; }
            set { dpto = value; }
        }

        public Direccion(
            bool esA,		// calle común o avenida
            String nomCalle,	// nombre completo de la calle
            int n,				// nro de la casa o departamento
            bool esDep,		// es departamento o no
            int p,				// número del piso
            String d)
        {			// departamento del piso
            esAvenida = esA;
            nombreCalle = nomCalle;
            nro = n;
            esDepartamento = esDep;
            piso = p;
            dpto = d;
        }


    }
}
