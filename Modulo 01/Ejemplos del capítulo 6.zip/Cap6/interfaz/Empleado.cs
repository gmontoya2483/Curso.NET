﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using interfaz;

namespace interfaz
{
    class Empleado : Persona, IEstacionamiento
    {
        private String departamento;

        public String Departamento
        {
            get { return departamento; }
            set { departamento = value; }
        }
        private String id;

        public String Id
        {
            get { return id; }
            set { id = value; }
        }
        private String idJefe;

        public String IdJefe
        {
            get { return idJefe; }
            set { idJefe = value; }
        }
        private float sueldo;

        public float Sueldo
        {
            get { return sueldo; }
            set { sueldo = value; }
        }

        public Empleado(String p, String s, String a, String doc, Direccion objDir,
             String dep, String i, String ij, float sdo):base(p, s, a, doc, objDir)
        {
            departamento = dep;
            id = i;
            idJefe = ij;
            sueldo = sdo;
        }

        public override String getDetalles()
        {
            armaDetalles();
            return detalles;
        }

        private void armaDetalles()
        {
            detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + Direccion.NombreCalle + " " + Direccion.Nro +
            " " + Direccion.Piso + "°" + Direccion.Dpto +
            " Departamento: " + Departamento + " ID:" + Id +
            " ID del Jefe:" + IdJefe + " Sueldo:" + Sueldo;
        }


        #region ISalario Members

        public int SueldoBruto
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int PagoGanacias
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public int PagoObraSocial
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        #endregion

        #region IEstacionamiento Members

        public void estacionar()
        {
           Console.WriteLine("Esta persona no puede estacionar en el garage de la empresa");
        }

        #endregion
    }
}
