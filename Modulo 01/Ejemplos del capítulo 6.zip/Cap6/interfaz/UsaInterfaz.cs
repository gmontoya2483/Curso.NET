﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using interfaz;

namespace interfaz
{
    class UsaInterfaz
    {
    
        static void Main(string[] args)
        {
		UsaInterfaz up = new UsaInterfaz();
		Persona refPolimorfica;
		
		Direccion d = new Direccion(true, "Juan De Garay", 870, true, 1, "A");
	
		d = null;
		d = new Direccion(false, "Amenabar", 1570, true, 7, "H");
		Empleado e = new Empleado("Sergio", "Omar", "Perotti","20.200.555",d, 
						"Administración","EA01","GAD50",1500.0F);
		d = null;
		d = new Direccion(true, "Allen", 1070, true, 5, "J");
		Secretaria s = new Secretaria("Laura", "Verónica", "Diaz","20.555.555",d, 
						"Directorio","SV01","GV50",1800.0F);
		d = null;
		d = new Direccion(false, "Juramento", 4561, false, 0, " ");
		Gerente g = new Gerente("Juan", "Pedro", "Goyena","17.767.076",d, 
						"Ventas","0","GV50",5500.0F,20);
		d = null;
		d = new Direccion(true, "Belgrano", 4560, true, 3, "C");
		AgenteDeSeguridad a = new AgenteDeSeguridad("Hernán", "Adrián",
						"Perez","20.888.999",d, "207272");
		
		refPolimorfica = e;
		Console.WriteLine(refPolimorfica.getDetalles());
        Console.WriteLine();
		refPolimorfica = s;
		Console.WriteLine(refPolimorfica.getDetalles());
        Console.WriteLine();
        refPolimorfica = g;
		Console.WriteLine(refPolimorfica.getDetalles());
        Console.WriteLine();
        refPolimorfica = a;
        Console.WriteLine(refPolimorfica.getDetalles());
        Console.WriteLine();
		
		up.muestraDetalles(e);
		up.muestraDetalles(s);
		up.muestraDetalles(g);
		up.muestraDetalles(a);

        Console.WriteLine();

        Console.WriteLine("Uso del garage para el Empleado:");
        up.permisoParaEstacionar(e);
        Console.WriteLine("Uso del garage para la Secretaria:");
        up.permisoParaEstacionar(s);
        Console.WriteLine("Uso del garage para el Gerente:");
        up.permisoParaEstacionar(g);
        Console.WriteLine("Uso del garage para el Agente de Seguridad:");
        up.permisoParaEstacionar(a);

        Console.ReadKey();

	}

        public void muestraDetalles(Persona refPolimorfica){
		Console.WriteLine("-----------------");
		Console.WriteLine(refPolimorfica.getDetalles());
        Console.WriteLine("-----------------");
        Console.ReadKey();
	}
        public void permisoParaEstacionar(IEstacionamiento e)
        {
            e.estacionar();
        }
    }
}
