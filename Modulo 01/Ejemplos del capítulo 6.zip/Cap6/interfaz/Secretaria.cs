﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using interfaz;

namespace interfaz
{
    class Secretaria : Empleado, IEstacionamiento
    {
        public Secretaria(
            String p,
            String s,
            String a,
            String doc,
            Direccion objDir,
            String dep,
            String i,
            String ij,
            float sdo):base(p, s, a, doc, objDir, dep, i, ij, sdo)
        {
        }

        public override String getDetalles()
        {
            armaDetalles();
            return detalles;
        }

        private void armaDetalles()
        {
            detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + Direccion.NombreCalle + " " + Direccion.Nro +
            " " + Direccion.Piso + "°" + Direccion.Dpto +
            " Departamento: " + Departamento + " ID:" + Id +
            " ID del Jefe:" + IdJefe + " Sueldo:" + Sueldo;
        }


        #region IEstacionamiento Members

        void IEstacionamiento.estacionar()
        {
            Console.WriteLine("Esta persona puede estacionar en el garage de la empresa");
        }

        #endregion
    }
}
