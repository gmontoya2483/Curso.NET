﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using interfaz;

namespace interfaz
{
    class Gerente : Empleado, IEstacionamiento
    {
        private int nroEmpleados = 10;

        public int NroEmpleados
        {
            get { return nroEmpleados; }
            set { nroEmpleados = value; }
        }

        public Gerente(
            String p,
            String s,
            String a,
            String doc,
            Direccion objDir,
            String dep,
            String i,
            String ij,
            float sdo,
            int ne):base(p, s, a, doc, objDir, dep, i, ij, sdo)
        {
            nroEmpleados = ne;
        }


        public override String getDetalles()
        {
            armaDetalles();
            return detalles;
        }

        private void armaDetalles()
        {
            detalles = base.getDetalles() +
            " Número de empleados: " + nroEmpleados;
        }



        #region IEstacionamiento Members

        void IEstacionamiento.estacionar()
        {
            Console.WriteLine("Esta persona puede estacionar en el garage de la empresa");
        }

        #endregion
    }
}
