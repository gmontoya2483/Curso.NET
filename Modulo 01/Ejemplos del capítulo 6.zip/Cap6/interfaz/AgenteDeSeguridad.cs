﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using interfaz;

namespace interfaz
{
    class AgenteDeSeguridad : Persona, IEstacionamiento
    {
        private String nroLicencia;

        public String NroLicencia
        {
            get { return nroLicencia; }
            set { nroLicencia = value; }
        }

        public AgenteDeSeguridad(String p,
            String s,
            String a,
            String d,
            Direccion objDir,
            String nl)
            : base(p, s, a, d, objDir)
        {
            nroLicencia = nl;
        }


        public override String getDetalles()
        {
            armaDetalles();
            return detalles;
        }

        private void armaDetalles()
        {
            detalles = "Apellido: " + Apellido + " Primer Nombre: " + PrimerNombre +
            " Segundo Nombre: " + SegundoNombre + " Documento: " + Documento +
            " Direccion: " + base.Direccion.NombreCalle + " " + base.Direccion.Nro +
            " " + base.Direccion.Piso + "°" + base.Direccion.Dpto;
        }


        #region IEstacionamiento Members

        public void estacionar()
        {
            Console.WriteLine("Esta persona no puede estacionar en el garage de la empresa");
        }

        #endregion
    }
}
