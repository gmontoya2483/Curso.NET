﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace asociacion
{
    class UsaAsociacion
    {
        static void Main(string[] args)
        {
            Auto a = new Auto("Fiat", "Uno", "1998");
            Persona p = new Persona("Juan", "Ignacio", "Perez", "21111222");

            p.usaAuto(a);

            Console.ReadKey();

        }
    }
}
