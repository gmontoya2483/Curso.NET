﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace composicion
{
    class UsaComposicion
    {
        static void Main(string[] args)
        {
         	Persona p = new Persona("Juan", "Pedro", "Diaz","22333444","Venezuela",1301);
		    Console.WriteLine("La persona vive en " + p.Dir.NombreCalle + ", Nro. " + p.Dir.Nro );

            Console.WriteLine("Mudate Juan!!!!");

            p.Dir.NombreCalle = "Saenz Peña";
            p.Dir.Nro = 151;
            Console.WriteLine("La persona vive en " + p.Dir.NombreCalle + ", Nro. " + p.Dir.Nro);
            Console.ReadKey();
        }
    }
}
