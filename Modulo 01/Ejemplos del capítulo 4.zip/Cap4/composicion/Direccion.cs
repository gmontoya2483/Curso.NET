﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace composicion
{
    class Direccion
    {
        private String nombreCalle;	// nombre completo de la calle

        public String NombreCalle
        {
            get { return nombreCalle; }
            set { nombreCalle = value; }
        }
        private int nro;			// nro de la casa o departamento

        public int Nro
        {
            get { return nro; }
            set { nro = value; }
        }

        /**
         * 
         */
        public Direccion(
            String nomCalle,	// nombre completo de la calle
            int n)// nro de la casa 
        {				
            nombreCalle = nomCalle;
            nro = n;
        }

    }
}
