﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace claseAsociacion
{
    class UsaClaseAsociacion
    {
        static void Main(string[] args)
        {
            int i = 0;
            int j = 0;

            Persona[] vecPerA1 = new Persona[1];
            Persona[] vecPerA2 = new Persona[3];
            Persona[] vecPerA3 = new Persona[2];
            Persona[] vecPerA4 = new Persona[2];
            Persona[] vecPerA5 = new Persona[2];

            Persona p1 = new Persona("Juan", "Ignacio", "Perez", "21111222");
            Persona p2 = new Persona("Pedro", "Alberto", "Almeida", "23222111");
            Persona p3 = new Persona("Carlos", "Alejo", "Garcia", "21444555");
            Persona p4 = new Persona("Sergio", "Ricardo", "Burr", "21666777");

            vecPerA1[0] = p1;

            vecPerA2[0] = p1;
            vecPerA2[1] = p3;
            vecPerA2[2] = p4;

            vecPerA3[0] = p1;
            vecPerA3[1] = p2;

            vecPerA4[0] = p2;
            vecPerA4[1] = p3;

            vecPerA5[0] = p2;
            vecPerA5[1] = p4;


            Auto[] vecAuP1 = new Auto[3];
            Auto[] vecAuP2 = new Auto[3];
            Auto[] vecAuP3 = new Auto[2];
            Auto[] vecAuP4 = new Auto[2];

            Auto a1 = new Auto("Fiat", "Uno", "1996");
            Auto a2 = new Auto("Fiat", "Dos", "1997");
            Auto a3 = new Auto("Fiat", "Tres", "1998");
            Auto a4 = new Auto("Fiat", "Cuatro", "1999");
            Auto a5 = new Auto("Fiat", "Cuatro", "2000");

            vecAuP1[0] = a1;
            vecAuP1[1] = a2;
            vecAuP1[2] = a3;

            vecAuP2[0] = a3;
            vecAuP2[1] = a4;
            vecAuP2[2] = a5;

            vecAuP3[0] = a2;
            vecAuP3[1] = a4;

            vecAuP4[0] = a2;
            vecAuP4[1] = a5;


            Asignados[] autosPersona = new Asignados[4];

            autosPersona[0] = new Asignados(p1, vecAuP1);
            autosPersona[1] = new Asignados(p2, vecAuP2);
            autosPersona[2] = new Asignados(p3, vecAuP3);
            autosPersona[3] = new Asignados(p4, vecAuP4);


            Asignados[] personasAuto = new Asignados[5];

            personasAuto[0] = new Asignados(a1, vecPerA1);
            personasAuto[1] = new Asignados(a2, vecPerA2);
            personasAuto[2] = new Asignados(a3, vecPerA3);
            personasAuto[3] = new Asignados(a4, vecPerA4);
            personasAuto[4] = new Asignados(a5, vecPerA5);

            for (i = 0; i < autosPersona.Length; i++)
            {
                Console.WriteLine("Autos Asignados a la Persona " );
                Console.WriteLine("Apellido: " + autosPersona[i].Persona.Apellido);
                Console.WriteLine("Primer Nombre: " + autosPersona[i].Persona.PrimerNombre);
                Console.WriteLine("Segundo Nombre: " + autosPersona[i].Persona.SegundoNombre);
                Console.WriteLine("Documento: " + autosPersona[i].Persona.Documento);

                Auto[] autos = autosPersona[i].Autos;

                for (j = 0; j < autos.Length; j++)
                {
                    Console.WriteLine("========================================");
                    Console.WriteLine("Marca: " + autos[j].Marca
                    + " Modelo: " + autos[j].Modelo
                    + " Año: " + autos[j].Anio);
                    Console.WriteLine("========================================");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
            Console.WriteLine();

            for (i = 0; i < personasAuto.Length; i++)
            {
                Console.WriteLine("Marca: " + personasAuto[i].Auto.Marca
                + " Modelo: " + personasAuto[i].Auto.Modelo
                + " Año: " + personasAuto[i].Auto.Anio);

                Persona[] personas = personasAuto[i].Personas;

                for (j = 0; j < personas.Length; j++)
                {
                    Console.WriteLine("========================================");
                    Console.WriteLine("Persona Asignados al Auto ");
                    Console.WriteLine("Apellido: " + personas[j].Apellido);
                    Console.WriteLine("Primer Nombre: " + personas[j].PrimerNombre);
                    Console.WriteLine("Segundo Nombre: " + personas[j].SegundoNombre);
                    Console.WriteLine("Documento: " + personas[j].Documento);
                    Console.WriteLine("========================================");
                }
                Console.WriteLine();
            }
            Console.ReadKey();

        }
    }
}
