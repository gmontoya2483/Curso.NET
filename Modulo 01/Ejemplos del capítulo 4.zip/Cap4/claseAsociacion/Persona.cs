﻿using System;
using System.Collections.Generic;
using System.Text;

namespace claseAsociacion
{
    class Persona
    {
        private String primerNombre;

        public String PrimerNombre
        {
            get { return primerNombre; }
            set { primerNombre = value; }
        }
        private String segundoNombre;

        public String SegundoNombre
        {
            get { return segundoNombre; }
            set { segundoNombre = value; }
        }
        private String apellido;

        public String Apellido
        {
            get { return apellido; }
            set { apellido = value; }
        }
        private String documento;

        public String Documento
        {
            get { return documento; }
            set { documento = value; }
        }


        public Persona(String p,
            String s,
            String a,
            String d)
        {
            primerNombre = p;
            segundoNombre = s;
            apellido = a;
            documento = d;
        }
	
    }
}
