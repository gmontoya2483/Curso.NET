﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace agregacion
{
    class UsaAgregacion
    {
        static void Main(string[] args)
        {
            Auto a = new Auto("Fiat", "Uno","1998");
		    Persona p = new Persona("Juan", "Ignacio", "Perez","21111222");
    		
		    p.Auto=a;

            Console.WriteLine("La Persona tiene agregado un auto " + p.Auto.Marca
			     +" " + p.Auto.Modelo+ " del año " + p.Auto.Anio);
            Console.ReadKey();

        }
    }
}
