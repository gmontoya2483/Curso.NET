﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace agregacion
{
    class Auto
    {
        private String marca;

        public String Marca
        {
            get { return marca; }
            set { marca = value; }
        }
        private String modelo;

        public String Modelo
        {
            get { return modelo; }
            set { modelo = value; }
        }
        private String anio;

        public String Anio
        {
            get { return anio; }
            set { anio = value; }
        }

        public Auto(String ma, String mo, String an)
        {
            marca = ma;
            modelo = mo;
            anio = an;
        }

    }
}
