﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using asociacionCalificada;


namespace asociacionCalificada
{
    class UsaAsociacionCalificada
    {
        static void Main(string[] args)
        {
            	Persona p1 = new Persona("Juan", "Ignacio", "Perez","21111222");
				Persona p2 = new Persona("Pedro", "Alberto", "Almeida","23222111");
				Persona p3 = new Persona("Carlos", "Alejo", "Garcia","21444555");
				Persona p4 = new Persona("Sergio", "Ricardo", "Burr","21666777");
		
				Auto a1 = new Auto("Fiat", "Uno","1996");
				Auto a2 = new Auto("Fiat", "Dos","1997");
				Auto a3 = new Auto("Fiat", "Tres","1998");
				Auto a4 = new Auto("Fiat", "Cuatro","1999");
				Auto a5 = new Auto("Fiat", "Cinco","2000");


				//Asignar los autos de la persona 1
				p1.setAuto(a1);
				p1.setAuto(a3);
				// Registrar que el auto fue asignado a 
				// la persona 1
				a1.setPersona(p1);
				a3.setPersona(p1);
				
				//Asignar los autos de la persona 2
				p2.setAuto(a2);
				p2.setAuto(a4);
				// Registrar que el auto fue asignado a 
				// la persona 2
                a2.setPersona(p2);
                a4.setPersona(p2);

				//Asignar los autos de la persona 3
				p3.setAuto(a1);
				p3.setAuto(a5);
				// Registrar que el auto fue asignado a 
				// la persona 3
                a1.setPersona(p3);
                a5.setPersona(p3);

				//Asignar los autos de la persona 4
				p4.setAuto(a2);
				p4.setAuto(a4);
				// Registrar que el auto fue asignado a 
				// la persona 4
                a2.setPersona(p4);
                a4.setPersona(p4);
		
				Console.WriteLine("Autos Asignados a la Persona 1");
				Console.WriteLine("Marca: " + p1.getAuto(0).Marca
					+ " Modelo: " + p1.getAuto(0).Modelo
					+ " Año: " + p1.getAuto(0).Anio);
				Console.WriteLine("Marca: " + p1.getAuto(1).Marca
					+ " Modelo: " + p1.getAuto(1).Modelo
					+ " Año: " + p1.getAuto(1).Anio);
				Console.WriteLine("------------------------------");		
				Console.WriteLine("Autos Asignados a la Persona 2");
				Console.WriteLine("Marca: " + p2.getAuto(0).Marca
					+ " Modelo: " + p2.getAuto(0).Modelo
					+ " Año: " + p2.getAuto(0).Anio);
				Console.WriteLine("Marca: " + p2.getAuto(1).Marca
					+ " Modelo: " + p2.getAuto(1).Modelo
					+ " Año: " + p2.getAuto(1).Anio);
				Console.WriteLine("------------------------------");		
				Console.WriteLine("Autos Asignados a la Persona 3");
				Console.WriteLine("Marca: " + p3.getAuto(0).Marca
					+ " Modelo: " + p3.getAuto(0).Modelo
					+ " Año: " + p3.getAuto(0).Anio);
				Console.WriteLine("Marca: " + p3.getAuto(1).Marca
					+ " Modelo: " + p3.getAuto(1).Modelo
					+ " Año: " + p3.getAuto(1).Anio);
				Console.WriteLine("------------------------------");		
				Console.WriteLine("Autos Asignados a la Persona 4");
				Console.WriteLine("Marca: " + p4.getAuto(0).Marca
					+ " Modelo: " + p4.getAuto(0).Modelo
					+ " Año: " + p4.getAuto(0).Anio);
				Console.WriteLine("Marca: " + p4.getAuto(1).Marca
					+ " Modelo: " + p4.getAuto(1).Modelo
					+ " Año: " + p4.getAuto(1).Anio);		
				Console.WriteLine("------------------------------");
				Console.WriteLine("******************************");
				Console.WriteLine("------------------------------");
				Console.WriteLine("Personas Asignadas al auto 1");
				Console.WriteLine("Nombre: " + a1.getPersona(0).PrimerNombre
                + " " + a1.getPersona(0).SegundoNombre
                + " " + a1.getPersona(0).Apellido);
                Console.WriteLine("Nombre: " + a1.getPersona(1).PrimerNombre
                        + " " + a1.getPersona(1).SegundoNombre
                        + " " + a1.getPersona(1).Apellido);
				Console.WriteLine("------------------------------");
				Console.WriteLine("Personas Asignadas al auto 2");
                Console.WriteLine("Nombre: " + a2.getPersona(0).PrimerNombre
                        + " " + a2.getPersona(0).SegundoNombre
                        + " " + a2.getPersona(0).Apellido);
                Console.WriteLine("Nombre: " + a2.getPersona(1).PrimerNombre
                        + " " + a2.getPersona(1).SegundoNombre
                        + " " + a2.getPersona(1).Apellido);
				Console.WriteLine("------------------------------");
				Console.WriteLine("Personas Asignadas al auto 3");
                Console.WriteLine("Nombre: " + a3.getPersona(0).PrimerNombre
                        + " " + a3.getPersona(0).SegundoNombre
                        + " " + a3.getPersona(0).Apellido);
				Console.WriteLine("------------------------------");
				Console.WriteLine("Personas Asignadas al auto 4");
                Console.WriteLine("Nombre: " + a4.getPersona(0).PrimerNombre
                        + " " + a4.getPersona(0).SegundoNombre
                        + " " + a4.getPersona(0).Apellido);
                Console.WriteLine("Nombre: " + a4.getPersona(1).PrimerNombre
                        + " " + a4.getPersona(1).SegundoNombre
                        + " " + a4.getPersona(1).Apellido);
				Console.WriteLine("------------------------------");
				Console.WriteLine("Personas Asignadas al auto 5");
                Console.WriteLine("Nombre: " + a5.getPersona(0).PrimerNombre
                        + " " + a5.getPersona(0).SegundoNombre
                        + " " + a5.getPersona(0).Apellido);

                Console.ReadKey();
			}

        }
    }

