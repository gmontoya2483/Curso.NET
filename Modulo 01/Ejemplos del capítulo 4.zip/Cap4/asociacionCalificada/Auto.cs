﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace asociacionCalificada
{
    class Auto
    {
        private String marca;

        public String Marca
        {
            get { return marca; }
            set { marca = value; }
        }
        private String modelo;

        public String Modelo
        {
            get { return modelo; }
            set { modelo = value; }
        }
        private String anio;

        public String Anio
        {
            get { return anio; }
            set { anio = value; }
        }

        private Persona[] refPersona = new Persona[10];

        public Persona[] RefPersona
        {
            get { return refPersona; }
            set { refPersona = value; }
        }

	    private int i;	

        public Auto(String ma, String mo, String an)
        {
            marca = ma;
            modelo = mo;
            anio = an;
        }

        public void setPersona(Persona persona)
        {
            refPersona[i] = persona;
            i = i + 1;
        }
        public Persona getPersona(int p)
        {
            return refPersona[p];
        }

    }
}
